# certificates.py
import ctypes
from ctypes import wintypes
from zeus_win32_utils import raise_windows_error
from .base import CertAPISerializableBase
from .crypt32 import (
    crypt_string_to_binary,
    CertGetNameString, CertNameType, CertNameFlags, CertEnumCertificateContextProperties,
    CertPropertyID, CertGetCertificateContextProperty, CertSerializeCertificateStoreElement,
    CertFreeCertificateContext, CertFreeCTLContext, CertCreateCertificateContext,
    ASNEncodingType, CryptStringFormat, CRYPT_KEY_PROV_INFO, PCTL_USAGE
)


UNICODE_PROPERTIES = {
    CertPropertyID.FRIENDLY_NAME,
    CertPropertyID.AUTO_ENROLL,
    CertPropertyID.EXTENDED_ERROR_INFO,
    CertPropertyID.PUB_KEY_CNG_ALG_BIT_LENGTH,
    CertPropertyID.PVK_FILE,
    CertPropertyID.REQUEST_ORIGINATOR,
    CertPropertyID.SIGN_HASH_CNG_ALG
}


class CertificateStoreItem(CertAPISerializableBase):
    def __init__(self, cert_api, location, store, p_ctx):
        super(CertificateStoreItem, self).__init__(cert_api=cert_api)
        self.location = location
        self.store = store
        self._p_ctx = p_ctx

    def __repr__(self):
        return f'{self.__class__.__name__}(location="{self.location.name}", store="{self.store.name}")'

    def __setstate__(self, state):
        super(CertificateStoreItem, self).__setstate__(state)
        self.location = None
        self.store = None
        self._p_ctx = None


class Certificate(CertificateStoreItem):
    @classmethod
    def from_file(cls, cert_api, path, encoding_type=ASNEncodingType.X509,
                  location=None, store=None):
        with open(path, 'rb') as f:
            return cls.from_bytes(
                cert_api=cert_api,
                encoded_data=f.read(),
                encoding_type=encoding_type,
                store=store,
                location=location
            )

    @classmethod
    def from_bytes(cls, cert_api, encoded_data, encoding_type=ASNEncodingType.X509,
                   location=None, store=None):
        if encoding_type not in ASNEncodingType:
            encoding_type = ASNEncodingType(encoding_type)

        if isinstance(encoded_data, str):
            encoded_data = encoded_data.encode('utf-8', 'strict')

        if not isinstance(encoded_data, (bytes, bytearray)):
            raise TypeError(f'Invalid type for data: "{type(encoded_data).__name__}"')

        data_arr = crypt_string_to_binary(encoded_data, CryptStringFormat.BASE_64)

        p_ctx = CertCreateCertificateContext(
            encoding_type.value,
            data_arr,
            len(encoded_data)
        )

        if not p_ctx:
            raise_windows_error()

        return cls(
            cert_api=cert_api,
            p_ctx=p_ctx,
            store=store,
            location=location
        )

    def __init__(self, cert_api, p_ctx, location=None, store=None):
        super(Certificate, self).__init__(
            cert_api=cert_api,
            location=location,
            store=store,
            p_ctx=p_ctx
        )
        self.__ext_properties = set()
        self.__ext_properties_enumerated = False

    def __del__(self):
        CertFreeCertificateContext(self._p_ctx)

    def __setstate__(self, state):
        super(Certificate, self).__setstate__(state)
        self.__ext_properties = set()
        self.__ext_properties_enumerated = False

    @property
    def subject(self):
        return self.get_name_string(name_type=CertNameType.RDN)

    @property
    def issuer(self):
        return self.get_name_string(name_flags=CertNameFlags.ISSUER)

    @property
    def serial_number(self):
        return self.get_serial_number()

    @property
    def extended_properties(self):
        return self.enum_properties()

    @property
    def friendly_name(self):
        return self.get_property(CertPropertyID.FRIENDLY_NAME)

    # @property
    # def enhanced_key_usage(self):
    #     pass

    def _resolve(self, *names):
        node = self._p_ctx

        for name in names:
            if isinstance(node, ctypes._Pointer):
                try:
                    node = node.contents
                except ValueError:
                    return False

            node = getattr(node, name)

        return node

    def _ensure_ext_properties_enumerated(self):
        if not self.__ext_properties_enumerated:
            self.enum_properties()

    def _serialize(self):
        size = wintypes.DWORD(0)

        try:
            res = CertSerializeCertificateStoreElement(
                self._p_ctx,
                0,
                None,
                ctypes.byref(size)
            )
        except OSError:
            return b''

        if not res:
            raise_windows_error()

        data = (ctypes.c_ubyte * size.value)()

        res = CertSerializeCertificateStoreElement(
            self._p_ctx,
            0,
            ctypes.cast(data, ctypes.POINTER(wintypes.BYTE)),
            ctypes.byref(size)
        )

        if not res:
            raise_windows_error()

        return bytes(data[:size.value])

    def get_serial_number(self):
        blob = self._resolve('pCertInfo', 'SerialNumber')
        sn_len = blob.cbData
        c_ba = (ctypes.c_ubyte * sn_len)()
        ctypes.memmove(c_ba, blob.pbData, sn_len)
        return ' '.join(f'0x{i:02x}' for i in reversed((c_ba[:sn_len])))

    def get_name_string(self, name_type=CertNameType.RDN, name_flags=None):
        if name_type not in CertNameType:
            name_type = CertNameType(name_type)

        name_flags = name_flags or 0

        if name_flags:

            if name_flags not in CertNameFlags:
                name_flags = CertNameFlags(name_flags)

            name_flags = name_flags.value

        try:
            required_size = CertGetNameString(
                self._p_ctx,
                name_type.value,
                name_flags,
                None,
                None,
                0
            )
        except OSError:
            return

        name_string = ctypes.create_string_buffer(required_size)

        try:
            CertGetNameString(
                self._p_ctx,
                name_type.value,
                name_flags,
                None,
                name_string,
                required_size
            )
        except OSError:
            return

        value = name_string.value.decode('utf-8', 'strict')

        if name_type is CertNameType.RDN:
            return tuple(reversed(tuple(filter(None, value.split(', ')))))

        return value

    def enum_properties(self):
        prop_id = 0

        while True:
            try:
                prop_id = CertEnumCertificateContextProperties(self._p_ctx, prop_id)
            except OSError:
                prop_id = 0

            if not prop_id:
                break

            try:
                cert_property = CertPropertyID(prop_id)
            except ValueError:
                pass

            else:
                prop_id = cert_property.value

            self.__ext_properties.add(prop_id)

        self.__ext_properties_enumerated = True
        return self.__ext_properties

    def get_property_data(self, property_id):
        self._ensure_ext_properties_enumerated()

        try:
            if property_id not in CertPropertyID:
                property_id = CertPropertyID(property_id)
        except ValueError:
            if property_id not in self.__ext_properties:
                return

        else:
            property_id = property_id.value

        if property_id not in self.__ext_properties:
            return

        size = wintypes.DWORD(0)
        res = CertGetCertificateContextProperty(
            self._p_ctx,
            property_id,
            None,
            ctypes.byref(size)
        )

        if not res:
            raise_windows_error()

        property_data = ctypes.create_string_buffer(size.value)

        res = CertGetCertificateContextProperty(
            self._p_ctx,
            property_id,
            property_data,
            ctypes.byref(size)
        )

        if not res:
            raise_windows_error()

        return property_data, size.value

    def get_property(self, property_id):

        try:
            data, size = self.get_property_data(property_id)
        except TypeError:
            return

        try:
            cert_prop = CertPropertyID(property_id)
        except ValueError:
            return bytearray(data)

        if cert_prop is CertPropertyID.KEY_PROV_INFO:
            return CRYPT_KEY_PROV_INFO.from_buffer(bytearray(data))

        elif cert_prop in UNICODE_PROPERTIES:
            return ctypes.wstring_at(ctypes.addressof(data))

        elif cert_prop is CertPropertyID.ENHKEY_USAGE:
            return PCTL_USAGE.from_buffer(bytearray(data)).contents

        return bytearray(data)

    def get_context_properties(self):
        self._ensure_ext_properties_enumerated()
        properties = {}

        for prop_id in self.__ext_properties:
            try:
                key = CertPropertyID(prop_id)
            except ValueError:
                key = prop_id

            properties[key] = self.get_property(prop_id)

        return properties


class CertificateTrustList(CertificateStoreItem):
    def __init__(self, cert_api, location, store, p_ctx):
        super(CertificateTrustList, self).__init__(
            cert_api=cert_api,
            location=location,
            store=store,
            p_ctx=p_ctx
        )

    def __del__(self):
        CertFreeCTLContext(self._p_ctx)

    def _serialize(self, *args, **kwargs):
        pass
