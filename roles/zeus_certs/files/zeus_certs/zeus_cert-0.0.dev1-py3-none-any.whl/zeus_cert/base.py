# base.py
import abc
from hashlib import md5


class CertAPIBase:
    def __init__(self, cert_api):
        self._cert_api = cert_api


class CertAPISerializableBase(CertAPIBase, metaclass=abc.ABCMeta):
    def __init__(self, cert_api):
        super(CertAPISerializableBase, self).__init__(cert_api=cert_api)
        self._serialized_data = None

    def __hash__(self):
        data = self.serialize()

        if data is None:
            return super().__hash__()

        return int(md5(data).hexdigest(), 16)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    def __getstate__(self):
        return {'serialized_data': self.serialize()}

    def __setstate__(self, state):
        self._serialized_data = state['serialized_data']

    @abc.abstractmethod
    def _serialize(self, *args, **kwargs):
        raise NotImplementedError()

    def clear_serialized_data(self):
        self._serialized_data = None

    def serialize(self, *args, **kwargs):
        if self._serialized_data is None:
            self._serialized_data = self._serialize(*args, **kwargs)

        return self._serialized_data
