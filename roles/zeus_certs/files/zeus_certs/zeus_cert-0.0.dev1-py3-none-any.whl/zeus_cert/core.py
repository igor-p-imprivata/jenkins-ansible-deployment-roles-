# core.py
import ctypes
from ctypes import wintypes
from functools import partial
from zeus_utils import SingletonMeta
from zeus_win32_utils import raise_windows_error
from .crypt32 import (
    CertEnumSystemStore, CertEnumSystemStoreLocation, CertEnumPhysicalStore,
    CertStoreLocationID, ASNEncodingType,
    ENUM_ARG, PENUM_ARG, PCERT_SYSTEM_STORE_RELOCATE_PARA,
    PFN_CERT_ENUM_SYSTEM_STORE_LOCATION, PFN_CERT_ENUM_SYSTEM_STORE, PFN_CERT_ENUM_PHYSICAL_STORE,
    CERT_SYSTEM_STORE_MASK, CERT_SYSTEM_STORE_LOCATION_MASK, CERT_SYSTEM_STORE_LOCATION_SHIFT,
    CERT_SYSTEM_STORE_RELOCATE_FLAG, CERT_PHYSICAL_STORE_PREDEFINED_ENUM_FLAG
)
from .stores import CertificateStoreLocation, SystemStore, PhysicalStore
from .certificates import Certificate


def _get_system_name(pv_system_store, dw_flags, p_enum_arg):
    enum_arg = p_enum_arg.contents

    if enum_arg.hKeyBase and (dw_flags & CERT_SYSTEM_STORE_RELOCATE_FLAG) == 0:
        return False

    if dw_flags & CERT_SYSTEM_STORE_RELOCATE_FLAG:
        p_relocate_para = ctypes.cast(pv_system_store, PCERT_SYSTEM_STORE_RELOCATE_PARA)
        return p_relocate_para.pwszSystemStore

    return ctypes.cast(pv_system_store, wintypes.LPCWSTR).value


class CertificateAPI(metaclass=SingletonMeta):

    def __init__(self):
        self.__store_locations = {}
        self.__stores_enumerated = False

    def _enum_sys_callback(self, location, pv_system_store, dw_flags, p_store_info, pv_reserved,
                           pv_arg):
        p_enum_arg = ctypes.cast(pv_arg, PENUM_ARG)
        enum_arg = p_enum_arg.contents
        store_name = _get_system_name(pv_system_store, dw_flags, p_enum_arg)

        store = SystemStore(
            cert_api=self,
            location=location,
            name=store_name
        )

        location.add_store(store)

        dw_flags &= CERT_SYSTEM_STORE_MASK
        dw_flags |= enum_arg.dwFlags & ~CERT_SYSTEM_STORE_MASK

        CertEnumPhysicalStore(
            pv_system_store,
            dw_flags,
            p_enum_arg,
            PFN_CERT_ENUM_PHYSICAL_STORE(partial(self._enum_phys_callback, location))
        )

        return True

    def _enum_phys_callback(self, location, pv_system_store, dw_flags, pwsz_store_name,
                            p_store_info, pv_reserved, pv_arg):
        p_enum_arg = ctypes.cast(pv_arg, PENUM_ARG)
        store_name = _get_system_name(pv_system_store, dw_flags, p_enum_arg)

        if not dw_flags & CERT_PHYSICAL_STORE_PREDEFINED_ENUM_FLAG:
            store = PhysicalStore(
                cert_api=self,
                location=location,
                name=store_name
            )

            location.add_store(store)

        return True

    def _enum_loc_callback(self, store_location, dw_flags, pv_reserved, pv_arg):
        p_enum_arg = ctypes.cast(pv_arg, PENUM_ARG)
        enum_arg = p_enum_arg.contents

        location = CertificateStoreLocation(
            cert_api=self,
            name=store_location
        )

        self.__store_locations[store_location.lower()] = location

        dw_flags &= CERT_SYSTEM_STORE_MASK
        dw_flags |= enum_arg.dwFlags & ~CERT_SYSTEM_STORE_LOCATION_MASK

        CertEnumSystemStore(
            dw_flags,
            ctypes.cast(enum_arg.pvStoreLocationPara, ctypes.c_void_p),
            p_enum_arg,
            PFN_CERT_ENUM_SYSTEM_STORE(partial(self._enum_sys_callback, location))
        )

        return True

    def _ensure_stores_enumerated(self):
        if not self.__stores_enumerated:
            self.enum_certificate_stores()

    def _clear_store_locations(self):
        for location in self.__store_locations.values():
            location.clear()

        self.__store_locations.clear()

    def iter_store_locations(self):
        self._ensure_stores_enumerated()

        for store_location in self.__store_locations.values():
            yield store_location

    def get_store_location(self, name):
        self._ensure_stores_enumerated()
        return self.__store_locations.get(name.lower())

    def enum_certificate_stores(self, location_id=CertStoreLocationID.CURRENT_USER):
        if location_id not in CertStoreLocationID:
            location_id = CertStoreLocationID(location_id)

        self._clear_store_locations()

        pwsz_store_location_para = wintypes.LPWSTR(None)
        pv_store_location_para = ctypes.cast(pwsz_store_location_para, ctypes.c_void_p)

        dw_flags = wintypes.DWORD(0)
        enum_arg = ENUM_ARG(
            dwFlags=dw_flags,
            hKeyBase=None,
            pvStoreLocationPara=pv_store_location_para,
            fAll=True,
            fVerbose=True
        )

        dw_flags.value &= ~CERT_SYSTEM_STORE_LOCATION_MASK
        dw_flags.value |= \
            (location_id << CERT_SYSTEM_STORE_LOCATION_SHIFT) & CERT_SYSTEM_STORE_LOCATION_MASK

        res = CertEnumSystemStoreLocation(
            dw_flags,
            ctypes.byref(enum_arg),
            PFN_CERT_ENUM_SYSTEM_STORE_LOCATION(self._enum_loc_callback)
        )

        if not res:
            raise_windows_error()

        self.__stores_enumerated = True

    def load_certificate(self, file_path=None, encoded_data=None,
                         encoding_type=ASNEncodingType.X509, store=None, location=None):
        if file_path is None and encoded_data is None:
            raise ValueError('Either file_path or encoded_data must be specified')

        if file_path is not None:
            cert = Certificate.from_file(
                self,
                path=file_path,
                encoding_type=encoding_type,
                location=location,
                store=store
            )

        else:
            cert = Certificate.from_bytes(
                self,
                encoded_data=encoded_data,
                encoding_type=encoding_type,
                location=location,
                store=store
            )

        return cert
