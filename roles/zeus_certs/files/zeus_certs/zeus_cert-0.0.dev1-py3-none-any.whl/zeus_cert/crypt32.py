# crypt32.py
import ctypes
from ctypes import wintypes
from enum import Enum, IntFlag, IntEnum
from zeus_win32_utils import raise_windows_error, ULONG_PTR


CERT_SYSTEM_STORE_MASK = 0xFFFF0000
CERT_SYSTEM_STORE_RELOCATE_FLAG = 0x80000000
CERT_SYSTEM_STORE_LOCATION_MASK = 0x00FF0000
CERT_SYSTEM_STORE_LOCATION_SHIFT = 16
CERT_PHYSICAL_STORE_PREDEFINED_ENUM_FLAG = 0x1

CERT_STORE_SAVE_AS_STORE = 1
CERT_STORE_SAVE_AS_PKCS7 = 2

CERT_STORE_SAVE_TO_FILE = 1
CERT_STORE_SAVE_TO_MEMORY = 2

CERT_STORE_PROV_MEMORY = 2
CERT_STORE_PROV_FILENAME = 8

CRYPT_ASN_ENCODING = 0x00000001
CRYPT_NDR_ENCODING = 0x00000002
X509_ASN_ENCODING = 0x00000001
X509_NDR_ENCODING = 0x00000002
PKCS_7_ASN_ENCODING = 0x00010000
PKCS_7_NDR_ENCODING = 0x00020000

HCERTSTORE = ctypes.c_void_p
HCRYPTMSG = ctypes.c_void_p
HCRYPTPROV_LEGACY = ULONG_PTR


class CertStoreLocationID(IntFlag):
    CURRENT_USER = 1
    LOCAL_MACHINE = 2
    CURRENT_SERVICE = 4
    SERVICES = 5
    USERS = 6
    CURRENT_USER_GROUP_POLICY = 7
    LOCAL_MACHINE_GROUP_POLICY = 8
    LOCAL_MACHINE_ENTERPRISE = 9


class CertStoreProvider(Enum):
    SYSTEM = 'System'
    MEMORY = 'Memory'
    FILE_NAME = 'File'


class CertNameType(IntEnum):
    EMAIL = 1
    RDN = 2
    ATTR = 3
    SIMPLE_DISPLAY = 4
    FRIENDLY_DISPLAY = 5
    DNS = 6
    URL = 7
    UPN = 8


class CertNameFlags(IntFlag):
    ISSUER = 0x1
    DISABLE_IE4_UTF8 = 0x00010000
    SEARCH_ALL_NAMES = 0x2
    STR_ENABLE_PUNYCODE = 0x00200000


class CertPropertyID(IntEnum):
    KEY_PROV_HANDLE = 1
    KEY_PROV_INFO = 2
    SHA1_HASH = 3
    MD5_HASH = 4
    KEY_CONTEXT = 5
    KEY_SPEC = 6
    IE30_RESERVED = 7
    PUBKEY_HASH_RESERVED = 8
    ENHKEY_USAGE = 9
    NEXT_UPDATE_LOCATION = 10
    FRIENDLY_NAME = 11
    PVK_FILE = 12
    DESCRIPTION = 13
    ACCESS_STATE = 14
    SIGNATURE_HASH = 15
    SMART_CARD_DATA = 16
    EFS = 17
    FORTEZZA_DATA = 18
    ARCHIVED = 19
    KEY_IDENTIFIER = 20
    AUTO_ENROLL = 21
    PUBKEY_ALG_PARA = 22
    CROSS_CERT_DIST_POINTS = 23
    ISSUER_PUBLIC_KEY_MD5_HASH = 24
    SUBJECT_PUBLIC_KEY_MD5_HASH = 25
    ENROLLMENT = 26
    DATE_STAMP = 27
    ISSUER_SERIAL_NUMBER_MD5_HASH = 28
    SUBJECT_NAME_MD5_HASH = 29
    EXTENDED_ERROR_INFO = 30
    RENEWAL = 64
    ARCHIVED_KEY_HASH = 65
    AUTO_ENROLL_RETRY = 66
    AIA_URL_RETRIEVED = 67
    AUTHORITY_INFO_ACCESS = 68
    BACKED_UP = 69
    OCSP_RESPONSE = 70
    REQUEST_ORIGINATOR = 71
    SOURCE_LOCATION = 72
    SOURCE_URL = 73
    NEW_KEY = 74
    OCSP_CACHE_PREFIX = 75
    SMART_CARD_ROOT_INFO = 76
    NO_AUTO_EXPIRE_CHECK = 77
    NCRYPT_KEY_HANDLE = 78
    HCRYPTPROV_OR_NCRYPT_KEY_HANDLE = 79
    SUBJECT_INFO_ACCESS = 80
    CA_OCSP_AUTHORITY_INFO_ACCESS = 81
    CA_DISABLE_CRL = 82
    ROOT_PROGRAM_CERT_POLICIES = 83
    ROOT_PROGRAM_NAME_CONSTRAINTS = 84
    SUBJECT_OCSP_AUTHORITY_INFO_ACCESS = 85
    SUBJECT_DISABLE_CRL = 86
    CEP = 87
    SIGN_HASH_CNG_ALG = 89
    SCARD_PIN_ID = 90
    SCARD_PIN_INFO = 91
    SUBJECT_PUB_KEY_BIT_LENGTH = 92
    PUB_KEY_CNG_ALG_BIT_LENGTH = 93
    ISSUER_PUB_KEY_BIT_LENGTH = 94
    ISSUER_CHAIN_SIGN_HASH_CNG_ALG = 95
    ISSUER_CHAIN_PUB_KEY_CNG_ALG_BIT_LENGTH = 96
    NO_EXPIRE_NOTIFICATION = 97
    AUTH_ROOT_SHA256_HASH = 98
    NCRYPT_KEY_HANDLE_TRANSFER = 99
    HCRYPTPROV_TRANSFER = 100
    SMART_CARD_READER = 101
    SEND_AS_TRUSTED_ISSUER = 102
    KEY_REPAIR_ATTEMPTED = 103
    DISALLOWED_FILETIME = 104
    ROOT_PROGRAM_CHAIN_POLICIES = 105
    SMART_CARD_READER_NON_REMOVABLE = 106
    SHA256_HASH = 107
    SCEP_SERVER_CERTS = 108
    SCEP_RA_SIGNATURE_CERT = 109
    SCEP_RA_ENCRYPTION_CERT = 110
    SCEP_CA_CERT = 111
    SCEP_SIGNER_CERT = 112
    SCEP_NONCE = 113
    SCEP_ENCRYPT_HASH_CNG_ALG = 114
    SCEP_FLAGS = 115
    SCEP_GUID = 116
    SERIALIZABLE_KEY_CONTEXT = 117


class ASNEncodingType(IntFlag):
    PKCS_7 = PKCS_7_ASN_ENCODING
    X509 = X509_ASN_ENCODING


class CryptStringFormat(IntFlag):
    BASE_64_HEADER = 0x00000000
    BASE_64 = 0x00000001
    BINARY = 0x00000002
    BASE_64_REQUEST_HEADER = 0x00000003
    HEX = 0x00000004
    HEX_ASCII = 0x00000005
    BASE_64_ANY = 0x00000006
    ANY = 0x00000007
    HEX_ANY = 0x00000008
    BASE_64_X509_CRL_HEADER = 0x00000009
    HEX_ADDR = 0x0000000a
    HEX_ASCII_ADDR = 0x0000000b
    HEX_RAW = 0x0000000c
    STRICT = 0x20000000


class CertStoreFlags(IntFlag):
    NO_CRYPT_RELEASE = 0x00000001
    SET_LOCALIZED_NAME = 0x00000002
    DEFER_CLOSE_UNTIL_LAST_FREE = 0x00000004
    DELETE = 0x00000010
    UNSAFE_PHYSICAL = 0x00000020
    SHARE_STORE = 0x00000040
    SHARE_CONTEXT = 0x00000080
    MANIFOLD = 0x00000100
    ENUM_ARCHIVED = 0x00000200
    UPDATE_KEYID = 0x00000400
    BACKUP_RESTORE = 0x00000800
    READONLY = 0x00008000
    OPEN_EXISTING = 0x00004000
    CREATE_NEW = 0x00002000
    MAXIMUM_ALLOWED = 0x00001000


class CRYPT_INTEGER_BLOB(ctypes.Structure):
    _fields_ = [
        ('cbData', wintypes.DWORD),
        ('pbData', ctypes.POINTER(wintypes.BYTE))
    ]


CRYPT_DATA_BLOB = CRYPT_INTEGER_BLOB
CRYPT_NAME_BLOB = CRYPT_INTEGER_BLOB
CRYPT_OBJID_BLOB = CRYPT_INTEGER_BLOB
CRYPT_BIT_BLOB = CRYPT_INTEGER_BLOB
CRYPT_ATTR_BLOB = CRYPT_INTEGER_BLOB

PCRYPT_ATTR_BLOB = ctypes.POINTER(CRYPT_ATTR_BLOB)


class CERT_SYSTEM_STORE_INFO(ctypes.Structure):
    _fields_ = [
        ('cbSize', wintypes.DWORD)
    ]


class CERT_SYSTEM_STORE_RELOCATE_PARA(ctypes.Structure):
    _fields_ = [
        ('hKeyBase', wintypes.HKEY),
        ('pvBase', ctypes.c_void_p),
        ('pvSystemStore', ctypes.c_void_p),
        ('pszSystemStore', wintypes.LPCSTR),
        ('pwszSystemStore', wintypes.LPCWSTR)
    ]


class CERT_PHYSICAL_STORE_INFO(ctypes.Structure):
    _fields_ = [
        ('cbSize', wintypes.DWORD),
        ('pszOpenStoreProvider', wintypes.LPSTR),
        ('dwOpenEncodingType', wintypes.DWORD),
        ('dwOpenFlags', wintypes.DWORD),
        ('OpenParameters', CRYPT_DATA_BLOB),
        ('dwFlags', wintypes.DWORD),
        ('dwPriority', wintypes.DWORD)
    ]


class ENUM_ARG(ctypes.Structure):
    _fields_ = [
        ('fAll', wintypes.BOOL),
        ('fVerbose', wintypes.BOOL),
        ('dwFlags', wintypes.DWORD),
        ('pvStoreLocationPara', ctypes.c_void_p),
        ('hKeyBase', wintypes.HKEY)
    ]


class CERT_EXTENSION(ctypes.Structure):
    _fields_ = [
        ('pszObjId', wintypes.LPSTR),
        ('fCritical', wintypes.BOOL),
        ('Value', CRYPT_OBJID_BLOB)
    ]

PCERT_EXTENSION = ctypes.POINTER(CERT_EXTENSION)


class CRYPT_ALGORITHM_IDENTIFIER(ctypes.Structure):
    _fields_ = [
        ('pszObjId', wintypes.LPSTR),
        ('Parameters', CRYPT_OBJID_BLOB)
    ]


class CERT_PUBLIC_KEY_INFO(ctypes.Structure):
    _fields_ = [
        ('Algorithm', CRYPT_ALGORITHM_IDENTIFIER),
        ('PublicKey', CRYPT_BIT_BLOB)
    ]


class CERT_INFO(ctypes.Structure):
    _fields_ = [
        ('dwVersion', wintypes.DWORD),
        ('SerialNumber', CRYPT_INTEGER_BLOB),
        ('SignatureAlgorithm', CRYPT_ALGORITHM_IDENTIFIER),
        ('Issuer', CRYPT_NAME_BLOB),
        ('NotBefore', wintypes.FILETIME),
        ('NotAfter', wintypes.FILETIME),
        ('Subject', CRYPT_NAME_BLOB),
        ('SubjectPublicKeyInfo', CERT_PUBLIC_KEY_INFO),
        ('IssuerUniqueId', CRYPT_BIT_BLOB),
        ('SubjectUniqueId', CRYPT_BIT_BLOB),
        ('cExtension', wintypes.DWORD),
        ('rgExtension', PCERT_EXTENSION)
    ]

PCERT_INFO = ctypes.POINTER(CERT_INFO)


class CERT_CONTEXT(ctypes.Structure):
    _fields_ = [
        ('dwCertEncodingType', wintypes.DWORD),
        ('pbCertEncoded', ctypes.POINTER(wintypes.BYTE)),
        ('cbCertEncoded', wintypes.DWORD),
        ('pCertInfo', PCERT_INFO),
        ('hCertStore', HCERTSTORE)
    ]


class CRYPT_KEY_PROV_PARAM(ctypes.Structure):
    _fields_ = [
        ('dwParam', wintypes.DWORD),
        ('pbData', ctypes.POINTER(wintypes.BYTE)),
        ('cbData', wintypes.DWORD),
        ('dwFlags', wintypes.DWORD)
    ]

PCRYPT_KEY_PROV_PARAM = ctypes.POINTER(CRYPT_KEY_PROV_PARAM)


class CRYPT_KEY_PROV_INFO(ctypes.Structure):
    _fields_ = [
        ('pwszContainerName', wintypes.LPWSTR),
        ('pwszProvName', wintypes.LPWSTR),
        ('dwProvType', wintypes.DWORD),
        ('dwFlags', wintypes.DWORD),
        ('cProvParam', wintypes.DWORD),
        ('rgProvParam', PCRYPT_KEY_PROV_PARAM),
        ('dwKeySpec', wintypes.DWORD)
    ]


class CTL_USAGE(ctypes.Structure):
    _fields_ = [
        ('cUsageIdentifier', wintypes.DWORD),
        ('rgpszUsageIdentifier', ctypes.POINTER(wintypes.LPSTR))
    ]

CERT_ENHKEY_USAGE = CTL_USAGE


class CRYPT_ATTRIBUTE(ctypes.Structure):
    _fields_ = [
        ('pszObjId', wintypes.LPSTR),
        ('cValue', wintypes.DWORD),
        ('rgValue', PCRYPT_ATTR_BLOB)
    ]

PCRYPT_ATTRIBUTE = ctypes.POINTER(CRYPT_ATTRIBUTE)


class CTL_ENTRY(ctypes.Structure):
    _fields_ = [
        ('SubjectIdentifier', CRYPT_DATA_BLOB),
        ('cAttribute', wintypes.DWORD),
        ('rgAttribute', PCRYPT_ATTRIBUTE)
    ]

PCTL_ENTRY = ctypes.POINTER(CTL_ENTRY)


class CTL_INFO(ctypes.Structure):
    _fields_ = [
        ('dwVersion', wintypes.DWORD),
        ('SubjectUsage', CTL_USAGE),
        ('ListIdentifier', CRYPT_DATA_BLOB),
        ('SequenceNumber', CRYPT_INTEGER_BLOB),
        ('ThisUpdate', wintypes.FILETIME),
        ('NextUpdate', wintypes.FILETIME),
        ('SubjectAlgorithm', CRYPT_ALGORITHM_IDENTIFIER),
        ('cCTLEntry', wintypes.DWORD),
        ('rgCTLEntry', PCTL_ENTRY),
        ('cExtension', wintypes.DWORD),
        ('rgExtension', PCERT_EXTENSION)
    ]

PCTL_INFO = ctypes.POINTER(CTL_INFO)


class CTL_CONTEXT(ctypes.Structure):
    _fields_ = [
        ('dwMsgAndCertEncodingType', wintypes.DWORD),
        ('pbCtlEncoded', ctypes.POINTER(wintypes.BYTE)),
        ('cbCtlEncoded', wintypes.DWORD),
        ('pCtlInfo', PCTL_INFO),
        ('hCertStore', HCERTSTORE),
        ('hCryptMsg', HCRYPTMSG),
        ('pbCtlContent', ctypes.POINTER(wintypes.BYTE)),
        ('cbCtlContent', wintypes.DWORD)
    ]

PCTL_CONTEXT = ctypes.POINTER(CTL_CONTEXT)

PCTL_USAGE = ctypes.POINTER(CTL_USAGE)
PCERT_ENHKEY_USAGE = ctypes.POINTER(CERT_ENHKEY_USAGE)

PCRYPT_KEY_PROV_INFO = ctypes.POINTER(CRYPT_KEY_PROV_INFO)

PCERT_CONTEXT = ctypes.POINTER(CERT_CONTEXT)

PCERT_SYSTEM_STORE_INFO = ctypes.POINTER(CERT_SYSTEM_STORE_INFO)
PCERT_PHYSICAL_STORE_INFO = ctypes.POINTER(CERT_PHYSICAL_STORE_INFO)
PCERT_SYSTEM_STORE_RELOCATE_PARA = ctypes.POINTER(CERT_SYSTEM_STORE_RELOCATE_PARA)
PENUM_ARG = ctypes.POINTER(ENUM_ARG)


PFN_CERT_ENUM_SYSTEM_STORE = ctypes.WINFUNCTYPE(
    wintypes.BOOL,
    ctypes.c_void_p,
    wintypes.DWORD,
    PCERT_SYSTEM_STORE_INFO,
    ctypes.c_void_p,
    ctypes.c_void_p
)

PFN_CERT_ENUM_SYSTEM_STORE_LOCATION = ctypes.WINFUNCTYPE(
    wintypes.BOOL,
    wintypes.LPCWSTR,
    wintypes.DWORD,
    ctypes.c_void_p,
    ctypes.c_void_p
)

PFN_CERT_ENUM_PHYSICAL_STORE = ctypes.WINFUNCTYPE(
    wintypes.BOOL,
    ctypes.c_void_p,
    wintypes.DWORD,
    wintypes.LPCWSTR,
    PCERT_SYSTEM_STORE_INFO,
    ctypes.c_void_p,
    ctypes.c_void_p

)


crypt32 = ctypes.windll.Crypt32

CertOpenSystemStore = crypt32.CertOpenSystemStoreA
CertOpenSystemStore.argtypes = (
    HCRYPTPROV_LEGACY,
    wintypes.LPCSTR
)
CertOpenSystemStore.restype = HCERTSTORE

CertCloseStore = crypt32.CertCloseStore
CertCloseStore.argtypes = (
    HCERTSTORE,
    wintypes.DWORD
)
CertCloseStore.restype = wintypes.BOOL

CertEnumSystemStore = crypt32.CertEnumSystemStore
CertEnumSystemStore.argtypes = (
    wintypes.DWORD,
    ctypes.c_void_p,
    ctypes.c_void_p,
    PFN_CERT_ENUM_SYSTEM_STORE
)
CertEnumSystemStore.restype = wintypes.BOOL

CertEnumSystemStoreLocation = crypt32.CertEnumSystemStoreLocation
CertEnumSystemStoreLocation.argtypes = (
    wintypes.DWORD,
    ctypes.c_void_p,
    PFN_CERT_ENUM_SYSTEM_STORE_LOCATION
)
CertEnumSystemStoreLocation.restype = wintypes.BOOL

CertEnumPhysicalStore = crypt32.CertEnumPhysicalStore
CertEnumPhysicalStore.argtypes = (
    ctypes.c_void_p,
    wintypes.DWORD,
    ctypes.c_void_p,
    PFN_CERT_ENUM_PHYSICAL_STORE
)
CertEnumPhysicalStore.restype = wintypes.BOOL

CertEnumCertificatesInStore = crypt32.CertEnumCertificatesInStore
CertEnumCertificatesInStore.argtypes = (
    HCERTSTORE,
    PCERT_CONTEXT
)
CertEnumCertificatesInStore.restype = PCERT_CONTEXT

CertGetNameString = crypt32.CertGetNameStringA
CertGetNameString.argtypes = (
    PCERT_CONTEXT,
    wintypes.DWORD,
    wintypes.DWORD,
    ctypes.c_void_p,
    wintypes.LPSTR,
    wintypes.DWORD
)
CertGetNameString.restype = wintypes.DWORD

CertEnumCertificateContextProperties = crypt32.CertEnumCertificateContextProperties
CertEnumCertificateContextProperties.argtypes = (
    PCERT_CONTEXT,
    wintypes.DWORD
)
CertEnumCertificateContextProperties.restype = wintypes.DWORD

CertGetCertificateContextProperty = crypt32.CertGetCertificateContextProperty
CertGetCertificateContextProperty.argtypes = (
    PCERT_CONTEXT,
    wintypes.DWORD,
    ctypes.c_void_p,
    ctypes.POINTER(wintypes.DWORD)
)
CertGetCertificateContextProperty.restype = wintypes.BOOL


CertSerializeCertificateStoreElement = crypt32.CertSerializeCertificateStoreElement
CertSerializeCertificateStoreElement.argtypes = (
    PCERT_CONTEXT,
    wintypes.DWORD,
    ctypes.POINTER(wintypes.BYTE),
    ctypes.POINTER(wintypes.DWORD)
)
CertSerializeCertificateStoreElement.restype = wintypes.BOOL

CertDuplicateCertificateContext = crypt32.CertDuplicateCertificateContext
CertDuplicateCertificateContext.argtypes = (PCERT_CONTEXT,)
CertDuplicateCertificateContext.restype = PCERT_CONTEXT

CertFreeCertificateContext = crypt32.CertFreeCertificateContext
CertFreeCertificateContext.argtypes = (PCERT_CONTEXT,)
CertFreeCertificateContext.restype = wintypes.BOOL

CertEnumCTLsInStore = crypt32.CertEnumCTLsInStore
CertEnumCTLsInStore.argtypes = (
    HCERTSTORE,
    PCTL_CONTEXT
)
CertEnumCTLsInStore.restype = PCTL_CONTEXT

CertDuplicateCTLContext = crypt32.CertDuplicateCTLContext
CertDuplicateCTLContext.argtypes = (PCTL_CONTEXT,)
CertDuplicateCTLContext.restype = PCTL_CONTEXT

CertFreeCTLContext = crypt32.CertFreeCTLContext
CertFreeCTLContext.argtypes = (PCTL_CONTEXT,)
CertFreeCTLContext.restype = wintypes.BOOL

CertSaveStore = crypt32.CertSaveStore
CertSaveStore.argtypes = (
    HCERTSTORE,
    wintypes.DWORD,
    wintypes.DWORD,
    wintypes.DWORD,
    ctypes.c_void_p,
    wintypes.DWORD
)
CertSaveStore.restype = wintypes.BOOL

CertCreateCertificateContext = crypt32.CertCreateCertificateContext
CertCreateCertificateContext.argtypes = (
    wintypes.DWORD,
    ctypes.POINTER(wintypes.BYTE),
    wintypes.DWORD
)
CertCreateCertificateContext.restype = PCERT_CONTEXT

CryptStringToBinary = crypt32.CryptStringToBinaryA
CryptStringToBinary.argtypes = (
    wintypes.LPCSTR,
    wintypes.DWORD,
    wintypes.DWORD,
    ctypes.POINTER(wintypes.BYTE),
    ctypes.POINTER(wintypes.DWORD),
    ctypes.POINTER(wintypes.DWORD),
    ctypes.POINTER(wintypes.DWORD),
)
CryptStringToBinary.restype = wintypes.BOOL

CertOpenStore = crypt32.CertOpenStore
CertOpenStore.argtypes = (
    wintypes.LPCSTR,
    wintypes.DWORD,
    HCRYPTPROV_LEGACY,
    wintypes.DWORD,
    ctypes.c_void_p
)
CertOpenStore.restype = HCERTSTORE


def crypt_string_to_binary(data, fmt=CryptStringFormat.ANY):
    if fmt not in CryptStringFormat:
        fmt = CryptStringFormat(fmt)

    if isinstance(data, str):
        data = data.encode('utf-8', 'strict')

    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(f'Invalid type for data: "{type(data).__name__}"')

    size = wintypes.DWORD(0)

    buffer = None

    res = CryptStringToBinary(
        data,
        len(data),
        fmt.value,
        buffer,
        ctypes.byref(size),
        None,
        None
    )

    if not res:
        raise_windows_error()

    buffer = (wintypes.BYTE * size.value)()

    res = CryptStringToBinary(
        data,
        len(data),
        fmt.value,
        ctypes.cast(buffer, ctypes.POINTER(wintypes.BYTE)),
        ctypes.byref(size),
        None,
        None
    )

    if not res:
        raise_windows_error()

    return buffer
