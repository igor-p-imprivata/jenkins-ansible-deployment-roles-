# stores.py
import os
import pickle
import ctypes
from ctypes import wintypes
from zeus_win32_utils import raise_windows_error
from zeus_win32_utils.error_codes import ERROR_INVALID_PARAMETER, E_INVALIDARG
from .crypt32 import (
    CertCloseStore, CertOpenSystemStore, CertEnumCertificatesInStore, CertOpenStore,
    CertDuplicateCertificateContext, CertSaveStore, ASNEncodingType, CertStoreFlags,
    HCRYPTPROV_LEGACY, PCERT_CONTEXT, CRYPT_DATA_BLOB, CERT_STORE_SAVE_AS_PKCS7,
    CERT_STORE_SAVE_TO_MEMORY, CERT_STORE_PROV_MEMORY, CERT_STORE_PROV_FILENAME
)
from .base import CertAPIBase, CertAPISerializableBase
from .certificates import Certificate, CertificateTrustList


H_PROV = HCRYPTPROV_LEGACY(0)
DEFAULT_ASN_ENCODING = ASNEncodingType.PKCS_7 | ASNEncodingType.X509


class CertificateStoreLocation(CertAPIBase):
    @classmethod
    def from_file(cls, path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    def __init__(self, cert_api, name):
        super(CertificateStoreLocation, self).__init__(cert_api=cert_api)
        self.name = name
        self.__stores_by_name = {}

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    def __iter__(self):
        yield from self.iter_stores()

    def __getitem__(self, item):
        return self.__stores_by_name[item.lower()]

    def __contains__(self, item):
        if not isinstance(item, CertificateStore):
            return False

        return item in set(self.iter_stores())

    def __getstate__(self):
        it = self.__stores_by_name.items()
        store_map = {name: store for name, store in it if store.serialize() is not None}

        return {
            'name': self.name,
            'stores_by_name': store_map
        }

    def __setstate__(self, state):
        self.name = state['name']
        self.__stores_by_name = state['stores_by_name']

        for store in self.__stores_by_name.values():
            store.location = self

    def clear(self):
        for store in self.__stores_by_name.values():
            store.close()

        self.__stores_by_name.clear()

    def add_store(self, store):
        if not isinstance(store, CertificateStore):
            raise TypeError(f'store must be a valid {CertificateStore.__name__} instance')

        self.__stores_by_name[store.name.lower()] = store

    def iter_stores(self):
        for store in self.__stores_by_name.values():
            yield store

    def get_store(self, name):
        return self.__stores_by_name.get(name.lower())

    def to_file(self, path):
        with open(path, 'wb') as f:
            pickle.dump(self, f)

        return os.path.abspath(path)


class CertificateStore(CertAPISerializableBase):
    @classmethod
    def from_file(cls, file_path, encoding_type=ASNEncodingType.X509 | ASNEncodingType.PKCS_7):
        if encoding_type not in ASNEncodingType:
            encoding_type = ASNEncodingType(encoding_type)

        file_path = os.path.abspath(file_path)
        print(file_path)
        file_path = file_path.encode('utf-8', 'strict')

        h_certstore = CertOpenStore(
            ctypes.cast(CERT_STORE_PROV_FILENAME, wintypes.LPCSTR),
            encoding_type.value,
            H_PROV,
            CertStoreFlags.OPEN_EXISTING | CertStoreFlags.READONLY,
            file_path
        )

        if not h_certstore:
            raise_windows_error()

    def __init__(self, cert_api, location, name):
        super(CertificateStore, self).__init__(cert_api=cert_api)
        self._location = location
        self.name = name
        self._handle = None
        self.__certificates = []
        self.__certificates_enumerated = False
        # self.__trust_lists = []
        # self.__trust_lists_enumerated = False

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", location="{self.location.name}")'

    def __del__(self):
        self.close()

    def __iter__(self):
        yield from self.iter_certificates()

    def __getstate__(self):
        self._ensure_certificates_enumerated()
        state = super(CertificateStore, self).__getstate__()
        state.update(
            name=self.name,
            certificates=self.__certificates
        )
        return state

    def __setstate__(self, state):
        super(CertificateStore, self).__setstate__(state)
        self._location = None
        self._handle = None
        self.name = state['name']
        self.__certificates = state['certificates']

        for certificate in self.__certificates:
            certificate.store = self

        self.__certificates_enumerated = True

    @property
    def location(self):
        return self._location

    @location.setter
    def location(self, value):
        self._location = value

        for certificate in self.__certificates:
            certificate.location = value

    def _ensure_certificates_enumerated(self):
        if not self.__certificates_enumerated:
            self.enumerate_certificates()

    # def _ensure_trust_lists_enumerated(self):
    #     if not self.__trust_lists_enumerated:
    #         self.enumerate_trust_lists()

    def _serialize(self, encoding=DEFAULT_ASN_ENCODING, save_as=CERT_STORE_SAVE_AS_PKCS7):
        if self.open():
            if encoding not in ASNEncodingType:
                encoding = ASNEncodingType(encoding)

            blob = CRYPT_DATA_BLOB(cbData=0, pbData=None)

            res = CertSaveStore(
                self._handle,
                encoding.value,
                save_as,
                CERT_STORE_SAVE_TO_MEMORY,
                ctypes.cast(ctypes.byref(blob), ctypes.c_void_p),
                0
            )

            if not res:
                raise_windows_error()

            data = (ctypes.c_ubyte * blob.cbData)()
            blob.pbData = ctypes.cast(data, ctypes.POINTER(wintypes.BYTE))

            res = CertSaveStore(
                self._handle,
                encoding.value,
                save_as,
                CERT_STORE_SAVE_TO_MEMORY,
                ctypes.cast(ctypes.byref(blob), ctypes.c_void_p),
                0
            )

            if not res:
                raise_windows_error()

            return bytes(data[:blob.cbData])

    def open(self, force=False):
        if self._handle is None or force:

            if force:
                self.close()

            h_cert_store = CertOpenSystemStore(
                H_PROV,
                self.name.encode('utf-8', 'strict')
            )

            if h_cert_store is None:
                raise_windows_error(ignore_codes=(ERROR_INVALID_PARAMETER, E_INVALIDARG))
                return

            self._handle = h_cert_store

        return self._handle is not None

    def close(self):
        if self._handle is not None:
            CertCloseStore(self._handle, 0)
            self._handle = None

    def enumerate_certificates(self):
        if self.open():
            p_cert_context = CertEnumCertificatesInStore(self._handle, PCERT_CONTEXT())

            while p_cert_context:

                certificate = Certificate(
                    cert_api=self._cert_api,
                    location=self.location,
                    store=self,
                    p_ctx=CertDuplicateCertificateContext(p_cert_context)
                )

                self.__certificates.append(certificate)

                p_cert_context = CertEnumCertificatesInStore(self._handle, p_cert_context)

        self.__certificates_enumerated = True

    def iter_certificates(self):
        self._ensure_certificates_enumerated()

        for certificate in self.__certificates:
            yield certificate

    # def enumerate_trust_lists(self):
    #     if self.open():
    #         p_ctl_context = CertEnumCTLsInStore(self._handle, PCTL_CONTEXT())
    #
    #         while p_ctl_context:
    #             trust_list = CertificateTrustList(
    #                 cert_api=self._cert_api,
    #                 location=self.location,
    #                 store=self,
    #                 p_ctx=CertDuplicateCTLContext(p_ctl_context)
    #             )
    #
    #             self.__trust_lists.append(trust_list)
    #
    #             p_ctl_context = CertEnumCTLsInStore(self._handle, p_ctl_context)
    #
    #     self.__trust_lists_enumerated = True
    #
    # def iter_trust_lists(self):
    #     self._ensure_trust_lists_enumerated()
    #
    #     for trust_list in self.__trust_lists:
    #         yield trust_list


class SystemStore(CertificateStore):
    pass


class PhysicalStore(CertificateStore):
    pass
