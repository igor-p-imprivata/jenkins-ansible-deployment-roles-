# api.py
from .core import CertificateAPI
from .stores import CertificateStoreLocation
from .crypt32 import ASNEncodingType


def get_store_location(name):
    return CertificateAPI().get_store_location(name)


def store_location_from_file(path):
    return CertificateStoreLocation.from_file(path)


def iter_store_locations():
    yield from CertificateAPI().iter_store_locations()


def iter_stores(location=None):
    cert_api = CertificateAPI()

    if location is not None:
        store_locations = []
        store_location = cert_api.get_store_location(location)

        if store_location is not None:
            store_locations.append(store_location)

    else:
        store_locations = cert_api.iter_store_locations()

    for store_location in store_locations:
        yield from store_location.iter_stores()


def load_certificate(file_path=None, encoded_data=None, encoding_type=ASNEncodingType.X509,
                     store=None, location=None):
    return CertificateAPI().load_certificate(
        file_path=file_path,
        encoded_data=encoded_data,
        encoding_type=encoding_type,
        store=store,
        location=location
    )
