# core.py
import ctypes
import win32ts
import win32file
import win32security
import win32process
import win32api
import win32con
import pywintypes
from functools import partial
from ctypes import wintypes
from zeus_utils import c_array_from_buffer
from .error_codes import ERROR_MORE_DATA
from ._wintypes import (
    va_list, va_list_p, SUCCEEDED, GUID, STARTUPINFOW, STARTUPINFOA, LPSTARTUPINFOW, PROCESS_INFORMATION,
    LPPROCESS_INFORMATION,
)
from .enums import (
    FolderId, Desktops, SidType, AccessTypes, FileShare, FileAttributes, CreationDisposition,
    ProcessorArchitecture, FormatFlags, ComputerNameFormat, DESKTOP_NAME_PREFIX,
)


NO_MULTIPLE_TRUSTEE = 0
TRUSTEE_IS_IMPERSONATE = 1
WINSTA_ALL_ACCESS = 0x37F

FORMAT_MESSAGE_ALLOCATE_BUFFER = 0x100
FORMAT_MESSAGE_FROM_SYSTEM = 0x1000
FORMAT_MESSAGE_FROM_STRING = 0x400
FORMAT_MESSAGE_FROM_HMODULE = 0x800
FORMAT_MESSAGE_ARGUMENT_ARRAY = 0x2000

LOGON_WITH_PROFILE = 0x00000001
LOGON_NETCREDENTIALS_ONLY = 0x00000002

CREATE_UNICODE_ENVIRONMENT = 0x00000400

PY_SI_PROPERTY_NAMES = (
    'lpDesktop', 'lpTitle', 'dwX', 'dwY', 'dwXSize', 'dwYSize', 'dwXCountChars', 'dwYCountChars',
    'dwFillAttribute', 'dwFlags', 'wShowWindow', 'hStdInput', 'hStdOutput', 'hStdError'
)


# KERNEL32.DLL
kernel32 = ctypes.windll.kernel32

GetDriveType = kernel32.GetDriveTypeA
GetDriveType.argtypes = (wintypes.LPCSTR,)
GetDriveType.restype = wintypes.UINT

GetCurrentProcess = kernel32.GetCurrentProcess
GetCurrentProcess.restype = wintypes.HANDLE

FormatMessage = kernel32.FormatMessageA
FormatMessage.argtypes = (
    wintypes.DWORD,
    wintypes.LPCVOID,
    wintypes.DWORD,
    wintypes.DWORD,
    wintypes.LPSTR,
    wintypes.DWORD,
    va_list_p
)
FormatMessage.restype = wintypes.DWORD

LoadLibrary = kernel32.LoadLibraryA
LoadLibrary.argtypes = (wintypes.LPCSTR,)
LoadLibrary.restype = wintypes.HMODULE

GetComputerNameEx = kernel32.GetComputerNameExA
GetComputerNameEx.argtypes = (
    ctypes.c_int,
    wintypes.LPSTR,
    wintypes.LPDWORD
)
GetComputerNameEx.restype = wintypes.BOOL

GetLastError = kernel32.GetLastError
GetLastError.restype = wintypes.DWORD

LocalFree = kernel32.LocalFree
LocalFree.argtypes = (wintypes.HLOCAL,)
LocalFree.restype = wintypes.HLOCAL

# ADVAPI32.DLL
advapi32 = ctypes.windll.Advapi32

CreateProcessWithLogon = advapi32.CreateProcessWithLogonW
CreateProcessWithLogon.argtypes = (wintypes.LPCWSTR,
                                   wintypes.LPCWSTR,
                                   wintypes.LPCWSTR,
                                   wintypes.DWORD,
                                   wintypes.LPCWSTR,
                                   wintypes.LPWSTR,
                                   wintypes.DWORD,
                                   wintypes.LPVOID,
                                   wintypes.LPCWSTR,
                                   LPSTARTUPINFOW,
                                   LPPROCESS_INFORMATION)
CreateProcessWithLogon.restype = wintypes.BOOL

CreateProcessWithToken = advapi32.CreateProcessWithTokenW
CreateProcessWithToken.argtypes = (wintypes.HANDLE,
                                   wintypes.DWORD,
                                   wintypes.LPCWSTR,
                                   wintypes.LPWSTR,
                                   wintypes.DWORD,
                                   wintypes.LPVOID,
                                   wintypes.LPCWSTR,
                                   LPSTARTUPINFOW,
                                   LPPROCESS_INFORMATION)
CreateProcessWithToken.restype = wintypes.BOOL

OpenProcessToken = advapi32.OpenProcessToken
OpenProcessToken.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.PHANDLE)
OpenProcessToken.restype = wintypes.BOOL

# SHELL32.DLL
shell32 = ctypes.windll.Shell32

SHGetKnownFolderPath = shell32.SHGetKnownFolderPath
SHGetKnownFolderPath.argtypes = (ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
                                 ctypes.POINTER(wintypes.LPWSTR))
SHGetKnownFolderPath.restype = ctypes.HRESULT

# # OLE32.DLL
ole32 = ctypes.windll.Ole32

CoTaskMemFree = ole32.CoTaskMemFree
CoTaskMemFree.argtypes = (wintypes.LPVOID,)

# # USERENV.DLL
userenv = ctypes.windll.Userenv

CreateEnvironmentBlock = userenv.CreateEnvironmentBlock
CreateEnvironmentBlock.argtypes = (ctypes.POINTER(wintypes.LPVOID), wintypes.HANDLE, wintypes.BOOL)
CreateEnvironmentBlock.restype = wintypes.BOOL

# MPR.DLL
mpr = ctypes.windll.mpr

WNetGetConnection = mpr.WNetGetConnectionA
WNetGetConnection.argtypes = (wintypes.LPCSTR, wintypes.LPSTR, wintypes.LPDWORD)
WNetGetConnection.restype = wintypes.DWORD


# CABINET.DLL
# cabinet = ctypes.windll.cabinet
#
# FDIIsCabinet = cabinet.FDIIsCabinet
# FDIIsCabinet.argtypes = ()

def dirty_cast(ptr, data_type):
    return ctypes.cast(ptr, ctypes.POINTER(data_type)).contents


def int_from_bytes(data, offset, size, byteorder='little'):
    return int.from_bytes(data[offset:offset + size], byteorder)


def lpstr2int(lpstr, size):
    print(lpstr.value[:size])


def wcschr(haystack, needle, offset=0):
    index = offset

    while haystack[index] != needle:
        index += 1

    return index


def create_environment_block(token=None, inherit=False):
    if token is None:
        token = wintypes.HANDLE()

        if not OpenProcessToken(GetCurrentProcess(), win32security.TOKEN_QUERY, ctypes.byref(token)):
            raise_windows_error()

    env = wintypes.LPVOID()
    inherit = wintypes.BOOL(inherit)

    if not CreateEnvironmentBlock(ctypes.byref(env), token, inherit):
        raise_windows_error()

    wstr = ctypes.cast(env, wintypes.PWCHAR)
    start = 0
    env = {}

    while True:
        end = wcschr(wstr, '\x00', offset=start)

        if end == start:
            break

        key_val_str = wstr[start:end]
        key, val = key_val_str.rsplit('=', 1)
        env[key] = val

        start = end + 1

    # print(wstr[:end])
    return env


def py_env_to_env(py_env):
    return ''.join(f'{k}={v}\x00' for k, v in py_env.items())


def load_library(lib_file_name):
    h_module = LoadLibrary(lib_file_name.encode('utf-8', 'strict'))

    if h_module is None:
        raise WindowsError(GetLastError(), 'LoadLibrary')

    return h_module


def format_error_message(err_code, source=None, fmt_args=None):
    flags = FormatFlags.ALLOCATE_BUFFER
    lp_msg = wintypes.LPSTR()

    if fmt_args is not None:
        if isinstance(fmt_args, str):
            fmt_args = (fmt_args,)

        if not isinstance(fmt_args, (tuple, list)):
            raise TypeError(f'Invalid type for fmt_args: {type(fmt_args).__name__}')

        enc_args = tuple(map(lambda a: bytearray(a.encode('utf-8', 'strict')), fmt_args))
        fmt_args = (va_list * len(enc_args))()

        for i, enc_arg in enumerate(enc_args):
            char_arr = c_array_from_buffer(ctypes.c_char, enc_arg)
            fmt_args[i] = ctypes.cast(ctypes.byref(char_arr), ctypes.c_char_p)

        flags |= FormatFlags.ARGUMENT_ARRAY

    if source is not None:
        if not isinstance(source, (wintypes.HANDLE, str)):
            raise TypeError(f'Invalid type for source: {type(source).__name__}')

        if isinstance(source, str):
            source = load_library(source)

        flags |= FormatFlags.FROM_HMODULE

    else:
        flags |= FormatFlags.FROM_SYSTEM

    res = FormatMessage(
        flags.value,
        source,
        err_code,
        0,
        ctypes.cast(ctypes.byref(lp_msg), wintypes.LPSTR),
        0,
        fmt_args
    )

    if not res:
        raise WindowsError(GetLastError(), 'FormatMessage')

    try:
        return lp_msg.value.rstrip().decode('utf-8', 'strict')
    finally:
        LocalFree(lp_msg)


def raise_windows_error(err_code=None, ignore_codes=None, message=None, exc_type=WindowsError,
                        source=None, fmt_args=None):
    err_code = err_code if err_code is not None else GetLastError()

    if ignore_codes is not None:
        for code in ignore_codes:
            if code == err_code:
                return code

    if not issubclass(exc_type, WindowsError):
        raise TypeError(f'exc_type must be a valid {WindowsError.__name__} subclass')

    if message is None:
        try:
            message = format_error_message(
                err_code,
                source=source,
                fmt_args=fmt_args
            )
        except WindowsError:
            message = 'Unknown error'

    raise exc_type(err_code, message)


def get_startup_info(desktop, show_window=False):
    if desktop not in Desktops:
        desktop = Desktops(desktop)

    si = win32process.STARTUPINFO()
    si.lpDesktop = DESKTOP_NAME_PREFIX + desktop.value

    if not show_window:
        si.dwFlags |= win32con.STARTF_USESHOWWINDOW
        si.wShowWindow = win32con.SW_HIDE

    return si


def create_environment(environ):
    """
    https://stackoverflow.com/a/29737399
    :param environ:
    :return:
    """
    if environ is not None:
        items = ['%s=%s' % (k, environ[k]) for k in sorted(environ)]
        buf = '\x00'.join(items)
        length = len(buf) + 2 if buf else 1
        return ctypes.create_unicode_buffer(buf, length)


def create_security_attributes(**kwargs):
    dacl_present = kwargs.get('dacl_present', True)
    dacl = kwargs.get('dacl')
    default_dacl = kwargs.get('default_dacl', False)

    security_descriptor = win32security.SECURITY_DESCRIPTOR()
    security_descriptor.Initialize()
    security_descriptor.SetSecurityDescriptorDacl(dacl_present, dacl,
                                                  default_dacl)
    security_attributes = win32security.SECURITY_ATTRIBUTES()
    security_attributes.SECURITY_DESCRIPTOR = security_descriptor
    return security_attributes


# noinspection PyPep8Naming
def PySTARTUPINFO_to_dict(py_si):
    return {name: getattr(py_si, name) for name in PY_SI_PROPERTY_NAMES}


# noinspection PyPep8Naming
def PySTARTUPINFO_to_STARTUPINFO(py_si, unicode=True):
    py_si_dict = PySTARTUPINFO_to_dict(py_si)

    if unicode:
        si = STARTUPINFOW()

    else:
        si = STARTUPINFOA()
        desktop = py_si_dict['lpDesktop']
        title = py_si_dict['lpTitle']

        if desktop is not None:
            py_si_dict['lpDesktop'] = desktop.encode('utf-8', 'strict')

        if title is not None:
            py_si_dict['lpTitle'] = title.encode('utf-8', 'strict')

    for key, value in py_si_dict.items():
        setattr(si, key, value)

    return si


def get_known_folder_path(folder_id):
    if folder_id not in FolderId:
        folder_id = FolderId(folder_id)

    path_ptr = wintypes.LPWSTR()
    hr = SHGetKnownFolderPath(ctypes.byref(folder_id.value), 0, None, ctypes.byref(path_ptr))

    if not SUCCEEDED(hr):
        raise_windows_error(hr)

    try:
        return path_ptr.value
    finally:
        CoTaskMemFree(path_ptr)


def create_process_as_user(*cmd_line_args, token, **kwargs):
    app_name = kwargs.pop('app_name', None)
    cmd_line = ' '.join(cmd_line_args)
    process_sa = kwargs.pop('process_sa', None)
    thread_sa = kwargs.pop('thread_sa', None)
    inherit_handles = kwargs.pop('inherit_handles', False)
    creation_flags = kwargs.pop('creation_flags', win32con.NORMAL_PRIORITY_CLASS)
    environment = kwargs.get('environment', None)
    current_directory = kwargs.pop('current_directory', None)
    startup_info = kwargs.pop('startup_info', win32process.STARTUPINFO())

    result = win32process.CreateProcessAsUser(token,
                                              app_name,
                                              cmd_line,
                                              process_sa,
                                              thread_sa,
                                              inherit_handles,
                                              creation_flags,
                                              environment,
                                              current_directory,
                                              startup_info)

    h_process, h_thread, process_id, thread_id = result
    h_thread.Close()
    return process_id


def create_process_with_logon(*cmd_line_args, username, password, domain=None,
                              logon_flags=LOGON_WITH_PROFILE, **kwargs):
    app_name = kwargs.pop('app_name', None)
    cmd_line = ' '.join(cmd_line_args)
    creation_flags = kwargs.pop('creation_flags', win32con.NORMAL_PRIORITY_CLASS)
    environment = kwargs.get('environment', None)
    current_directory = kwargs.pop('current_directory', None)
    si = kwargs.pop('startup_info', win32process.STARTUPINFO())
    pi = PROCESS_INFORMATION()

    res = CreateProcessWithLogon(username,
                                 domain,
                                 password,
                                 logon_flags,
                                 app_name,
                                 cmd_line,
                                 creation_flags,
                                 environment,
                                 current_directory,
                                 ctypes.byref(si),
                                 ctypes.byref(pi))

    if not res:
        raise_windows_error()

    win32api.CloseHandle(pi.hThread)
    return pi.dwProcessId


def create_process_with_token(*cmd_line_args, token, logon_flags=LOGON_WITH_PROFILE, **kwargs):
    app_name = kwargs.pop('app_name', None)
    cmd_line = ' '.join(cmd_line_args)
    creation_flags = kwargs.pop('creation_flags', win32con.NORMAL_PRIORITY_CLASS)
    creation_flags |= CREATE_UNICODE_ENVIRONMENT
    environment = kwargs.get('environment', None)

    if isinstance(environment, dict):
        environment = py_env_to_env(environment)

    current_directory = kwargs.pop('current_directory', None)

    py_si = kwargs.pop('startup_info', win32process.STARTUPINFO())

    si = PySTARTUPINFO_to_STARTUPINFO(py_si, unicode=True)

    pi = PROCESS_INFORMATION()

    token = wintypes.HANDLE(int(token))
    res = CreateProcessWithToken(token,
                                 logon_flags,
                                 app_name,
                                 cmd_line,
                                 creation_flags,
                                 environment,
                                 current_directory,
                                 ctypes.byref(si),
                                 ctypes.byref(pi))

    if not res:
        raise_windows_error()

    win32api.CloseHandle(pi.hThread)
    return pi.dwProcessId


def get_username():
    return win32api.GetUserName()


def lookup_account_name(name):
    sid, domain, sid_type = win32security.LookupAccountName(None, name)
    sid_str = win32security.ConvertSidToStringSid(sid)
    sid_type = SidType(sid_type)
    return sid_str, domain, sid_type


def lookup_account_sid(sid_str):
    sid = win32security.ConvertStringSidToSid(sid_str)
    name, domain, sid_type = win32security.LookupAccountSid(None, sid)
    sid_type = SidType(sid_type)
    return name, domain, sid_type


def get_current_process_id():
    return win32process.GetCurrentProcessId()


def get_current_session_id(process_id=None):
    if process_id is None:
        process_id = win32process.GetCurrentProcessId()

    return win32ts.ProcessIdToSessionId(process_id)


def create_file(file_name, desired_access, share_mode, security_attributes, creation_disposition,
                flags_and_attributes, template_file):
    if desired_access not in AccessTypes:
        desired_access = AccessTypes(desired_access)

    if share_mode not in FileShare:
        share_mode = FileShare(share_mode)

    if creation_disposition not in CreationDisposition:
        creation_disposition = CreationDisposition(creation_disposition)

    if flags_and_attributes not in FileAttributes:
        flags_and_attributes = FileAttributes(flags_and_attributes)

    win32file.CreateFile()
    return win32file.CreateFile(file_name,
                                int(desired_access),
                                int(share_mode),
                                security_attributes,
                                creation_disposition.value,
                                int(flags_and_attributes),
                                template_file)


def get_current_user_token():
    return win32security.OpenProcessToken(win32process.GetCurrentProcess(),
                                          win32security.TOKEN_QUERY)


def get_session_token(session_id):
    session_id = int(session_id)
    # get the access token of the current process, which is launched
    # under the SYSTEM user.
    process_token = win32security.OpenProcessToken(win32process.GetCurrentProcess(),
                                                   win32security.TOKEN_ALL_ACCESS)
    token = win32security.DuplicateTokenEx(process_token,
                                           win32security.SecurityIdentification,
                                           win32security.TOKEN_ALL_ACCESS,
                                           win32security.TokenPrimary)

    # set the duplicated token with the session_id
    win32security.SetTokenInformation(token,
                                      win32security.TokenSessionId,
                                      session_id)
    return token


def get_user_token_for_session(user_token, session_id, impersonate=False):
    session_id = int(session_id)

    if impersonate:
        user_token = win32security.ImpersonateLoggedOnUser(user_token)

    token = win32security.DuplicateTokenEx(user_token,
                                           win32security.SecurityIdentification,
                                           win32security.TOKEN_ALL_ACCESS,
                                           win32security.TokenPrimary)

    win32security.SetTokenInformation(token,
                                      win32security.TokenSessionId,
                                      session_id)
    return token


def get_user_sid(token=None):
    token = token or get_current_user_token()
    sid, _ = win32security.GetTokenInformation(token, win32security.TokenUser)
    return win32security.ConvertSidToStringSid(sid)


get_current_user_sid = partial(get_user_sid, None)


def adjust_process_privilege(privilege_name, enable=True):
    token = win32security.OpenProcessToken(win32api.GetCurrentProcess(),
                                           win32con.TOKEN_ADJUST_PRIVILEGES | win32con.TOKEN_QUERY)
    privilege_id = win32security.LookupPrivilegeValue(None, privilege_name)

    if enable:
        new_privileges = [(privilege_id, win32con.SE_PRIVILEGE_ENABLED)]

    else:
        new_privileges = [(privilege_id, 0)]

    win32security.AdjustTokenPrivileges(token, 0, new_privileges)


def enable_process_privilege(se_privilege):
    return adjust_process_privilege(se_privilege, True)


def disable_process_privilege(se_privilege):
    return adjust_process_privilege(se_privilege, False)


def initiate_system_shutdown(message=None, timeout=0, force_apps_closed=False, reboot=False):
    enable_process_privilege(win32con.SE_SHUTDOWN_NAME)
    win32api.InitiateSystemShutdown(None, message, timeout, force_apps_closed, reboot)


def get_processor_architecture():
    proc_arch, *_ = win32api.GetNativeSystemInfo()
    return ProcessorArchitecture(proc_arch)


def windows_is_64bit():
    return get_processor_architecture().name.endswith('64')


def get_computer_name(name_format=ComputerNameFormat.DNS_FULLY_QUALIFIED):
    if name_format not in ComputerNameFormat:
        name_format = ComputerNameFormat(name_format)

    size = wintypes.DWORD(0)
    res = GetComputerNameEx(
        name_format.value,
        None,
        ctypes.byref(size)
    )

    if not res:
        raise_windows_error(ignore_codes=(ERROR_MORE_DATA,))

    buffer = ctypes.create_string_buffer(size.value)

    res = GetComputerNameEx(
        name_format.value,
        buffer,
        ctypes.byref(size)
    )

    if not res:
        raise_windows_error()

    return buffer.value.decode('utf-8', 'strict')
