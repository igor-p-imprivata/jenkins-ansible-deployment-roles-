# _wintypes.py
import ctypes
from struct import calcsize
from ctypes import wintypes


BITNESS = calcsize('P') * 8

DWORD_PTR = ctypes.POINTER(wintypes.DWORD)
ULONG_PTR = ctypes.c_ulonglong if BITNESS == 64 else ctypes.c_ulong

va_list = ctypes.c_char_p
va_list_p = ctypes.POINTER(va_list)

ole32 = ctypes.windll.ole32

StringFromCLSID = ole32.StringFromCLSID

CoTaskMemFree = ole32.CoTaskMemFree


# noinspection PyPep8Naming
def SUCCEEDED(hr):
    return hr >= 0


class GUID(ctypes.Structure):
    @classmethod
    def INITGUID(cls, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8):
        guid = cls()
        guid.Data1 = l
        guid.Data2 = w1
        guid.Data3 = w2
        _bytes = (b1, b2, b3, b4, b5, b6, b7, b8)

        for i, b in enumerate(_bytes):
            guid.Data4[i] = b

        return guid

    # noinspection PyTypeChecker
    _fields_ = [
        ('Data1', wintypes.DWORD),
        ('Data2', wintypes.WORD),
        ('Data3', wintypes.WORD),
        ('Data4', wintypes.BYTE * 8)
    ]

    def __str__(self):
        p = ctypes.c_wchar_p()
        StringFromCLSID(ctypes.byref(self), ctypes.byref(p))
        result = p.value
        CoTaskMemFree(p)
        return result


LPGUID = ctypes.POINTER(GUID)


class LUID(ctypes.Structure):
    _fields_ = [
        ('LowPart', wintypes.DWORD),
        ('HighPart', wintypes.LONG),
    ]

PLUID = ctypes.POINTER(LUID)


class SECURITY_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ('nLength', wintypes.DWORD),
        ('lpSecurityDescriptor', wintypes.LPVOID),
        ('bInheritHandle', wintypes.BOOL)
    ]

LPSECURITY_ATTRIBUTES = ctypes.POINTER(SECURITY_ATTRIBUTES)


class OVERLAPPED(ctypes.Structure):
    class DUMMYUNION(ctypes.Union):

        class DUMMYSTRUCT(ctypes.Structure):
            _fields_ = [
                ('Offset', wintypes.DWORD),
                ('OffsetHigh', wintypes.DWORD)
            ]

        _anonymous_ = ('DUMMYSTRUCTNAME',)
        _fields_ = [
            ('DUMMYSTRUCTNAME', DUMMYSTRUCT),
            ('Pointer', wintypes.LPVOID)
        ]

    _anonymous_ = ('DUMMYUNIONNAME',)

    _fields_ = [
        ('Internal', ULONG_PTR),
        ('InternalHigh', ULONG_PTR),
        ('DUMMYUNIONNAME', DUMMYUNION),
        ('hEvent', wintypes.HANDLE)
    ]

LPOVERLAPPED = ctypes.POINTER(OVERLAPPED)


class SID_IDENTIFIER_AUTHORITY(ctypes.Structure):
    # noinspection PyTypeChecker
    _fields_ = [
        ('Value', wintypes.BYTE * 6)
    ]


class SID(ctypes.Structure):
    pass

PSID = ctypes.POINTER(SID)


class LUID_AND_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ('Luid', LUID),
        ('Attributes', wintypes.DWORD)
    ]


class TOKEN_PRIVILEGES(ctypes.Structure):
    _fields_ = [
        ('PrivilegeCount', wintypes.DWORD),
        ('Privileges', LUID_AND_ATTRIBUTES * 1)
    ]


PTOKEN_PRIVILEGES = ctypes.POINTER(TOKEN_PRIVILEGES)


def alloc_token_privileges(size=1):
    TOKEN_PRIVILEGES._fields_[1] = ('Privileges', LUID_AND_ATTRIBUTES * size)

    token_privileges = TOKEN_PRIVILEGES()
    token_privileges.PrivilegeCount = size
    return token_privileges


class SID_AND_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ('Sid', PSID),
        ('Attributes', wintypes.DWORD),
    ]


class TOKEN_USER(ctypes.Structure):
    _fields_ = [
        ('User', SID_AND_ATTRIBUTES)
    ]

PTOKEN_USER = ctypes.POINTER(TOKEN_USER)


class SYSTEM_INFO(ctypes.Structure):

    class DUMMYUNION(ctypes.Union):

        class DUMMYSTRUCT(ctypes.Structure):

            _fields_ = [
                ('wProcessorArchitecture', wintypes.WORD),
                ('wReserved', wintypes.WORD)
            ]

        _fields_ = [
            ('dwOemId', wintypes.DWORD),
            ('DUMMYSTRUCTNAME', DUMMYSTRUCT)
        ]

    _fields_ = [
        ('DUMMYUNIONNAME', DUMMYUNION),
        ('dwPageSize', wintypes.DWORD),
        ('lpMinimumApplicationAddress', wintypes.LPVOID),
        ('lpMaximumApplicationAddress', wintypes.LPVOID),
        ('dwActiveProcessorMask', DWORD_PTR),
        ('dwNumberOfProcessors', wintypes.DWORD),
        ('dwProcessorType', wintypes.DWORD),
        ('dwAllocationGranularity', wintypes.DWORD),
        ('wProcessorLevel', wintypes.WORD),
        ('wProcessorRevision', wintypes.WORD)
    ]

LPSYSTEM_INFO = ctypes.POINTER(SYSTEM_INFO)


class NETRESOURCE(ctypes.Structure):
    _fields_ = [
        ('dwScope', wintypes.DWORD),
        ('dwType', wintypes.DWORD),
        ('dwDisplayType', wintypes.DWORD),
        ('dwUsage', wintypes.DWORD),
        ('lpLocalName', wintypes.LPCSTR),
        ('lpRemoteName', wintypes.LPCSTR),
        ('lpComment', wintypes.LPCSTR),
        ('lpProvider', wintypes.LPCSTR)
    ]

LPNETRESOURCE = ctypes.POINTER(NETRESOURCE)


class UNIVERSAL_NAME_INFO(ctypes.Structure):
    _fields_ = [
        ('lpUniversalName', wintypes.LPSTR)
    ]


class REMOTE_NAME_INFO(ctypes.Structure):
    _fields_ = [
        ('lpUniversalName', wintypes.LPSTR),
        ('lpConnectionName', wintypes.LPSTR),
        ('lpRemainingPath', wintypes.LPSTR)
    ]


class STARTUPINFOA(ctypes.Structure):
    _fields_ = [
        ('cb', wintypes.DWORD),
        ('lpReserved', wintypes.LPSTR),
        ('lpDesktop', wintypes.LPSTR),
        ('lpTitle', wintypes.LPSTR),
        ('dwX', wintypes.DWORD),
        ('dwY', wintypes.DWORD),
        ('dwXSize', wintypes.DWORD),
        ('dwYSize', wintypes.DWORD),
        ('dwXCountChars', wintypes.DWORD),
        ('dwYCountChars', wintypes.DWORD),
        ('dwFillAttribute', wintypes.DWORD),
        ('dwFlags', wintypes.DWORD),
        ('wShowWindow', wintypes.WORD),
        ('cbReserved2', wintypes.WORD),
        ('lpReserved2', wintypes.LPBYTE),
        ('hStdInput', wintypes.HANDLE),
        ('hStdOutput', wintypes.HANDLE),
        ('hStdError', wintypes.HANDLE)
    ]

LPSTARTUPINFOA = ctypes.POINTER(STARTUPINFOA)


class STARTUPINFOW(ctypes.Structure):
    _fields_ = [
        ('cb', wintypes.DWORD),
        ('lpReserved', wintypes.LPWSTR),
        ('lpDesktop', wintypes.LPWSTR),
        ('lpTitle', wintypes.LPWSTR),
        ('dwX', wintypes.DWORD),
        ('dwY', wintypes.DWORD),
        ('dwXSize', wintypes.DWORD),
        ('dwYSize', wintypes.DWORD),
        ('dwXCountChars', wintypes.DWORD),
        ('dwYCountChars', wintypes.DWORD),
        ('dwFillAttribute', wintypes.DWORD),
        ('dwFlags', wintypes.DWORD),
        ('wShowWindow', wintypes.WORD),
        ('cbReserved2', wintypes.WORD),
        ('lpReserved2', wintypes.LPBYTE),
        ('hStdInput', wintypes.HANDLE),
        ('hStdOutput', wintypes.HANDLE),
        ('hStdError', wintypes.HANDLE)
    ]

LPSTARTUPINFOW = ctypes.POINTER(STARTUPINFOW)


class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [
        ('hProcess', wintypes.HANDLE),
        ('hThread', wintypes.HANDLE),
        ('dwProcessId', wintypes.DWORD),
        ('dwThreadId', wintypes.DWORD)
    ]

LPPROCESS_INFORMATION = ctypes.POINTER(PROCESS_INFORMATION)


class WTS_SESSION_INFO(ctypes.Structure):
    _fields_ = [
        ('SessionId', wintypes.DWORD),
        ('pWinStationName', wintypes.LPSTR),
        ('State', ctypes.c_int)
    ]

PWTS_SESSION_INFO = ctypes.POINTER(WTS_SESSION_INFO)


class WTS_PROCESS_INFO(ctypes.Structure):
    _fields_ = [
        ('SessionId', wintypes.DWORD),
        ('ProcessId', wintypes.DWORD),
        ('pProcessName', wintypes.LPSTR),
        ('pUserSid', PSID)
    ]

PWTS_PROCESS_INFO = ctypes.POINTER(WTS_PROCESS_INFO)


class WTS_CLIENT_DISPLAY(ctypes.Structure):
    _fields_ = [
        ('HorizontalResolution', wintypes.DWORD),
        ('VerticalResolution', wintypes.DWORD),
        ('ColorDepth', wintypes.DWORD)
    ]

PWTS_CLIENT_DISPLAY = ctypes.POINTER(WTS_CLIENT_DISPLAY)


class IMAGE_DOS_HEADER(ctypes.Structure):
    _fields_ = [
        ('e_magic', wintypes.WORD),
        ('e_cblp', wintypes.WORD),
        ('e_cp', wintypes.WORD),
        ('e_crlc', wintypes.WORD),
        ('e_cparhdr', wintypes.WORD),
        ('e_minalloc', wintypes.WORD),
        ('e_maxalloc', wintypes.WORD),
        ('e_ss', wintypes.WORD),
        ('e_sp', wintypes.WORD),
        ('e_csum', wintypes.WORD),
        ('e_ip', wintypes.WORD),
        ('e_cs', wintypes.WORD),
        ('e_lfarlc', wintypes.WORD),
        ('e_ovno', wintypes.WORD),
        ('e_res', wintypes.WORD * 4),
        ('e_oemid', wintypes.WORD),
        ('e_oeminfo', wintypes.WORD),
        ('e_res2', wintypes.WORD * 10),
        ('e_lfanew', wintypes.LONG),
    ]


