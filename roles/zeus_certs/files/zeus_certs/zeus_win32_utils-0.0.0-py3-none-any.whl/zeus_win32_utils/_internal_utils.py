# _internal_utils.py
import re


arr_re = re.compile(r'\[(\d+)\]$')


def cy_struct2ctypes_struct(cy_struct_str):
    lines = [line.strip() for line in cy_struct_str.splitlines() if line.strip()]
    builder = CtypesStructBuilder(lines)
    return builder.build()


def make_tabs(count):
    return (' ' * 4) * count


class CtypesStructBuilder:
    class_def_fmt = 'class {class_name}(ctypes.Structure):'
    fields_fmt = '_fields_ = ['
    member_fmt = "('{member_name}', {data_type}),"

    def __init__(self, lines):
        self.input_lines = lines
        self.output_lines = []

    def add_output_line(self, line, tab_offset=0):
        tabs = make_tabs(tab_offset)
        self.output_lines.append(f'{tabs}{line}')

    def add_member(self, line):
        data_type, member_name = line.split()
        data_type = f'wintypes.{data_type}'

        res = arr_re.search(member_name)

        if res is not None:
            arr_len = int(res.group(1))
            data_type = f'{data_type} * {arr_len}'
            member_name = member_name.split('[')[0]

        line = self.member_fmt.format(member_name=member_name, data_type=data_type)
        self.add_output_line(line, tab_offset=2)

    def add_class_definition(self):
        typedef_line = self.input_lines[0]

        if not typedef_line.endswith(':'):
            raise RuntimeError()

        class_def = self.class_def_fmt.format(class_name=typedef_line.split()[-1][:-1])
        self.add_output_line(class_def)

    def build(self):
        self.add_class_definition()
        self.add_output_line(self.fields_fmt, tab_offset=1)

        for line in self.input_lines[1:]:
            self.add_member(line)

        self.add_output_line(']', tab_offset=1)
        return '\n'.join(self.output_lines)

