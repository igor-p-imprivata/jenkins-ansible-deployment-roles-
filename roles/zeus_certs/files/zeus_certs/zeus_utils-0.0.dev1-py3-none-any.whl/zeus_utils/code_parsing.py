# code_parsing
import ast


def iter_parse(code):
    root = ast.parse(source=code)
    yield from ast.walk(root)


def dump(code):
    return ast.dump(ast.parse(source=code))


def iter_nodes_of_type(code, *node_types):
    for node_type in node_types:
        if not issubclass(node_type, ast.AST):
            raise TypeError(f'node_type must be a valid {ast.AST.__name__} subclass')

    yield from filter(lambda node: isinstance(node, node_types), iter_parse(code))


def get_function_names(code):
    return tuple(func_def.name for func_def in iter_nodes_of_type(code, ast.FunctionDef))


def get_class_names(code):
    return tuple(class_def.name for class_def in iter_nodes_of_type(code, ast.ClassDef))


def get_variable_names(code):
    return tuple(name.id for name in iter_nodes_of_type(code, ast.Name))


__all__ = [
    'iter_parse', 'dump', 'iter_nodes_of_type', 'get_function_names', 'get_class_names',
    'get_variable_names'
]
