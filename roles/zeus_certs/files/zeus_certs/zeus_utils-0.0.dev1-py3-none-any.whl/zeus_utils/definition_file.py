# definition_file.py


class DefinitionFile:
    def __init__(self, file_path):
        self.file_path = file_path
        self._expected_names = set()
        self._expected_name_defaults = {}
        self._value_converters = {}
        self._lines = None
        self._value_cache = {}

    def __str__(self):
        self.parse()
        return '\n'.join(self._lines)

    def __iter__(self):
        self.parse()

        for line in self._lines:
            yield line

    def _parse_line(self, line, name, converter=None, default=None):
        if line.startswith(name):
            value = line.split('=')[-1].strip()

            if converter is None:
                converter = self._value_converters.get(name)

            if converter is not None:
                value = converter(value)

            self._value_cache[name] = value
            return value

        return default

    def _fill_defaults(self):
        for name, default in self._expected_name_defaults.items():
            if name not in self._value_cache:
                self._value_cache[name] = default

    def add_expected_name(self, name, converter=None, **kwargs):
        self._expected_names.add(name)

        if converter is not None:
            self._value_converters[name] = converter

        if 'default' in kwargs:
            self._expected_name_defaults[name] = kwargs['default']

        self.clear()

    def clear(self):
        self._lines = None
        self._value_cache.clear()

    def parse(self):
        if self._lines is None:
            with open(self.file_path, 'r') as f:
                self._lines = lines = []

                for line in filter(None, (l.strip() for l in f.readlines())):

                    for name in self._expected_names:
                        if self._parse_line(line, name=name) is not None:
                            break

                    lines.append(line)

            self._fill_defaults()

    def get(self, name, default=None):
        self.parse()
        return self._value_cache.get(name, default)
