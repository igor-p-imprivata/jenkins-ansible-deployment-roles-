# protocol_magic.py
import os

here = os.path.abspath(os.path.dirname(__file__))

PROTOCOL_MAGIC_BYTES_LEN = 4
PROTOCOL_MAGIC_FILE_NAME = '_protocol_magic.py'
PROTOCOL_MAGIC_PATH = os.path.join(here, 'zeus_vda_smoke_test', PROTOCOL_MAGIC_FILE_NAME)


def generate_protocol_magic():
    lines = [f'# {PROTOCOL_MAGIC_FILE_NAME}', *['\n'] * 3]
    magic = os.urandom(PROTOCOL_MAGIC_BYTES_LEN)
    lines.append(f'PROTOCOL_MAGIC = {repr(magic)}\r')

    with open(PROTOCOL_MAGIC_PATH, 'w') as f:
        f.writelines(lines)


if __name__ == '__main__':
    generate_protocol_magic()
