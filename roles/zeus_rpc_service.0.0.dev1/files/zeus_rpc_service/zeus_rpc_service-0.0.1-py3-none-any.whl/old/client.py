

# SVC_NAME_SESSIONS, SVC_NAME_SYSTEM, SVC_NAME_REGISTRY, SVC_NAME_DRIVES,
# from zeus_win32_utils import WConnectFlags
# from zeus_reg import RegistryKeyFlags, RegistryDataTypes
# from zeus_rpc_service.client.utils import TemporaryRemoteService

# AUTO_LOGON_REG_KEY = 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon'
# AUTO_LOGON_USERNAME_VALUE = 'DefaultUserName'
# AUTO_LOGON_PASSWORD_VALUE = 'DefaultPassword'
# AUTO_LOGON_DOMAIN_VALUE = 'DefaultDomainName'
# AUTO_LOGON_SWITCH_VALUE = 'AutoAdminLogon'
#
# AUTO_LOGON_VALUE_NAMES = (
#     AUTO_LOGON_USERNAME_VALUE, AUTO_LOGON_PASSWORD_VALUE, AUTO_LOGON_DOMAIN_VALUE,
#     AUTO_LOGON_SWITCH_VALUE
# )


# def wait_for_icmp_response(host, exit_condition, timeout=None, interval=WAIT_PING_INTERVAL):
#     start = time.time()
#
#     while True:
#         ping_response = ping(host, count=1, timeout=interval)
#
#         if exit_condition(ping_response):
#             break
#
#         if timeout is not None and (time.time() - start) > timeout:
#             raise TimeoutError()
#
#         time.sleep(interval)


# def get_auto_logon_requirements(username=None, password=None, domain=None, enabled=True):
#     name_values = []
#
#     if username is not None:
#         name_values.append((AUTO_LOGON_USERNAME_VALUE, username))
#
#     if password is not None:
#         name_values.append((AUTO_LOGON_PASSWORD_VALUE, password))
#
#     if domain is not None:
#         name_values.append((AUTO_LOGON_DOMAIN_VALUE, domain))
#
#     name_values.append((AUTO_LOGON_SWITCH_VALUE, '1' if enabled else '0'))
#     return name_values


# def find_windows_session(self, *, case_insensitive=True, sub_string=True, **attributes):
    #     services_session = self.get_session(STATION_NAME_SERVICES)
    #     session_manager = services_session.get_remote_service(service=SVC_NAME_SESSIONS)
    #     return session_manager.find(
    #         case_insensitive=case_insensitive,
    #         sub_string=sub_string,
    #         **attributes
    #     )

    # def connect_to_session_id(self, session_id, timeout=None, **kwargs):
    #     services_session = self.get_session(STATION_NAME_SERVICES)
    #     windows_session = self.find_windows_session(session_id=session_id)
    #     station_name = windows_session.station_name
    #     port = self.claim_available_port()
    #     root_service = services_session.get_remote_service(service=SVC_NAME_ROOT)
    #     root_service.spawn_rpc_server(
    #         session_id=session_id,
    #         port=port,
    #         timeout=timeout,
    #         **kwargs
    #     )
    #
    #     try:
    #         session = self.connect_session(
    #             station_name=station_name,
    #             session_id=session_id,
    #             port=port,
    #             disconnect_action=DisconnectActions.SHUTDOWN_SERVER
    #         )
    #     except Exception:
    #         self.release_port(port)
    #         raise
    #
    #     return session

    # def connect_console_session(self, timeout=None, **kwargs):
    #     windows_session = self.find_windows_session(station_name=STATION_NAME_CONSOLE)
    #
    #     if windows_session is None:
    #         raise RuntimeError('No console session found on host')
    #
    #     # if the windows_session is an RDP session, console is actually attached
    #     # to an active RDP session with the station name "RDP-Tcp#N"
    #     # if windows_session.is_remote:
    #     if windows_session.get_user() is None:
    #         windows_session = self.find_windows_session(station_name='RDP-Tcp#')
    #         session_id = windows_session.session_id
    #
    #     else:
    #         services_session = self.get_session(STATION_NAME_SERVICES)
    #         session_manager = services_session.get_remote_service(service=SVC_NAME_SESSIONS)
    #         session_id = session_manager.get_console_session_id()
    #
    #     return self.connect_to_session_id(
    #         session_id=session_id,
    #         timeout=timeout,
    #         **kwargs
    #     )

    # def wait_for_reboot(self, reboot_timeout=None):
    #     logger.info(f'{repr(self)}: waiting for {self.host} to reboot...')
    #     start = time.time()
    #
    #     logger.debug(f'{repr(self)}: reboot -> waiting for {self.host} to become '
    #                  f'unreachable via ICMP')
    #     # wait until not ping-able
    #     wait_for_icmp_response(host=self.host,
    #                            exit_condition=lambda ping_response: not bool(ping_response),
    #                            timeout=reboot_timeout)
    #
    #     logger.debug(f'{repr(self)}: reboot -> {self.host} unreachable via ICMP')
    #
    #     logger.debug(f'{repr(self)}: reboot -> waiting for {self.host} to become '
    #                  f'reachable via ICMP')
    #
    #     if reboot_timeout is not None:
    #         reboot_timeout -= (time.time() - start)
    #
    #     # wait until ping-able
    #     wait_for_icmp_response(host=self.host,
    #                            exit_condition=lambda ping_response: bool(ping_response),
    #                            timeout=reboot_timeout)
    #
    #     logger.debug(f'{repr(self)}: reboot -> {self.host} reachable via ICMP')
    #
    #     logger.debug(f'{repr(self)}: reboot -> waiting for RPC service on {self.host}')
    #
    #     if reboot_timeout is not None:
    #         reboot_timeout -= (time.time() - start)
    #
    #     self.wait_for_services_session(timeout=reboot_timeout)
    #
    #     elapsed_time = time.time() - start
    #     logger.debug(f'{repr(self)}: reboot -> RPC service on {self.host} reachable; '
    #                  f'elapsed_time: {elapsed_time} second(s)')
    #
    #     logger.info(f'{repr(self)}: successfully rebooted {self.host}')

    # def reboot(self, message=None, timeout=0, force_apps_closed=True, wait=True,
    #            reboot_timeout=None):
    #     logger.info(f'{repr(self)}: rebooting {self.host}...')
    #
    #     self.disconnect_session(STATION_NAME_CONSOLE)
    #
    #     services_session = self.get_session(STATION_NAME_SERVICES)
    #     services_session.cleanup_resources()
    #
    #     system_service = services_session.get_remote_service(SVC_NAME_SYSTEM)
    #     system_service.initiate_system_shutdown(
    #         message=message,
    #         timeout=timeout,
    #         force_apps_closed=force_apps_closed,
    #         reboot=True
    #     )
    #
    #     self._sessions_by_station_name.clear()
    #
    #     if wait:
    #         self.wait_for_reboot(reboot_timeout=reboot_timeout)

    # def get_auto_logon_registry_key(self, station_name=STATION_NAME_SERVICES, index=0):
    #     session = self.get_session(station_name, index=index)
    #
    #     system_service = session.get_remote_service(SVC_NAME_SYSTEM)
    #     os_bitness = system_service.get_os_bitness()
    #
    #     key_flag = RegistryKeyFlags.WOW64_64_KEY if os_bitness == 64 else 0
    #
    #     registry_service = session.get_remote_service(SVC_NAME_REGISTRY)
    #     return registry_service.get(AUTO_LOGON_REG_KEY, key_flag=key_flag)

    # def get_auto_logon_registry_values(self, key=None, station_name=STATION_NAME_SERVICES, index=0):
    #     key = key or self.get_auto_logon_registry_key(
    #         station_name=station_name,
    #         index=index
    #     )
    #
    #     if key is None:
    #         raise ValueError(f'Unable to find key: {AUTO_LOGON_REG_KEY}')
    #
    #     return {name: key.get_value(name) for name in AUTO_LOGON_VALUE_NAMES}

    # def enable_auto_logon(self, username=None, password=None, domain=None, key=None,
    #                       station_name=STATION_NAME_SERVICES, index=0):
    #     logger.debug(f'{repr(self)}: enable_auto_logon -> username: {username}, '
    #                  f'password: {password}, domain: {domain}')
    #
    #     key = key or self.get_auto_logon_registry_key(station_name=station_name, index=index)
    #     reg_val_map = self.get_auto_logon_registry_values(key=key)
    #     requirements = get_auto_logon_requirements(
    #         username=username,
    #         password=password,
    #         domain=domain,
    #         enabled=True
    #     )
    #
    #     for value_name, required_value in requirements:
    #         reg_val = reg_val_map.get(value_name)
    #
    #         if reg_val is None:
    #             key.create_value(
    #                 name=value_name,
    #                 data_type=RegistryDataTypes.SZ,
    #                 value=required_value
    #             )
    #
    #         elif reg_val.get() != required_value:
    #             key.set_value(
    #                 name=value_name,
    #                 data_type=RegistryDataTypes.SZ,
    #                 value=required_value
    #             )
    #
    # def check_auto_logon_enabled(self, username=None, password=None, domain=None, key=None,
    #                              station_name=STATION_NAME_SERVICES, index=0):
    #     reg_val_map = self.get_auto_logon_registry_values(
    #         key=key,
    #         station_name=station_name,
    #         index=index
    #     )
    #     requirements = get_auto_logon_requirements(
    #         username=username,
    #         password=password,
    #         domain=domain,
    #         enabled=True
    #     )
    #
    #     for value_name, required_value in requirements:
    #         reg_val = reg_val_map.get(value_name)
    #
    #         if reg_val is None or reg_val.value != required_value:
    #             enabled = False
    #             break
    #
    #     else:
    #         enabled = True
    #
    #     logger.debug(f'{repr(self)}: check_auto_logon_enabled -> {enabled}')
    #     return enabled
    #
    # def ensure_auto_logon_enabled(self, username=None, password=None, domain=None,
    #                               station_name=STATION_NAME_SERVICES, index=0):
    #     key = self.get_auto_logon_registry_key(station_name=station_name, index=index)
    #
    #     enabled = self.check_auto_logon_enabled(
    #         username=username,
    #         password=password,
    #         domain=domain,
    #         key=key
    #     )
    #
    #     if not enabled:
    #         self.enable_auto_logon(
    #             username=username,
    #             password=password,
    #             domain=domain,
    #             key=key
    #         )

    # def disconnect_network_drives(self, station_name=STATION_NAME_SERVICES, index=0):
    #     drive_manager = self.get_remote_service(
    #         service_name=SVC_NAME_DRIVES,
    #         station_name=station_name,
    #         index=index
    #     )
    #     drive_manager.disconnect_drives()
    #
    # def map_network_drive(self, tag, remote_name, username, password,
    #                       flags=WConnectFlags.TEMPORARY, cleanup=True,
    #                       station_name=STATION_NAME_SERVICES, index=0):
    #     session = self.get_session(station_name, index=index)
    #     drive_manager = session.get_remote_service(SVC_NAME_DRIVES)
    #
    #     network_drive = drive_manager.map_network_drive(
    #         remote_name=remote_name,
    #         username=username,
    #         password=password,
    #         flags=flags
    #     )
    #
    #     cleanup_func = network_drive.disconnect if cleanup else None
    #
    #     session.register_resource(
    #         tag=tag,
    #         resource=network_drive,
    #         cleanup_func=cleanup_func
    #     )
    #
    #     return network_drive

    # def create_temporary_remote_service(self, import_path, call_service_import=False, service_args=None,
    #                                     service_kwargs=None, station_name=STATION_NAME_SERVICES, index=0):
    #     session = self.get_session(station_name, index=index)
    #     return TemporaryRemoteService(
    #         rpc_session=session,
    #         import_path=import_path,
    #         call_service_import=call_service_import,
    #         service_args=service_args,
    #         service_kwargs=service_kwargs
    #     )
