# temp_remote_service.py
# class TemporaryRemoteService(RemoteServiceUtility):
#     def __init__(self, rpc_session, import_path=None, call_service_import=False, service_args=None,
#                  service_kwargs=None, code=None, class_name=None, func_name=None,
#                  variable_name=None):
#         super(TemporaryRemoteService, self).__init__(rpc_session=rpc_session)
#         self.name = str(uuid4())
#         self.import_path = import_path
#         self.call_service_import = call_service_import
#         self.service_args = service_args
#         self.service_kwargs = service_kwargs
#         self.code = code
#         self._module_name = None
#         self._remote_service = None
#         self._class_name = class_name
#         self._func_name = func_name
#         self._var_name = variable_name
#         self.__opened = False
#
#     def __enter__(self):
#         return self.open()
#
#     def __exit__(self, exc_type, exc_val, exc_tb):
#         self.close()
#
#     def _extract_import_name_from_code(self):
#         if not any((self._func_name, self._class_name, self._var_name)):
#             raise ValueError(
#                 f'import_path or (func_name or class_name or variable_name) must be specified')
#
#         if self._func_name is not None:
#             func_names = code_parsing.get_function_names(self.code)
#
#             if self._func_name not in func_names:
#                 raise ValueError(f'func_name "{self._func_name}" not found in code')
#
#             import_name = self._func_name
#
#         elif self._class_name:
#             class_names = code_parsing.get_class_names(self.code)
#
#             if self._class_name not in class_names:
#                 raise ValueError(f'class_name "{self._class_name}" not found in code')
#
#             import_name = self._class_name
#
#         else:
#             variable_names = code_parsing.get_variable_names(self.code)
#
#             if self._var_name not in variable_names:
#                 raise ValueError(f'variable_name "{self._var_name}" not found in code')
#
#             import_name = self._var_name
#
#         return import_name
#
#     def _import_code(self):
#         self._module_name = str(uuid4())
#
#         if self.import_path is None:
#             import_name = self._extract_import_name_from_code()
#             self.import_path = f'{self._module_name}.{import_name}'
#
#         return self.import_remote_module(name=self._module_name, code=self.code)
#
#     def open(self):
#         if not self.__opened:
#
#             if self.code is not None:
#                 self._import_code()
#
#             self.add_remote_service(
#                 service_name=self.name,
#                 import_path=self.import_path,
#                 call_service_import=self.call_service_import,
#                 service_args=self.service_args,
#                 service_kwargs=self.service_kwargs
#             )
#
#             self._remote_service = self.get_remote_service(self.name)
#             self.__opened = True
#
#         return self._remote_service
#
#     def close(self):
#         if self.__opened:
#             self.remove_remote_service(service_name=self.name)
#             self._remote_service = None
#             self.__opened = False