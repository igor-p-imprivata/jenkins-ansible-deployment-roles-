# _protocol_magic.py


PROTOCOL_MAGIC = b'\x0e[\xecF'