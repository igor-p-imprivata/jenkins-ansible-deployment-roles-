# configurators.py
import logging
from zeus_utils import WheelMetadata
from zeus_rpc_service.definitions import (
    PLUGIN_NAME_ROOT, PLUGIN_NAME_CODE_IMPORTER, PLUGIN_NAME_PACKAGES, PLUGIN_NAME_FILES
)


class RemoteSessionConfigurator:
    def __init__(self, rpc_session):
        self._rpc_session = rpc_session

    def __repr__(self):
        return f'{self.__class__.__name__}(host="{self._rpc_session.host}", ' \
               f'station_name="{self._rpc_session.station_name}")'

    def get_remote_service(self, service_name_):
        self._rpc_session.raise_for_not_connected()
        return self._rpc_session.get_remote_plugin(service_name_)

    def call_remote_service(self, service_name_, method_name_, *args, **kwargs):
        remote_service = self.get_remote_service(service_name_=service_name_)
        method = getattr(remote_service, method_name_)
        return method(*args, **kwargs)

    def send_file(self, tag, src, dest_dir=None, cleanup=True):
        remote_file = self.call_remote_service(
            service_name_=PLUGIN_NAME_FILES,
            method_name_='send_file',
            src=src,
            dest_dir=dest_dir
        )

        cleanup_func = remote_file.delete if cleanup else None

        self._rpc_session.register_resource(
            tag=tag,
            resource=remote_file,
            cleanup_func=cleanup_func
        )

        return remote_file

    def update_services(self):
        return self._rpc_session.set_plugin_names()

    def find_remote_package(self, case_insensitive=True, sub_string=True, **attributes):
        return self.call_remote_service(
            service_name_=PLUGIN_NAME_PACKAGES,
            method_name_='find_package',
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def refresh_remote_packages(self):
        self.call_remote_service(
            service_name_=PLUGIN_NAME_PACKAGES,
            method_name_='refresh_packages'
        )

    def wait_for_remote_package(self, *, timeout=None, case_insensitive=True, sub_string=True,
                                **attributes):
        return self.call_remote_service(
            service_name_=PLUGIN_NAME_PACKAGES,
            method_name_='wait_for_package',
            timeout=timeout,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def install_remote_package(self, name=None, source=None, extra_args=None,
                               remote_source_path=None, force=False, wait_timeout=None):
        if name is None and source is None:
            raise ValueError('Either name or source must be specified')

        if source is not None and not source.endswith('.whl'):
            raise ValueError('Only wheel package format is supported')

        if source is not None:
            metadata = WheelMetadata(source)
            name = metadata.package_name
            existing_package = self.find_remote_package(name=name)

            if existing_package is not None:
                version = metadata.package_version
                existing_version = tuple(existing_package.version)

                if existing_version == version and not force:
                    # nothing to do
                    return existing_package

            remote_file = self.send_file(tag=source, src=source)
            package = remote_file.path

        elif remote_source_path is not None:
            package = remote_source_path

        else:
            package = name

        stdout = self.call_remote_service(
            service_name_=PLUGIN_NAME_PACKAGES,
            method_name_='install',
            package=package,
            extra_args=extra_args
        )

        # wait_for_package calls refresh_packages under the covers
        return self.wait_for_remote_package(
            timeout=wait_timeout,
            name=name,
            sub_string=False
        )

    def uninstall_remote_package(self, name=None, source=None, extra_args=None,
                                 remote_source_path=None):
        if name is None and source is None:
            raise ValueError('Either name or source must be specified')

        if source is not None and not source.endswith('.whl'):
            raise ValueError('Only wheel package format is supported')

        if name is None:
            metadata = WheelMetadata(source)
            name = metadata.package_name

        if self.find_remote_package(name=name, sub_string=False) is None:
            # package not installed, nothing to do
            return

        if source is not None and remote_source_path is None:
            remote_file = self.send_file(tag=source, src=source)
            remote_source_path = remote_file.path

        stdout = self.call_remote_service(
            service_name_=PLUGIN_NAME_PACKAGES,
            method_name_='uninstall',
            package=name,
            source=remote_source_path,
            extra_args=extra_args
        )

        self.unload_remote_module(name=name)
        self.refresh_remote_packages()

    def import_remote_module(self, name, code=None, path=None):
        if path is not None:
            remote_file = self.send_file(tag=path, src=path)
            path = remote_file.path

        return self.call_remote_service(
            service_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='import_module',
            name=name,
            code=code,
            path=path
        )

    def unload_remote_module(self, name, raise_if_non_existent=False):
        return self.call_remote_service(
            service_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='unload',
            full_name=name,
            raise_if_non_existent=raise_if_non_existent
        )

    def import_remote_package(self, package_info=None, name=None, location=None):
        if not any((package_info, name)):
            raise ValueError('Either package_info or name must be specified')

        if package_info is not None:
            name = package_info.name
            location = package_info.location

        elif location is None:
            package_info = self.find_remote_package(name=name)

            if package_info is None:
                raise ValueError(f'Package "{name}" not installed')

            location = package_info.location

        return self.call_remote_service(
            service_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='import_package',
            name=name,
            location=location
        )

    def get_remote_imports(self):
        return self.call_remote_service(
            service_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='enumerate'
        )

    def find_remote_import(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.call_remote_service(
            service_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='find',
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_remote_imports(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.call_remote_service(
            service_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='findall',
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def add_remote_service(self, service_name, import_path, call_service_import=False,
                           service_args=None, service_kwargs=None):
        result = self.call_remote_service(
            service_name_=PLUGIN_NAME_ROOT,
            method_name_='add_service',
            service_name=service_name,
            import_path=import_path,
            call_service_import=call_service_import,
            service_args=service_args,
            service_kwargs=service_kwargs

        )
        self.update_services()
        return result

    def remove_remote_service(self, service_name):
        result = self.call_remote_service(
            service_name_=PLUGIN_NAME_ROOT,
            method_name_='remove_service',
            name=service_name
        )
        self.update_services()
        return result

