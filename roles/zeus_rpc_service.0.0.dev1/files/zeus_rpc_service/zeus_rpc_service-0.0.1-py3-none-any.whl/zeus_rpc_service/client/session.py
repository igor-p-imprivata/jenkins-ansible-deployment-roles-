# session.py
import logging
from functools import partial
from enum import IntEnum
from xmlrpc.client import ServerProxy, Fault
from zeus_utils import WheelMetadata, ContextTimer
from zeus_rpc_service.definitions import (
    STATION_NAME_SERVICES, SERVICES_SESSION_ID, PLUGIN_NAME_ROOT, PLUGIN_NAME_CODE_IMPORTER,
    PLUGIN_NAME_PACKAGES, PLUGIN_NAME_FILES
)
from zeus_rpc_service.exceptions import ZeusRpcServiceError
from zeus_rpc_service.protocol import RpcRequestPacket, RpcResponsePacket
from zeus_rpc_service.plugins import RpcPluginManager
from .remote_plugins import RemotePluginManager
from .resources import RpcResourceManager


logger = logging.getLogger(__name__)


def normalize_url_path(url_path):
    if url_path is not None:
        if not url_path.startswith('/'):
            url_path = f'/{url_path}'

        if url_path.endswith('/'):
            url_path = url_path[:-1]

    else:
        url_path = ''

    return url_path


class DisconnectActions(IntEnum):
    NONE = 0
    CLEAR_SESSION = 1
    SHUTDOWN_SERVER = 2


class RpcSession:
    def __init__(self, host, port, url_path=None, station_name=STATION_NAME_SERVICES,
                 session_id=SERVICES_SESSION_ID):
        self.host = host
        self.port = port
        self.path = url_path
        self.station_name = station_name
        self.session_id = session_id
        self.server_url = f'http://{host}:{port}{normalize_url_path(url_path)}'
        self._server = ServerProxy(self.server_url, allow_none=True)
        self._session_uuid = None
        self._remote_plugin_manager = None
        self._rpc_plugin_manager = RpcPluginManager(self)
        self._resource_manager = None
        self._on_disconnect = None
        self._connected = False

    def __repr__(self):
        return f'{self.__class__.__name__}(station_name="{self.station_name}")'

    def __getattr__(self, item):
        return self.get_remote_plugin(item)

    @property
    def connected(self):
        return self._connected

    def send_request(self, rpc_request):
        rpc_request.session_uuid = self._session_uuid

        logger.debug(f'{repr(self)}: sending to server -> {str(rpc_request)}')

        request_binary = rpc_request.serialize()

        try:
            response_binary = self._server.handle_request(request_binary)
        except Fault as exc:
            raise ZeusRpcServiceError(exc)

        response = RpcResponsePacket.deserialize(response_binary, send_func=self.send_request)
        return response.unmarshal()

    def send_file(self, tag, src, dest_dir=None, cleanup=True):
        logger.debug(f'{repr(self)}: send_file -> {src}')

        with ContextTimer() as timer:
            remote_file = self.call_remote_plugin(
                plugin_name_=PLUGIN_NAME_FILES,
                method_name_='send_file',
                src=src,
                dest_dir=dest_dir
            )

        logger.debug(f'{repr(self)}: send_file -> elapsed seconds: {timer.elapsed}')

        cleanup_func = remote_file.delete if cleanup else None

        self.register_resource(
            tag=tag,
            resource=remote_file,
            cleanup_func=cleanup_func
        )

        return remote_file

    def copy_file(self, tag, src, dest_dir=None, file_name=None, fail_if_exists=False, cleanup=True):
        logger.debug(f'{repr(self)}: copy_file -> {src}')

        with ContextTimer() as timer:
            remote_file = self.call_remote_plugin(
                plugin_name_=PLUGIN_NAME_FILES,
                method_name_='copy_file',
                src=src,
                dest_dir=dest_dir,
                file_name=file_name,
                fail_if_exists=fail_if_exists
            )

        logger.debug(f'{repr(self)}: copy_file -> elapsed seconds: {timer.elapsed}')

        cleanup_func = remote_file.delete if cleanup else None

        self.register_resource(
            tag=tag,
            resource=remote_file,
            cleanup_func=cleanup_func
        )

        return remote_file

    def raise_for_not_connected(self):
        if not self._connected:
            raise RuntimeError(f'{repr(self)} not connected')

    def get_remote_plugin(self, plugin_name):
        self.raise_for_not_connected()
        return self._remote_plugin_manager.get_remote_plugin(plugin_name)

    def get_remote_globals(self):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='get_globals'
        )

    def get_remote_locals(self):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='get_locals'
        )

    def call_remote_plugin(self, plugin_name_, method_name_, *args, **kwargs):
        logger.debug(f'{repr(self)}: call_remote_plugin -> plugin_name_: {plugin_name_}, '
                     f'method_name_: {method_name_}, args: {args}, kwargs: {kwargs}')
        remote_plugin = self.get_remote_plugin(plugin_name=plugin_name_)
        method = getattr(remote_plugin, method_name_)
        return method(*args, **kwargs)

    def get_plugin_version_info(self):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='get_plugin_version_info'
        )

    def clear_state(self):
        self._session_uuid = None
        self._remote_plugin_manager = None
        self._resource_manager = None
        self._on_disconnect = None
        self._connected = False

    def set_on_disconnect(self, disconnect_action):
        if disconnect_action not in DisconnectActions:
            disconnect_action = DisconnectActions(disconnect_action)

        root_plugin = self.get_remote_plugin(PLUGIN_NAME_ROOT)

        if disconnect_action is DisconnectActions.CLEAR_SESSION:
            self._on_disconnect = partial(root_plugin.clear_session, self._session_uuid)

        elif disconnect_action is DisconnectActions.SHUTDOWN_SERVER:
            self._on_disconnect = root_plugin.shutdown_server

        else:
            self._on_disconnect = None

    def connect(self, disconnect_action=DisconnectActions.CLEAR_SESSION):
        logger.debug(f'{repr(self)}: connect -> creating session on server')

        root = RpcRequestPacket(
            send_func=self.send_request,
            plugin_name=PLUGIN_NAME_ROOT
        )

        self._session_uuid = session_uuid = root.create_session()

        logger.debug(f'{repr(self)}: connect -> created session_uuid: {session_uuid}')

        self._remote_plugin_manager = RemotePluginManager(
            send_func=self.send_request,
            session_uuid=session_uuid,
        )

        plugin_names = root.get_plugin_names()

        self._remote_plugin_manager.set_plugin_names(plugin_names)
        self._resource_manager = RpcResourceManager()
        self._connected = True

        logger.debug(f'{repr(self)}: successfully connected -> plugin_names: {plugin_names}')

        self.set_on_disconnect(disconnect_action)

    def disconnect(self):
        if not self._connected:
            return False

        logger.debug(f'{repr(self)}: disconnecting...')

        self.cleanup_resources()

        if self._on_disconnect is not None:
            self._on_disconnect()

        self.clear_state()
        return True

    def cleanup_resources(self):
        self.raise_for_not_connected()
        self._resource_manager.cleanup()

    def register_resource(self, tag, resource, cleanup_func=None):
        self.raise_for_not_connected()
        self._resource_manager.register(
            tag,
            resource=resource,
            cleanup_func=cleanup_func
        )

    def get_resource(self, tag):
        self.raise_for_not_connected()
        return self._resource_manager.get(tag)

    def update_plugin_names(self):
        plugin_names = self.get_plugin_names()
        self._remote_plugin_manager.set_plugin_names(plugin_names)
        return plugin_names

    def get_plugin_names(self):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='get_plugin_names'
        )

    def create_context(self, context_request):
        context_request.session_uuid = self._session_uuid
        return self.call_remote_plugin(
            context_request,
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='create_session_context',
        )

    def clear_context(self, context_uuid):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='clear_session_context',
            session_uuid=self._session_uuid,
            context_uuid=context_uuid
        )

    def find_remote_package(self, case_insensitive=True, sub_string=True, **attributes):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_PACKAGES,
            method_name_='find_package',
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def refresh_remote_packages(self):
        self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_PACKAGES,
            method_name_='refresh_packages'
        )

    def wait_for_remote_package(self, *, timeout=None, case_insensitive=True, sub_string=True,
                                **attributes):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_PACKAGES,
            method_name_='wait_for_package',
            timeout=timeout,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def install_remote_package(self, name=None, source=None, extra_args=None,
                               remote_source_path=None, force=False, wait_timeout=None):
        logger.debug(f'{repr(self)}: install_remote_package -> name: {name}, source: {source}, '
                     f'extra_args: {extra_args}, remote_source_path: {remote_source_path}, '
                     f'force: {force}, wait_timeout: {wait_timeout}')

        if name is None and source is None:
            raise ValueError('Either name or source must be specified')

        if source is not None and not source.endswith('.whl'):
            raise ValueError('Only wheel package format is supported')

        if source is not None:
            package = None
            wheel_metadata = WheelMetadata(source)
            name = wheel_metadata.package_name
            existing_package = self.find_remote_package(name=name)

            if existing_package is not None:
                version = wheel_metadata.package_version
                existing_version = tuple(existing_package.version)

                if existing_version == version and not force:
                    logger.info(f'{repr(self)}: install_remote_package -> {name} already installed')
                    # nothing to do
                    return existing_package

                remote_file = self.send_file(tag=source, src=source)
                package = remote_file.path
                self.uninstall_remote_package(source=source, remote_source_path=package)

            if package is None:
                remote_file = self.send_file(tag=source, src=source)
                package = remote_file.path

        elif remote_source_path is not None:
            package = remote_source_path

        else:
            package = name

        logger.info(f'{repr(self)}: install_remote_package -> installing "{package}"')

        stdout = self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_PACKAGES,
            method_name_='install',
            package=package,
            extra_args=extra_args
        )

        output = '\n'.join(f'\t{line}' for line in stdout.splitlines())
        logger.info(f'{repr(self)}: install_remote_package -> output: \n{output}')
        # wait_for_package calls refresh_packages under the covers
        self.wait_for_remote_package(timeout=wait_timeout, name=name, sub_string=False)

    def uninstall_remote_package(self, name=None, source=None, extra_args=None,
                                 remote_source_path=None):

        logger.debug(f'{repr(self)}: uninstall_remote_package -> name: {name}, source: {source}, '
                     f'extra_args: {extra_args}, remote_source_path: {remote_source_path}')

        if name is None and source is None:
            raise ValueError('Either name or source must be specified')

        if source is not None and not source.endswith('.whl'):
            raise ValueError('Only wheel package format is supported')

        if name is None:
            wheel_metadata = WheelMetadata(source)
            name = wheel_metadata.package_name

        if self.find_remote_package(name=name, sub_string=False) is None:
            logger.info(f'{repr(self)}: uninstall_remote_package -> package "{name}" not found')
            # package not installed, nothing to do
            return

        if source is not None and remote_source_path is None:
            remote_file = self.send_file(tag=source, src=source)
            remote_source_path = remote_file.path

        logger.info(f'{repr(self)}: uninstall_remote_package -> uninstalling "{name}"')

        stdout = self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_PACKAGES,
            method_name_='uninstall',
            package=name,
            source=remote_source_path,
            extra_args=extra_args
        )

        output = '\n'.join(f'\t{line}' for line in stdout.splitlines())

        logger.info(f'{repr(self)}: uninstall_remote_package -> output: \n{output}')

        self.unload_remote_module(name=name)
        self.refresh_remote_packages()

    def import_remote_module(self, name, code=None, path=None):
        if path is not None:
            remote_file = self.send_file(tag=path, src=path)
            path = remote_file.path

        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='import_module',
            name=name,
            code=code,
            path=path
        )

    def unload_remote_module(self, name, raise_if_non_existent=False):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='unload',
            full_name=name,
            raise_if_non_existent=raise_if_non_existent
        )

    def import_remote_package(self, package_info=None, name=None, location=None):
        if not any((package_info, name)):
            raise ValueError('Either package_info or name must be specified')

        if package_info is not None:
            name = package_info.name
            location = package_info.location

        elif location is None:
            package_info = self.find_remote_package(name=name)

            if package_info is None:
                raise ValueError(f'Package "{name}" not installed')

            location = package_info.location

        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='import_package',
            name=name,
            location=location
        )

    def get_remote_imports(self):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='iter_root_nodes'
        )

    def find_remote_import(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='find',
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_remote_imports(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_CODE_IMPORTER,
            method_name_='findall',
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def add_extended_request_handler(self, name, import_path, **kwargs):
        self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='add_ext_request_handler',
            name=name,
            import_path=import_path,
            **kwargs
        )

    def remove_extended_request_handler(self, name):
        self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='remove_ext_request_handler',
            name=name
        )

    def add_plugin(self, plugin_definition, force=False):
        self.raise_for_not_connected()
        return self._rpc_plugin_manager.add_plugin(
            plugin_definition,
            force=force
        )

    def remove_plugin(self, plugin_definition):
        self.raise_for_not_connected()
        return self._rpc_plugin_manager.remove_plugin(plugin_definition)

    def get_plugin(self, plugin_definition):
        return self._rpc_plugin_manager.get_plugin(plugin_definition)

    def spawn_rpc_server(self, session_id, port, python_exe=None, default_directory=None,
                         timeout=None, **kwargs):
        return self.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='spawn_rpc_server',
            session_id=session_id,
            port=port,
            python_exe=python_exe,
            default_directory=default_directory,
            timeout=timeout,
            **kwargs
        )
