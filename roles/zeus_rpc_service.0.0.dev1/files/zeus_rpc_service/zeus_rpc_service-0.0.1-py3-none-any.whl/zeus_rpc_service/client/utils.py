# utils.py
from uuid import uuid4
from zeus_rpc_service.definitions import PLUGIN_NAME_ROOT


class TemporaryRemoteService:
    def __init__(self, rpc_session, import_path, call_service_import=False, service_args=None,
                 service_kwargs=None):
        self._rpc_session = rpc_session
        self.name = str(uuid4())
        self.import_path = import_path
        self.call_service_import = call_service_import
        self.service_args = service_args
        self.service_kwargs = service_kwargs
        self._remote_service = None
        self.__opened = False

    def __enter__(self):
        return self.open()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def _add_remote_service(self):
        root_service = self._rpc_session.get_remote_plugin(PLUGIN_NAME_ROOT)

        result = root_service.add_plugin_from_implementation(
            plugin_name=self.name,
            import_path=self.import_path,
            call_plugin_import=self.call_service_import,
            plugin_args=self.service_args,
            plugin_kwargs=self.service_kwargs
        )

        self._rpc_session.set_plugin_names()
        return result

    def _get_remote_service(self):
        if self._remote_service is None:
            self._remote_service = self._rpc_session.get_remote_plugin(self.name)

        return self._remote_service

    def _remove_remote_service(self):
        root_service = self._rpc_session.get_remote_plugin(PLUGIN_NAME_ROOT)
        result = root_service.remove_plugin(name=self.name)
        self._rpc_session.set_plugin_names()
        return result

    def open(self):
        if not self.__opened:
            self._rpc_session.raise_for_not_connected()
            self._add_remote_service()
            self.__opened = True

        return self._get_remote_service()

    def close(self):
        if self.__opened:
            self._remove_remote_service()
            self.__opened = False

