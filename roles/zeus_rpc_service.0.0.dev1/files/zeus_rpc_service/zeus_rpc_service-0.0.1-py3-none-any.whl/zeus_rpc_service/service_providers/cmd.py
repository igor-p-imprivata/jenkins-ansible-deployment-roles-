# cmd.py
import subprocess as sp
from zeus_utils import SingletonMeta


# noinspection PyMethodMayBeStatic
class CommandPrompt(metaclass=SingletonMeta):

    def run(self, command_line, **kwargs):
        proc = sp.run(command_line, stdout=sp.PIPE, stderr=sp.PIPE, **kwargs)
        return {
            'args':   proc.args, 'returncode': proc.returncode, 'stdout': proc.stdout,
            'stderr': proc.stderr
        }


command_prompt = CommandPrompt()
