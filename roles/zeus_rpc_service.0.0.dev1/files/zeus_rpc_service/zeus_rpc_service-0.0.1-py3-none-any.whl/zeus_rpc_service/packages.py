# pip_cli.py
import os
import sys
from io import StringIO
from zeus_utils import find_by_attrs, findall_by_attrs, SingletonMeta

try:
    from pip import main as pip_main, get_installed_distributions
except ImportError:
    from pip._internal import main as pip_main
    from pip._internal.utils.misc import get_installed_distributions


def normalize_package_name(name):
    return name.replace('-', '_')


def normalize_package_version(version):
    version_parts = []

    for part_str in version.split('.'):
        try:
            part = int(part_str)
        except ValueError:
            part = part_str

        version_parts.append(part)

    return tuple(version_parts)


# noinspection PyMethodMayBeStatic
class PipCommandLineInterface(metaclass=SingletonMeta):
    def _pip_main(self, arg_list):
        orig_stdout, orig_stderr = sys.stdout, sys.stderr
        tmp_stdout, tmp_stderr = StringIO(), StringIO()
        sys.stdout, sys.stderr = tmp_stdout, tmp_stderr

        try:
            pip_main([arg_list])
        finally:
            sys.stdout, sys.stderr = orig_stdout, orig_stderr

        return tmp_stdout.getvalue(), tmp_stderr.getvalue()

    def install(self, package, extra_args=None):
        extra_args = extra_args or ()
        return self._pip_main(['install', package, *extra_args])

    def uninstall(self, package, source=None, extra_args=None):
        extra_args = extra_args or ()
        orig_cwd = os.getcwd()

        try:
            if source is not None:
                if os.path.isfile(source):
                    wd = os.path.dirname(source)

                elif os.path.isdir(source):
                    wd = source

                else:
                    raise ValueError(f'Invalid source: {source}')

                os.chdir(wd)

            return self._pip_main(['uninstall', package, *extra_args])

        finally:
            if os.getcwd() != orig_cwd:
                os.chdir(orig_cwd)


_pip_cli = PipCommandLineInterface()


class PackageInfo:
    @classmethod
    def from_pip_distribution(cls, distribution):
        name = normalize_package_name(distribution.project_name)
        version = normalize_package_version(distribution.version)
        return cls(name=name, location=distribution.location, version=version)

    def __init__(self, name, location, version):
        self.name = name
        self.location = location
        self.version = version

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", location="{self.location}", ' \
               f'version={self.version})'

    def __hash__(self):
        return hash((self.name, self.location) + self.version)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    def __getstate__(self):
        return {
            'name': self.name,
            'location': self.location,
            'version': self.version
        }

    def __setstate__(self, state):
        self.__dict__.update(state)

    def uninstall(self, source=None, extra_args=None):
        return _pip_cli.uninstall(package=self.name, source=source, extra_args=extra_args)


# noinspection PyMethodMayBeStatic
class PythonPackageManager(metaclass=SingletonMeta):
    def install(self, package, extra_args=None):
        return _pip_cli.install(package=package, extra_args=extra_args)

    def enumerate(self):
        for dist in get_installed_distributions():
            yield PackageInfo.from_pip_distribution(dist)

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(
            self.enumerate(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(
            self.enumerate(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )


package_manager = PythonPackageManager()
