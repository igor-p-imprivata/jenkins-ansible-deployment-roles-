# __main__.py
import sys
import argparse
from zeus_rpc_service.service import (
    install_service, remove_service, start_service, stop_service
)
from zeus_utils import config_logging


def main(args=None):
    if args is None:
        args = sys.argv[1:]

    parser = argparse.ArgumentParser(description='zeus_rpc_service')

    parser.add_argument(
        '--install',
        '-i',
        action='store_true',
        help='Install zeus_rpc_service.'
    )

    parser.add_argument(
        '--remove',
        '-r',
        action='store_true',
        help='Remove zeus_rpc_service.'
    )

    parser.add_argument(
        '--start',
        '-s',
        action='store_true',
        help='Start zeus_rpc_service.'
    )

    parser.add_argument(
        '--stop',
        '-x',
        action='store_true',
        help='Stop zeus_rpc_service.'
    )

    parser.add_argument(
        '--debug',
        '-d',
        action='store_true',
        help='Enable debug logging.'
    )

    parsed_args = parser.parse_args(args=args)

    if parsed_args.debug:
        config_logging('debug')

    if parsed_args.install:
        install_service()

    if parsed_args.start:
        start_service()

    if parsed_args.stop:
        stop_service()

    if parsed_args.remove:
        remove_service()


if __name__ == '__main__':
    main()
