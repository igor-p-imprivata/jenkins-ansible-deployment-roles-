# remote_services.py
import logging
import zipfile
from subprocess import CompletedProcess
from contextlib import contextmanager
from functools import partial
from zeus_utils import zip_to_bytes, SingletonMeta
from zeus_win32_utils import WConnectFlags, ComputerNameFormat
from zeus_rpc_service.protocol import RpcRequestPacket, RpcContextRequest, RpcRemoteObjectProxy
from zeus_rpc_service.definitions import (
    PLUGIN_NAME_ROOT, SVC_NAME_SYSTEM, SVC_NAME_DRIVES, PLUGIN_NAME_FILES, SVC_NAME_CMD,
    SVC_NAME_USERS, SVC_NAME_PROCESSES, SVC_NAME_MSI, SVC_NAME_REGISTRY, SVC_NAME_SESSIONS,
    PLUGIN_NAME_PACKAGES, PLUGIN_NAME_CODE_IMPORTER
)


logger = logging.getLogger(__name__)


class RemoteServiceRegistry(metaclass=SingletonMeta):
    def __init__(self):
        self.__service_types = {}
        self.__type_modified_cbs = set()

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def register_type(self, service_type):
        if not isinstance(service_type, type):
            raise TypeError('service_type must be a type')

        if not issubclass(service_type, RemoteService):
            raise TypeError(f'service_type must be a valid {RemoteService.__name__} subclass')

        # noinspection PyProtectedMember
        service_name = service_type._name_

        if service_name is None:
            return

        logger.debug(f'{repr(self)}: register_type -> service_name: {service_name}')

        if service_name in self.__service_types:
            for cb in self.__type_modified_cbs:
                cb(service_name)

        self.__service_types[service_name] = partial(service_type, service_name)

    def get_service(self, service_name, rpc_request, service_manager):
        service_type = self.__service_types.get(service_name)

        if service_type is None:
            service_type = partial(RemoteService, service_name)

        return service_type(rpc_request, service_manager)

    def add_service_type_modified_callback(self, callback):
        self.__type_modified_cbs.add(callback)

    def remove_service_type_modified_callback(self, callback):
        self.__type_modified_cbs.remove(callback)


remote_service_registry = RemoteServiceRegistry()


class RemoteServiceBase:
    def __init__(self, name, rpc_request, session_uuid):
        self.name = name
        self.rpc_request = rpc_request
        self.session_uuid = session_uuid

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    def __getattr__(self, item):
        return self.rpc_request.wrap_remote_attribute(item)

    def create_context_request(self):
        return RpcContextRequest(session_uuid=self.session_uuid)

    @contextmanager
    def session_context(self, context_uuid, cleanup=None):
        self.rpc_request.context_uuid = context_uuid

        try:
            yield self
        finally:
            self.rpc_request.context_uuid = None

            if cleanup is not None:
                cleanup()


class RemoteService(RemoteServiceBase):
    _name_ = None

    def __init__(self, name, rpc_request, service_manager):
        super(RemoteService, self).__init__(
            name=name,
            rpc_request=rpc_request,
            session_uuid=rpc_request.session_uuid
        )
        self.service_manager = service_manager


class RpcRemoteServiceManager(RemoteServiceBase):
    def __init__(self, send_func, session_uuid):
        rpc_request = RpcRequestPacket(
            send_func=send_func,
            plugin_name=PLUGIN_NAME_ROOT,
            session_uuid=session_uuid
        )

        super(RpcRemoteServiceManager, self).__init__(
            name=PLUGIN_NAME_ROOT,
            rpc_request=rpc_request,
            session_uuid=session_uuid
        )

        self.send_func = send_func
        self.service_names = set()
        self._services = {}
        remote_service_registry.add_service_type_modified_callback(self.on_service_type_modified)

    def __del__(self):
        remote_service_registry.remove_service_type_modified_callback(self.on_service_type_modified)

    def on_service_type_modified(self, service_name):
        service = self._services.pop(service_name, None)

        if service is not None:
            del service

    def create_rpc_packet(self, service_name):
        return RpcRequestPacket(
            send_func=self.send_func,
            plugin_name=service_name,
            session_uuid=self.session_uuid
        )

    def update_services(self, service_names):
        self.service_names.clear()
        self.service_names.update(name.lower() for name in service_names)
        self._services.clear()

    def get_remote_service(self, name=None):
        if name is None or name == self.name:
            return self

        lower_name = name.lower()

        if lower_name not in self.service_names:
            raise RuntimeError(f'Service "{name}" does not exist')

        remote_service = self._services.get(lower_name)

        if remote_service is None:
            remote_service = remote_service_registry.get_service(
                service_name=lower_name,
                rpc_request=self.create_rpc_packet(lower_name),
                service_manager=self
            )

        return remote_service

    def ping(self):
        return self.rpc_request.ping()

    def get_service_names(self):
        return self.rpc_request.get_local_plugin_names()

    def create_session(self):
        return self.rpc_request.create_session()

    def clear_session(self, session_uuid):
        self.rpc_request.clear_session(session_uuid=session_uuid)

    def get_session_count(self):
        return self.rpc_request.get_session_count()

    def shutdown_server(self):
        self.rpc_request.shutdown()

    def create_session_context(self, context_request=None, *, src_uuid=None, keyword_mapping=None):
        return self.rpc_request.create_session_context(
            context_request=context_request,
            src_uuid=src_uuid,
            keyword_mapping=keyword_mapping
        )

    def clear_session_context(self, context_uuid, session_uuid=None):
        session_uuid = session_uuid or self.session_uuid
        return self.rpc_request.clear_session_context(
            session_uuid=session_uuid,
            context_uuid=context_uuid
        )

    def add_service(self, service_name=None, import_path=None, call_service_import=False,
                    service_args=None, service_kwargs=None, context_uuid=None):

        if context_uuid is None:
            if service_name is None:
                raise ValueError(f'service_name must be specified')

            if import_path is None:
                raise ValueError(f'import_path must be specified')

            context_request = self.create_context_request()

            context_request.add_item_request(
                key='name',
                value=service_name,
                evaluated=True
            )

            context_request.add_item_request(
                key='service',
                import_path=import_path,
                call_import=call_service_import,
                call_args=service_args,
                call_kwargs=service_kwargs,
                evaluated=False
            )

            context_uuid = self.create_session_context(context_request)

        with self.session_context(context_uuid):
            return self.rpc_request.add_plugin_from_implementation()

    def remove_service(self, name):
        return self.rpc_request.remove_plugin(name=name)

    def add_ext_request_handler(self, name=None, import_path=None, context_uuid=None,
                                **handler_kwargs):

        if context_uuid is None:
            if name is None:
                raise ValueError(f'name must be specified')

            if import_path is None:
                raise ValueError(f'import_path must be specified')

            context_request = self.create_context_request()

            context_request.add_item_request(
                key='name',
                value=name,
                evaluated=True
            )

            context_request.add_item_request(
                key='ext_handler',
                import_path=import_path,
                call_import=True,
                call_kwargs=dict(name=name, **handler_kwargs),
                evaluated=False
            )

            context_uuid = self.create_session_context(context_request)

        with self.session_context(context_uuid):
            return self.rpc_request.add_ext_request_handler()

    def remove_ext_request_handler(self, name):
        return self.rpc_request.remove_ext_request_handler(name=name)

    def spawn_rpc_server(self, session_id, port, python_exe=None, default_directory=None,
                         timeout=None, **kwargs):
        return self.rpc_request.spawn_rpc_server(
            session_id=session_id,
            port=port,
            python_exe=python_exe,
            default_directory=default_directory,
            timeout=timeout,
            **kwargs
        )


@remote_service_registry.register_type
class SystemManagerService(RemoteService):
    _name_ = SVC_NAME_SYSTEM

    def get_process_bitness(self):
        return self.rpc_request.get_process_bitness()

    def get_os_bitness(self):
        return self.rpc_request.get_os_bitness()

    def initiate_system_shutdown(self, message=None, timeout=None, force_apps_closed=True,
                                 reboot=False):
        self.rpc_request.initiate_system_shutdown(
            message=message,
            timeout=timeout,
            force_apps_closed=force_apps_closed,
            reboot=reboot
        )

    def get_computer_name(self, name_format=ComputerNameFormat.DNS_FULLY_QUALIFIED):
        return self.rpc_request.get_computer_name(name_format=name_format)


@remote_service_registry.register_type
class DriveManagerService(RemoteService):
    _name_ = SVC_NAME_DRIVES

    def find_network_drive_by_name(self, remote_name):
        return self.rpc_request.find(remote_name=remote_name)

    def map_network_drive(self, remote_name, username, password, flags=WConnectFlags.TEMPORARY):
        drive = self.rpc_request.get_available_drive()
        drive.connect(
            remote_name=remote_name,
            username=username,
            password=password,
            flags=flags
        )
        return self.find_network_drive_by_name(remote_name)

    def disconnect_drives(self):
        self.rpc_request.disconnect_drives()


@remote_service_registry.register_type
class FileManagerService(RemoteService):
    _name_ = PLUGIN_NAME_FILES

    def copy_file(self, src, dest_dir=None, file_name=None, fail_if_exists=False):
        return self.rpc_request.copy_file(
            src=src,
            dest_dir=dest_dir,
            file_name=file_name,
            fail_if_exists=fail_if_exists
        )

    def send_file(self, src, dest_dir=None, compression=zipfile.ZIP_DEFLATED):
        data = zip_to_bytes(src, compression=compression)
        remote_files = self.rpc_request.unzip(
            data=data,
            compression=compression,
            extract_dir=dest_dir,
        )
        assert len(remote_files) > 0
        return remote_files[0]


@remote_service_registry.register_type
class CommandPromptService(RemoteService):
    _name_ = SVC_NAME_CMD

    def run(self, command_line, **kwargs):
        proc_kwargs = self.rpc_request.run(command_line, **kwargs)
        proc_kwargs['stdout'] = proc_kwargs['stdout'].decode('utf-8', 'strict')
        proc_kwargs['stderr'] = proc_kwargs['stderr'].decode('utf-8', 'strict')
        return CompletedProcess(**proc_kwargs)


@remote_service_registry.register_type
class UserManagerService(RemoteService):
    _name_ = SVC_NAME_USERS


@remote_service_registry.register_type
class ProcessManagerService(RemoteService):
    _name_ = SVC_NAME_PROCESSES

    def find_process(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.find(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_processes(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.findall(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )


@remote_service_registry.register_type
class MsiService(RemoteService):
    _name_ = SVC_NAME_MSI

    def find_product(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.find(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_products(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.findall(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )


@remote_service_registry.register_type
class RegistryService(RemoteService):
    _name_ = SVC_NAME_REGISTRY

    def get(self, *path, key_flag=0):
        return self.rpc_request.get(*path, key_flag=key_flag)


@remote_service_registry.register_type
class SessionManagerService(RemoteService):
    _name_ = SVC_NAME_SESSIONS

    def enumerate(self):
        return self.rpc_request.enumerate()

    def find_session(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.find(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_sessions(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.findall(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def get_console_session_id(self):
        return self.rpc_request.get_console_session_id()


@remote_service_registry.register_type
class PackageManagerService(RemoteService):
    _name_ = PLUGIN_NAME_PACKAGES

    def install(self, package, extra_args=None):
        proc_kwargs = self.rpc_request.install(package=package, extra_args=extra_args)
        proc = CompletedProcess(**proc_kwargs)
        return proc.stdout

    def uninstall(self, package, source=None, extra_args=None):
        if isinstance(package, RpcRemoteObjectProxy):
            package_name = package.name

        else:
            package_name = package

        package_info = self.find_package(name=package_name)

        if package_info is None:
            raise ValueError(f'Unable to find package: "{package}"')

        proc_kwargs = package_info.uninstall(source=source, extra_args=extra_args)
        proc = CompletedProcess(**proc_kwargs)
        return proc.stdout

    def refresh_packages(self):
        return self.rpc_request.refresh_packages()

    def enumerate(self):
        return self.rpc_request.enumerate()

    def wait_for_package(self, *, timeout=None, case_insensitive=True, sub_string=True,
                         **attributes):
        return self.rpc_request.wait_for_package(
            timeout=timeout,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def find_package(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.find(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_packages(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.findall(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )


@remote_service_registry.register_type
class CodeImporterService(RemoteService):
    _name_ = PLUGIN_NAME_CODE_IMPORTER

    def iter_nodes(self):
        return self.rpc_request.iter_nodes()

    def unload(self, full_name, raise_if_non_existent=False):
        return self.rpc_request.unload(full_name=full_name, raise_if_non_existent=raise_if_non_existent)

    def import_module(self, name, code=None, path=None):
        return self.rpc_request.import_module(name=name, code=code, path=path)

    def import_package(self, name, location):
        return self.rpc_request.import_package(name=name, location=location)

    def get_import(self, import_path, default=None):
        return self.rpc_request.get(import_path=import_path, default=default)

    def find_module(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.find(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_modules(self, *, case_insensitive=True, sub_string=True, **attributes):
        return self.rpc_request.findall(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )
