# providers.py
from zeus_rpc_service.protocol import RpcLocalObjectWrapper


class RpcServiceProviderManager:
    def __init__(self):
        self.__providers = {}

    def __contains__(self, item):
        if not isinstance(item, str):
            return False

        return item.lower() in self.__providers

    def __getitem__(self, item):
        if not isinstance(item, str):
            raise KeyError(item)

        return self.__providers[item.lower()]

    def keys(self):
        yield from self.__providers.keys()

    def values(self):
        yield from self.__providers.values()

    def items(self):
        yield from self.__providers.items()

    def add_provider(self, provider):
        if not isinstance(provider, RpcServiceProviderBase):
            raise TypeError(f'provider must be a valid {RpcServiceProviderBase.__name__} instance')

        if provider.name.lower() in self.__providers:
            raise ValueError(f'provider with name "{provider.name}" already exists')

        self.__providers[provider.name.lower()] = provider

    def remove_provider(self, name):
        name = name.lower()
        provider = self.__providers.get(name)

        if provider is not None:
            if isinstance(provider, CoreServiceProvider):
                raise RuntimeError(f'Cannot remove {CoreServiceProvider.__name__} types')

            self.__providers.pop(name)

    def add_core_provider(self, name, service):
        core_provider = CoreServiceProvider.from_object(obj=service, name=name)
        self.add_provider(provider=core_provider)

    def add_plugin(self, name, service):
        plugin = ServiceProviderPlugin.from_object(obj=service, name=name)
        self.add_provider(provider=plugin)

    def get_service(self, name):
        provider = self.__providers.get(name.lower())

        if provider is not None:
            return provider.object_wrapper

    def iter_providers_of_type(self, prov_type):
        if not issubclass(prov_type, RpcServiceProviderBase):
            raise TypeError(f'prov_type must be a valid {RpcServiceProviderBase.__name__} subclass')

        yield from filter(lambda p: isinstance(p, prov_type), self.__providers.values())

    def get_core_provider_names(self):
        return map(lambda prov: prov.name, self.iter_providers_of_type(CoreServiceProvider))

    def get_plugin_names(self):
        return map(lambda prov: prov.name, self.iter_providers_of_type(ServiceProviderPlugin))


class RpcServiceProviderBase:
    @classmethod
    def from_object(cls, obj, *, name, **kwargs):
        object_wrapper = RpcLocalObjectWrapper()
        object_wrapper.wrap(obj)
        return cls(name=name, object_wrapper=object_wrapper, **kwargs)

    def __init__(self, object_wrapper, *, name, **kwargs):
        self.object_wrapper = object_wrapper
        self.name = name


class CoreServiceProvider(RpcServiceProviderBase):
    pass


class ServiceProviderPlugin(RpcServiceProviderBase):
    pass
