# core.py
from zeus_rpc_service.protocol import RpcLocalObjectWrapper


class RpcPluginBase:
    @classmethod
    def from_implementation(cls, implementation, *, name, **kwargs):
        impl_wrapper = RpcLocalObjectWrapper()
        impl_wrapper.wrap(implementation)
        return cls(name=name, impl_wrapper=impl_wrapper, **kwargs)

    def __init__(self, impl_wrapper, *, name, **kwargs):
        self.impl_wrapper = impl_wrapper
        self.name = name


class ImmutableRpcPlugin(RpcPluginBase):
    pass


class RpcPlugin(RpcPluginBase):
    pass


class RpcPluginManager:
    def __init__(self):
        self.__plugins = {}

    def __contains__(self, item):
        if not isinstance(item, str):
            return False

        return item.lower() in self.__plugins

    def __getitem__(self, item):
        if not isinstance(item, str):
            raise KeyError(item)

        return self.__plugins[item.lower()]

    def keys(self):
        yield from self.__plugins.keys()

    def values(self):
        yield from self.__plugins.values()

    def items(self):
        yield from self.__plugins.items()

    def add(self, name, implementation, plugin_type, **kwargs):
        if not issubclass(plugin_type, RpcPluginBase):
            raise TypeError(f'plugin_type must be a valid {RpcPluginBase.__name__} subclass')

        if name.lower() in self.__plugins:
            raise ValueError(f'plugin with name "{name}" already exists')

        plugin = plugin_type.from_implementation(
            implementation=implementation,
            name=name,
            **kwargs
        )

        self.__plugins[plugin.name.lower()] = plugin

    def remove(self, name):
        name = name.lower()
        plugin = self.__plugins.get(name)

        if plugin is not None:
            if isinstance(plugin, ImmutableRpcPlugin):
                raise RuntimeError(f'Cannot remove {ImmutableRpcPlugin.__name__} types')

            self.__plugins.pop(name)

    def add_plugin(self, name, implementation):
        self.add(name=name, implementation=implementation, plugin_type=RpcPlugin)

    def add_immutable_plugin(self, name, implementation):
        self.add(name=name, implementation=implementation, plugin_type=ImmutableRpcPlugin)

    def get_implementation(self, name):
        plugin = self.__plugins.get(name.lower())

        if plugin is not None:
            return plugin.impl_wrapper

    def iter_plugins(self, plugin_type=None):
        if plugin_type is not None:
            if not issubclass(plugin_type, RpcPlugin):
                raise TypeError(f'prov_type must be a valid {RpcPlugin.__name__} subclass')

            iter_plugins = filter(lambda p: isinstance(p, plugin_type), self.__plugins.values())

        else:
            iter_plugins = self.__plugins.values()

        yield from iter_plugins

    def get_immutable_plugin_names(self):
        return map(lambda prov: prov.name, self.iter_plugins(ImmutableRpcPlugin))

    def get_plugin_names(self):
        return map(lambda prov: prov.name, self.iter_plugins(RpcPlugin))
