# importer.py
import os
import sys
import logging
import importlib.util as importlib_util
from importlib import invalidate_caches
from zeus_utils import find_by_attrs, findall_by_attrs


logger = logging.getLogger(__name__)


def create_module_spec(name, path=None):
    if path is not None:
        return importlib_util.spec_from_file_location(name, path)

    return importlib_util.spec_from_loader(name, loader=None)


def import_module_from_spec(spec, code=None, update_sys_modules=True):
    module_ = importlib_util.module_from_spec(spec)

    if update_sys_modules:
        sys.modules[spec.name] = module_

    if code is not None:
        exec(code, module_.__dict__)

    else:
        spec.loader.exec_module(module_)

    return module_


class ModuleNode:
    def __init__(self, key, module_):
        self.__key = key
        self.__module = module_
        self._path = module_.__name__.split('.')
        self._parent = None
        self._children = {}

    def __repr__(self):
        return f'{self.__class__.__name__}(full_name="{self.full_name}")'

    def __str__(self):
        return '\n'.join(self._get_lines())

    def __hash__(self):
        value = self.full_name

        if self.file is not None:
            value += self.file

        return hash(value)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    def __getitem__(self, item):
        if item in self._children:
            return self._children[item]

        return getattr(self.__module, item)

    def __iter__(self):
        for child_node in self._children.values():
            yield child_node

            for descendant_node in child_node:
                yield descendant_node

    @property
    def key(self):
        return self.__key

    @property
    def root_name(self):
        if self._path:
            return self._path[0]

    @property
    def parent_name(self):
        if self._parent is None:
            if len(self._path) > 1:
                return self._path[1]

        else:
            return self.parent.name

    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self, value):
        if not isinstance(value, ModuleNode):
            raise TypeError(f'parent must be a valid {ModuleNode.__name__} instance')

        self._parent = value

    @property
    def name(self):
        if self._path:
            return self._path[-1]

    @property
    def full_name(self):
        return self.__module.__name__

    @property
    def file(self):
        try:
            return self.__module.__file__
        except AttributeError:
            return None

    @property
    def children(self):
        return tuple(self._children.values())

    @property
    def path(self):
        return tuple(self._path)

    def _get_lines(self, lines=None, tab_offset=0):
        if lines is None:
            lines = []

        lines.append(tab_offset * (' ' * 4) + repr(self))

        for child in self._children.values():
            # noinspection PyProtectedMember
            child._get_lines(lines=lines, tab_offset=tab_offset + 1)

        return lines

    def add_child(self, child_node):
        self._children[child_node.name] = child_node
        child_node.parent = self

    def is_child(self, node):
        conditions = [
            isinstance(node, ModuleNode),
            node.root_name == self.root_name,
            len(node.path) > 1,
            node.path[-2] == self.name
        ]
        return all(conditions)

    def clear(self):
        for node in self:
            node.clear()

        self._children.clear()

    def unload(self):
        for node in self:
            node.unload()

        logger.debug(f'{repr(self)}: unload')
        sys.modules.pop(self.__key)
        module_ = self.__module
        self.__module = None
        del module_
        self.clear()

    def unload_child(self, name, raise_if_non_existent=False):
        child_node = self._children.pop(name, None)

        if child_node is not None:
            child_node.unload()
            del child_node

        elif raise_if_non_existent:
            raise ValueError(f'{repr(self)} has no child named "{name}"')


# noinspection PyMethodMayBeStatic
class PythonCodeImporter:
    def __init__(self):
        self.__nodes = {}
        self.__nodes_loaded = False

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def __contains__(self, item):
        return item in sys.modules

    def __iter__(self):
        yield from self.iter_root_nodes()

    def _ensure_nodes(self):
        if not self.__nodes_loaded:
            nodes_by_depth = {}

            for key, module_ in self._enumerate():
                node = ModuleNode(key, module_)
                depth = len(node.path) - 1
                nodes_by_depth.setdefault(depth, set())
                nodes_by_depth[depth].add_from_implementation(node)

            parent_nodes = nodes_by_depth.pop(0)
            self.__nodes.update((node.name, node) for node in parent_nodes)
            current_depth = 1

            while nodes_by_depth:
                child_nodes = nodes_by_depth.pop(current_depth)
                child_nodes_ = set(child_nodes)

                while child_nodes_:

                    for child_node in child_nodes:

                        for parent_node in parent_nodes:

                            if parent_node.is_child(child_node):
                                child_nodes_.remove(child_node)
                                parent_node.add_child(child_node)
                                break

                parent_nodes = child_nodes
                current_depth += 1

            self.__nodes_loaded = True

    def _clear_nodes(self):
        self.__nodes.clear()
        self.__nodes_loaded = False

    def _enumerate(self):
        for name, module_ in sys.modules.items():
            logger.debug(f'{repr(self)}: enumerate -> name: {name}, module: {repr(module_)}')

            if not isinstance(module_, type):
                yield name, module_

    def iter_root_nodes(self):
        self._ensure_nodes()

        for root_node in self.__nodes.values():
            yield root_node

    def iter_nodes(self):
        for root_node in self.iter_root_nodes():
            yield root_node
            yield from root_node

    def refresh_nodes(self):
        self._clear_nodes()
        self._ensure_nodes()

    def unload(self, full_name, raise_if_non_existent=False):
        self._ensure_nodes()
        should_raise = False

        node = self.find(full_name=full_name)

        if node is not None:
            parent = node.parent

            if parent is not None:
                parent.unload_child(
                    name=node.name,
                    raise_if_non_existent=raise_if_non_existent
                )

            else:
                root_node = self.__nodes.pop(node.name, None)

                if root_node is not None:
                    root_node.unload()
                    del root_node

                elif raise_if_non_existent:
                    should_raise = True

        elif raise_if_non_existent:
            should_raise = True

        if should_raise:
            raise ValueError(f'Unable to find {ModuleNode.__name__} with full_name: "{full_name}"')

    def import_module(self, name, code=None, path=None):
        if code is None and path is None:
            raise ValueError('Either code or path must be specified')

        invalidate_caches()
        spec = create_module_spec(name, path=path)
        import_module_from_spec(spec, code=code)
        self._clear_nodes()

    def import_package(self, name, location):
        logger.info(f'{repr(self)}: import_package -> name: "{name}", location: "{location}"')
        init_path = os.path.join(location, f'{name}\\__init__.py')
        self.import_module(name=name, path=init_path)

    def get(self, import_path, default=None):
        self._ensure_nodes()
        top_level_name, *descendant_names = import_path.split('.')
        current_obj = sys.modules.get(top_level_name)

        if current_obj is None:
            return default

        for name in descendant_names:
            current_obj = getattr(current_obj, name, None)

            if current_obj is None:
                return default

        return current_obj

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(
            self.iter_nodes(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(
            self.iter_nodes(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )
