# core.py
import logging
from functools import partial
from zeus_rpc_service.protocol import RpcLocalObjectWrapper


logger = logging.getLogger(__name__)


class LocalPluginBase:
    def __init__(self, name, implementation=None):
        self.name = name
        self._interface = RpcLocalObjectWrapper()
        self._implementation = RpcLocalObjectWrapper()
        self.local_plugin_manager = None

        self._interface.wrap(self)

        if implementation is not None:
            self._implementation.wrap(implementation)

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    def __getattr__(self, item):
        if item in self._interface:
            return getattr(self._interface, item)

        return getattr(self._implementation, item)

    def __call__(self, attribute_name, *args, **kwargs):
        if attribute_name in self._interface:
            return self._interface(attribute_name, *args, **kwargs)

        return self._implementation(attribute_name, *args, **kwargs)

    def get_plugin(self, name, default=None):
        if self.local_plugin_manager is None:
            return default

        return self.local_plugin_manager.get_plugin(name, default)


class ImmutableLocalPlugin(LocalPluginBase):
    pass


class LocalPlugin(LocalPluginBase):
    def __init__(self, name, version, implementation=None):
        self.version = version
        super(LocalPlugin, self).__init__(name=name, implementation=implementation)

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", version={self.version})'


class LocalPluginManager:
    def __init__(self):
        self.__plugins = {}

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def __contains__(self, item):
        if not isinstance(item, str):
            return False

        return item.lower() in self.__plugins

    def __getitem__(self, item):
        if not isinstance(item, str):
            raise KeyError(item)

        return self.__plugins[item.lower()]

    def __iter__(self):
        yield from self.keys()

    def keys(self):
        for key in self.__plugins.keys():
            yield key

    def values(self):
        for value in self.__plugins.values():
            yield value

    def items(self):
        for key, value in self.__plugins.items():
            yield key, value

    def remove_plugin(self, name):
        logger.debug(f'{repr(self)}: remove_plugin -> name: {name}')

        name = name.lower()
        plugin = self.__plugins[name]

        if isinstance(plugin, ImmutableLocalPlugin):
            raise RuntimeError(f'Cannot remove {ImmutableLocalPlugin.__name__} types')

        self.__plugins.pop(name)
        plugin.local_plugin_manager = None

    def add_plugin(self, plugin):
        if not isinstance(plugin, LocalPluginBase):
            raise TypeError(f'plugin must be a valid {LocalPluginBase.__name__} instance')

        plugin_key = plugin.name.lower()

        if plugin_key in self.__plugins:
            raise ValueError(f'plugin with name "{plugin.name}" already exists')

        self.__plugins[plugin_key] = plugin
        plugin.local_plugin_manager = self

    def get_plugin(self, name, default=None):
        return self.__plugins.get(name.lower(), default)

    def add_plugin_from_implementation(self, name, implementation, plugin_type=LocalPlugin,
                                       **kwargs):
        if not issubclass(plugin_type, LocalPluginBase):
            raise TypeError(f'plugin_type must be a valid {LocalPluginBase.__name__} subclass')

        plugin = plugin_type(name=name, implementation=implementation, **kwargs)
        return self.add_plugin(plugin=plugin)

    def get_implementation(self, name):
        local_plugin = self.__plugins.get(name.lower())

        if local_plugin is not None:
            return local_plugin.implementation

    def iter_plugins(self, plugin_type=None):
        if plugin_type is not None:
            if not issubclass(plugin_type, LocalPlugin):
                raise TypeError(f'prov_type must be a valid {LocalPlugin.__name__} subclass')

            iter_plugins = filter(lambda p: isinstance(p, plugin_type), self.__plugins.values())

        else:
            iter_plugins = self.__plugins.values()

        yield from iter_plugins

    def get_immutable_plugin_names(self):
        return map(lambda plugin: plugin.name, self.iter_plugins(ImmutableLocalPlugin))

    def get_local_plugin_names(self):
        return map(lambda plugin: plugin.name, self.iter_plugins(LocalPlugin))

    def get_plugin_version_info(self):
        # noinspection PyUnresolvedReferences
        return {plugin.name.lower(): plugin.version for plugin in self.iter_plugins(LocalPlugin)}
