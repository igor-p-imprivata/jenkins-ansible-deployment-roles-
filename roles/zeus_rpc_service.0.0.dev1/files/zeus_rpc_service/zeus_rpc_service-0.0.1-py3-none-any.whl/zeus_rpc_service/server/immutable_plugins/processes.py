# processes.py
import logging
import win32ts
import win32security
import win32profile
from zeus_utils import (
    find_by_attrs,
    findall_by_attrs,
)
from zeus_win32_utils import (
    create_process_as_user,
    get_startup_info,
    ProcessPriorityClass,
    Desktops
)


logger = logging.getLogger(__name__)


class Process:
    __slots__ = ('session_id', 'pid', 'name', 'user_sid')

    @classmethod
    def from_process_info(cls, process_info):
        session_id, process_id, process_name, user_sid = process_info

        if user_sid is not None:
            user_sid = win32security.ConvertSidToStringSid(user_sid)

        return cls(session_id=session_id, process_id=process_id, process_name=process_name,
                   user_sid=user_sid)

    def __init__(self, session_id, process_id, process_name, user_sid):
        self.session_id = session_id
        self.pid = process_id
        self.name = process_name
        self.user_sid = user_sid

    def __str__(self):
        return f'{self.__class__.__name__}(session_id={self.session_id}, ' \
               f'pid={self.pid}, name="{self.name}", user_sid="{self.user_sid}")'


# noinspection PyMethodMayBeStatic
class ProcessManager:
    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def enumerate(self):
        for process_info in win32ts.WTSEnumerateProcesses():
            yield Process.from_process_info(process_info)

    def terminate(self, process_id, exit_code=0):
        win32ts.WTSTerminateProcess(win32ts.WTS_CURRENT_SERVER_HANDLE, process_id, exit_code)

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(self.enumerate(), case_insensitive=case_insensitive,
                             sub_string=sub_string, attrs=attributes)

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(self.enumerate(), case_insensitive=case_insensitive,
                                sub_string=sub_string, attrs=attributes)

    def create_process_in_session(self, session_id, *args, app_name=None, process_sa=None,
                                  thread_sa=None, inherit_handles=False,
                                  creation_flags=ProcessPriorityClass.NORMAL,
                                  current_directory=None, desktop=Desktops.DEFAULT,
                                  show_window=True, inherit_environment=False):
        logger.debug(f'{repr(self)}: create_process_in_session -> \n\tsession_id: {session_id}, '
                     f'\n\targs: {args}, \n\tapp_name: {app_name}, \n\tprocess_sa: {process_sa}, '
                     f'\n\tthread_sa: {thread_sa}, \n\tinherit_handles: {inherit_handles}, '
                     f'\n\tcreation_flags: {creation_flags}, '
                     f'\n\tcurrent_directory: {current_directory}, '
                     f'\n\tdesktop: {desktop}, \n\tshow_window: {show_window}, '
                     f'\n\tinherit_environment: {inherit_environment}')

        token = win32ts.WTSQueryUserToken(session_id)

        startup_info = get_startup_info(desktop, show_window=show_window)

        environment = win32profile.CreateEnvironmentBlock(token, inherit_environment)

        pid = create_process_as_user(
            *args,
            token=token,
            startup_info=startup_info,
            app_name=app_name,
            process_sa=process_sa,
            thread_sa=thread_sa,
            inherit_handles=inherit_handles,
            creation_flags=creation_flags,
            current_directory=current_directory,
            environment=environment
        )

        logger.debug(f'{repr(self)}: create_process_in_session -> process_id: {pid}')
        return pid
