# plugins.py
import os
import logging
from collections import Iterable
from zeus_utils import (
    kwargs2str, get_containing_package_name, get_package_root_directory, get_import_path,
    DefinitionFile, PackageBuilder, SingletonMeta
)
from zeus_rpc_service.definitions import PLUGIN_NAME_ROOT
from zeus_rpc_service.client.remote_plugins import (
    remote_plugin_registry, RemotePlugin
)
from zeus_rpc_service.server import LocalPlugin, ExtendedRequestHandler


logger = logging.getLogger(__name__)

# TODO -> handle plugins that are ext request handlers


def raise_for_value_subclass(var_name, var_value, parent_class):
    if not isinstance(parent_class, type):
        raise RuntimeError(f'parent_class must be a valid type')

    if not issubclass(var_value, parent_class):
        raise TypeError(f'{var_name} must be a valid {parent_class.__name__} subclass')


def raise_for_invalid_version_format(version):
    if not isinstance(version, tuple) or len(version) != 3:
        raise TypeError(f'Version must be a tuple of length 3. Invalid version format: {version}')

    invalid_elements = tuple(filter(lambda i: not isinstance(i, int), version))

    if invalid_elements:
        raise ValueError(f'Version elements must be integers. Invalid version elements: '
                         f'{invalid_elements}')


class RpcPluginDefinitionFile(DefinitionFile):
    def __init__(self, file_path):
        super(RpcPluginDefinitionFile, self).__init__(file_path=file_path)

        self.add_expected_name(
            name='PLUGIN_NAME',
            converter=lambda v: v.replace('\'', '')
        )

        self.add_expected_name(
            name='PACKAGE_NAME',
            converter=lambda v: v.replace('\'', '')
        )

        self.add_expected_name(
            name='VERSION',
            converter=eval,
            default=(0, 0, 0)
        )

        self.add_expected_name(
            name='INSTALL_REQUIRES',
            converter=eval,
            default=[]
        )

    @property
    def plugin_name(self):
        self.parse()
        return self.get('PLUGIN_NAME')

    @property
    def package_name(self):
        self.parse()
        return self.get('PACKAGE_NAME')

    @property
    def version(self):
        self.parse()
        return self.get('VERSION')

    @property
    def install_requires(self):
        self.parse()
        return self.get('INSTALL_REQUIRES')


class PluginDefinition(metaclass=SingletonMeta):
    def __init__(self, definition_file_path, local_plugin_type, remote_plugin_type, name=None,
                 version=None, package_installer=None, required_plugins=None,
                 **dependency_installers):

        self._local_plugin_type = None
        self._remote_plugin_type = None
        self._required_plugins = set()
        self._version = None
        self._package_installer = package_installer
        self._local_plugin_import_path = None

        self.definition_file = RpcPluginDefinitionFile(definition_file_path)
        self.definition_file.parse()

        self.name = name or self.definition_file.plugin_name
        self.version = version or self.definition_file.version
        self.local_plugin_type = local_plugin_type
        self.remote_plugin_type = remote_plugin_type
        self.dependency_installers = {}

        for package_name, installer_path in dependency_installers.items():
            self.add_dependency_installer(
                package_name=package_name,
                installer_path=installer_path
            )

        if required_plugins is not None:
            self.required_plugins = required_plugins

        remote_plugin_registry.register(
            plugin_type=self.remote_plugin_type,
            plugin_name=self.name
        )

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", version={self.version})'

    @property
    def version(self):
        return self._version

    @version.setter
    def version(self, value):
        raise_for_invalid_version_format(value)
        self._version = value

    @property
    def local_plugin_type(self):
        return self._local_plugin_type

    @local_plugin_type.setter
    def local_plugin_type(self, value):
        raise_for_value_subclass('local_plugin_type', value, LocalPlugin)
        self._local_plugin_type = value

    @property
    def remote_plugin_type(self):
        return self._remote_plugin_type

    @remote_plugin_type.setter
    def remote_plugin_type(self, value):
        raise_for_value_subclass('remote_plugin_type', value, RemotePlugin)
        self._remote_plugin_type = value

    @property
    def required_plugins(self):
        return tuple(self._required_plugins)

    @required_plugins.setter
    def required_plugins(self, value):
        plugins = value if isinstance(value, Iterable) else (value,)

        for plugin in plugins:
            self.raise_for_invalid_plugin_definition(plugin)

        self._required_plugins.clear()
        self._required_plugins.update(plugins)

    @property
    def package_installer(self):
        if self._package_installer is None:
            self._package_installer = self.build_local_package()

        return self._package_installer

    @property
    def package_name(self):
        return get_containing_package_name(self._local_plugin_type)

    @property
    def local_plugin_import_path(self):
        if self._local_plugin_import_path is None and self._local_plugin_type is not None:
            self._local_plugin_import_path = get_import_path(self._local_plugin_type)

        return self._local_plugin_import_path

    @staticmethod
    def raise_for_invalid_plugin_definition(value):
        if isinstance(value, type):
            if not issubclass(value, PluginDefinition):
                raise TypeError(f'plugins must be valid {PluginDefinition.__name__} subclasses')

        elif not isinstance(value, PluginDefinition):
            raise TypeError(f'plugins must be valid {PluginDefinition.__name__} instances')

    def build_local_package(self):
        local_plugin_type = self._local_plugin_type

        if local_plugin_type is None:
            return

        kwargs = dict(
            package_name=self.definition_file.package_name,
            version_tuple=self.definition_file.version,
            package_root=get_package_root_directory(local_plugin_type),
            install_requires=self.definition_file.install_requires,
            use_wheel=True
        )

        logger.info(f'{repr(self)}: build_local_package -> {kwargs2str(**kwargs)}')

        package_builder = PackageBuilder(**kwargs)
        return package_builder.build()

    def add_dependency_installer(self, package_name, installer_path):
        self.dependency_installers[package_name] = os.path.abspath(installer_path)


class RpcPluginManager:
    def __init__(self, rpc_session):
        self._rpc_session = rpc_session
        self._root_plugin = None

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def _install_ext_request_handler(self, plugin_definition: PluginDefinition):
        ext_ctx = self._rpc_session.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='create_context_request',
        )

        ext_ctx.add_item_request(
            key='ext_handler',
            import_path=plugin_definition.local_plugin_import_path,
            call_import=True,
            evaluated=False,
            call_args=(plugin_definition.version,)
        )

        ext_ctx_uuid = self._rpc_session.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='create_session_context',
            context_request=ext_ctx
        )

        self._rpc_session.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='add_ext_request_handler',
            context_uuid=ext_ctx_uuid
        )

        return ext_ctx_uuid

    def _uninstall_ext_request_handler(self, plugin_definition: PluginDefinition):
        self._rpc_session.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='remove_ext_request_handler',
            name=plugin_definition.name
        )

    def _install_plugin(self, plugin_definition: PluginDefinition, force: bool = False):
        logger.debug(f'{repr(self)}: _install_plugin -> plugin_definition: {repr(plugin_definition)}, '
                     f'force: {force}')

        ctx_uuids = set()

        self._rpc_session.install_remote_package(
            name=plugin_definition.package_name,
            source=plugin_definition.package_installer,
            force=force
        )

        plugin_ctx = self._rpc_session.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='create_context_request',
        )

        if issubclass(plugin_definition.local_plugin_type, ExtendedRequestHandler):
            ext_ctx_uuid = self._install_ext_request_handler(plugin_definition)
            ctx_uuids.add(ext_ctx_uuid)

            keyword_mapping = [('ext_handler', 'plugin')]

            plugin_ctx_uuid = self._rpc_session.call_remote_plugin(
                plugin_name_=PLUGIN_NAME_ROOT,
                method_name_='create_session_context',
                context_request=plugin_ctx,
                src_uuid=ext_ctx_uuid,
                keyword_mapping=keyword_mapping
            )

        else:
            plugin_ctx.add_item_request(
                key='plugin',
                import_path=plugin_definition.local_plugin_import_path,
                call_import=True,
                call_args=(plugin_definition.version,),
                evaluated=False
            )

            plugin_ctx_uuid = self._rpc_session.call_remote_plugin(
                plugin_name_=PLUGIN_NAME_ROOT,
                method_name_='create_session_context',
                context_request=plugin_ctx
            )

        ctx_uuids.add(plugin_ctx_uuid)

        try:
            self._rpc_session.call_remote_plugin(
                plugin_name_=PLUGIN_NAME_ROOT,
                method_name_='add_plugin',
                context_uuid=plugin_ctx_uuid
            )

            self._rpc_session.update_plugin_names()

        finally:
            for ctx_uuid in ctx_uuids:
                self._rpc_session.call_remote_plugin(
                    plugin_name_=PLUGIN_NAME_ROOT,
                    method_name_='clear_session_context',
                    context_uuid=ctx_uuid
                )

        return self._rpc_session.get_remote_plugin(plugin_definition.name)

    def _uninstall_plugin(self, plugin_definition: PluginDefinition):
        logger.debug(f'{repr(self)}: _uninstall_plugin -> plugin_definition: {repr(plugin_definition)}')

        if issubclass(plugin_definition.local_plugin_type, ExtendedRequestHandler):
            self._uninstall_ext_request_handler(plugin_definition)

        self._rpc_session.call_remote_plugin(
            plugin_name_=PLUGIN_NAME_ROOT,
            method_name_='remove_plugin',
            name=plugin_definition.name
        )

        self._rpc_session.uninstall_remote_package(
            name=plugin_definition.package_name,
            # source=plugin_definition.package_installer
        )

        remote_plugin_registry.unregister(
            plugin_type=plugin_definition.remote_plugin_type,
            plugin_name=plugin_definition.name
        )
        self._rpc_session.update_plugin_names()

    @staticmethod
    def _normalize_plugin_definition(plugin_definition):
        if isinstance(plugin_definition, type):

            if not issubclass(plugin_definition, PluginDefinition):
                raise TypeError(f'plugin_definition must be a valid {PluginDefinition.__name__} subclass')

            plugin_definition = plugin_definition()

        if not isinstance(plugin_definition, PluginDefinition):
            raise TypeError(f'plugin_definition must be a valid {PluginDefinition.__name__} instance')

        return plugin_definition

    def get_plugin(self, plugin_definition: PluginDefinition):
        plugin_definition = self._normalize_plugin_definition(plugin_definition)
        return self._rpc_session.get_remote_plugin(plugin_definition.name)

    def add_plugin(self, plugin_definition: PluginDefinition, force=False):
        plugin_definition = self._normalize_plugin_definition(plugin_definition)

        logger.debug(f'{repr(self)}: add_plugin -> plugin_definition: {repr(plugin_definition)}, force: {force}')

        plugin_name = plugin_definition.name.lower()

        if plugin_definition.remote_plugin_type is None:
            raise ValueError(f'remote_plugin_type must be set')

        if plugin_definition.local_plugin_type is None:
            raise ValueError(f'local_plugin_type must be set')

        existing_version_info = self._rpc_session.get_plugin_version_info()
        version = existing_version_info.get(plugin_name)

        if version is not None:
            if not force and version >= plugin_definition.version:
                return self._rpc_session.get_remote_plugin(plugin_definition.name)

            self._uninstall_plugin(plugin_definition)

        for required_plugin in plugin_definition.required_plugins:
            self.add_plugin(required_plugin, force=force)

        for package_name, installer in plugin_definition.dependency_installers.items():
            self._rpc_session.install_remote_package(
                name=package_name,
                source=installer,
                force=force
            )

        return self._install_plugin(plugin_definition, force=force)

    def remove_plugin(self, plugin_definition: PluginDefinition):
        plugin_definition = self._normalize_plugin_definition(plugin_definition)

        logger.debug(f'{repr(self)}: remove_plugin -> plugin_definition: {repr(plugin_definition)}')

        self._uninstall_plugin(plugin_definition)
