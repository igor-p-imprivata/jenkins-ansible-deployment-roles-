# events.py
import ctypes
from ctypes import wintypes


kernel32 = ctypes.windll.kernel32

WAIT_ABANDONED = 0x00000080
WAIT_OBJECT_0 = 0x00000000
WAIT_TIMEOUT = 0x00000102
WAIT_FAILED = 0xFFFFFFFF

INFINITE = -1

WaitForSingleObject = kernel32.WaitForSingleObject
WaitForSingleObject.argtypes = (
    wintypes.HANDLE, wintypes.DWORD
)
WaitForSingleObject.restype = wintypes.DWORD

WaitForMultipleObjects = kernel32.WaitForMultipleObjects
WaitForMultipleObjects.argtypes = (
    wintypes.DWORD,
    wintypes.LPHANDLE,
    wintypes.BOOL,
    wintypes.DWORD
)
WaitForMultipleObjects.restype = wintypes.DWORD


CreateEvent = kernel32.CreateEventA
CreateEvent.argtypes = (
    ctypes.c_void_p,
    wintypes.BOOL,
    wintypes.BOOL,
    wintypes.LPCSTR
)
CreateEvent.restype = wintypes.HANDLE

SetEvent = kernel32.SetEvent
SetEvent.argtypes = (wintypes.HANDLE,)
SetEvent.restype = wintypes.BOOL

ResetEvent = kernel32.ResetEvent
ResetEvent.argtypes = (wintypes.HANDLE,)
ResetEvent.restype = wintypes.BOOL

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = (wintypes.HANDLE,)
CloseHandle.restype = wintypes.BOOL


class WaitableEvent:
    __slots__ = ('handle',)

    def __init__(self):
        self.handle = CreateEvent(None, 1, 0, None)

    def __del__(self):
        CloseHandle(self.handle)

    def __hash__(self):
        return self.handle

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    def wait(self, timeout=None):
        timeout = INFINITE if timeout is None else timeout * 1000
        return WaitForSingleObject(self.handle, timeout) == WAIT_OBJECT_0

    def set(self):
        SetEvent(self.handle)

    def is_set(self):
        return WaitForSingleObject(self.handle, 0) == WAIT_OBJECT_0

    def clear(self):
        if self.is_set():
            ResetEvent(self.handle)


class WaitableEventSet:
    def __init__(self, *events):
        self._events = set()

        if events:
            self.update(*events)

    def __len__(self):
        return len(self._events)

    def __bool__(self):
        return bool(self._events)

    def __iter__(self):
        for event in self._events:
            yield event

    def add(self, waitable_event):
        self._events.add(waitable_event)

    def remove(self, waitable_event):
        self._events.remove(waitable_event)

    def discard(self, waitable_event):
        self._events.discard(waitable_event)

    def update(self, *events):
        for event in events:
            self.add(event)

    def wait_all(self, timeout=None):
        timeout = INFINITE if timeout is None else timeout * 1000
        handles = tuple(e.handle for e in self._events)
        # noinspection PyCallingNonCallable,PyTypeChecker
        lp_handles = (wintypes.HANDLE * len(handles))(*handles)
        return WaitForMultipleObjects(len(handles), lp_handles, 1, timeout) == WAIT_OBJECT_0

    def clear_all(self):
        for event in self._events:
            event.clear()

    def set_all(self):
        for event in self._events:
            event.set()
