# definitions.py

PACKAGE_NAME = 'zeus_win32_utils'
VERSION = (0, 0, 0)
INSTALL_REQUIRES = ['zeus_utils', 'pywin32']
