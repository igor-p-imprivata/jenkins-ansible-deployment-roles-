# dll_utils.py
import ctypes
from ctypes import wintypes
from .core import raise_windows_error, dirty_cast
from ._wintypes import (IMAGE_DOS_HEADER,)


# cpdef list get_exports(self):
#     """
#     https://stackoverflow.com/a/1128453
#     :return:
#     """
#     cdef:
#         BOOL res
#         HMODULE h_lib = <HMODULE>INVALID_HANDLE_VALUE
#         DWORD last_err, i
#         const char *file_name
#         BYTE **names
#         PIMAGE_DOS_HEADER dos_header
#         PIMAGE_NT_HEADERS header
#         PIMAGE_EXPORT_DIRECTORY exports
#         bytes b_symbol_name
#         list results = []
#
#     self.ensure_freed()
#
#     file_name = self.file_name.c_str()
#
#     log_debug('DynamicLinkLibrary: getting exports for "%s"', file_name)
#
#     h_lib = LoadLibraryEx(file_name, NULL, DONT_RESOLVE_DLL_REFERENCES)
#
#     if h_lib == NULL:
#         last_err = GetLastError()
#         raise_windows_error(last_err, 'LoadLibraryEx')
#         return results
#
#     dos_header = <PIMAGE_DOS_HEADER>h_lib
#
#     if dos_header.e_magic != IMAGE_DOS_SIGNATURE:
#         res = FreeLibrary(h_lib)
#         raise_for_bool_result(res, 'FreeLibrary', 0)
#         return results
#
#     header = <PIMAGE_NT_HEADERS>((<BYTE *>h_lib) + (<PIMAGE_DOS_HEADER>h_lib).e_lfanew)
#
#     if header.Signature != IMAGE_NT_SIGNATURE or header.OptionalHeader.NumberOfRvaAndSizes < 1:
#         res = FreeLibrary(h_lib)
#         raise_for_bool_result(res, 'FreeLibrary', 0)
#         return results
#
#     exports = <PIMAGE_EXPORT_DIRECTORY>((<BYTE *>h_lib) + header.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress)
#
#     if exports.AddressOfNames == 0:
#         res = FreeLibrary(h_lib)
#         raise_for_bool_result(res, 'FreeLibrary', 0)
#         return results
#
#     names = <BYTE **>((<int>h_lib) + exports.AddressOfNames)
#
#     for i in range(exports.NumberOfNames):
#         b_symbol_name = (<BYTE *>h_lib) + (<int>names[i])
#         results.append(b_symbol_name.decode('utf-8', 'strict'))
#
#     res = FreeLibrary(h_lib)
#     raise_for_bool_result(res, 'FreeLibrary', 0)
#
#     log_debug('DynamicLinkLibrary: found %d export(s) for "%s"', len(results), file_name)
#     return results

DONT_RESOLVE_DLL_REFERENCES = 0x00000001
IMAGE_DOS_SIGNATURE = 0x5A4D

kernel32 = ctypes.windll.Kernel32

LoadLibraryEx = kernel32.LoadLibraryExA
LoadLibraryEx.argtypes = (wintypes.LPCSTR, wintypes.HANDLE, wintypes.DWORD)
LoadLibraryEx.restype = wintypes.HMODULE

FreeLibrary = kernel32.FreeLibrary
FreeLibrary.argtypes = (wintypes.HMODULE,)
FreeLibrary.restype = wintypes.BOOL


def get_exports(dll_path):
    exports = []

    h_lib = LoadLibraryEx(
        dll_path.encode('utf-8', 'strict'),
        None,
        DONT_RESOLVE_DLL_REFERENCES
    )

    if h_lib is None:
        raise_windows_error()

    dos_header = dirty_cast(h_lib, IMAGE_DOS_HEADER)

    if dos_header.e_magic != IMAGE_DOS_SIGNATURE:
        FreeLibrary(h_lib)
        return exports





