# bin_file_locator.py
import os
import re
import mmap
from zeus_utils import iter_find_files, cmp_attrs
from .core import drive_manager
from .files import get_version_info, FileManager
from .enums import PEMachineType, PECharacteristics, WConnectFlags


PE_SIG = b'PE\x00\x00'

COFF_HEADER_SIZE = 20

MACHINE_TYPE_OFFSET = 0
MACHINE_TYPE_SIZE = 2

N_SECTIONS_OFFSET = 2
N_SECTIONS_SIZE = 2

DATE_TIME_OFFSET = 4
DATE_TIME_SIZE = 4

SYM_TABLE_PTR_OFFSET = 8
SYM_TABLE_PTR_SIZE = 4

N_SYMBOLS_OFFSET = 12
N_SYMBOLS_SIZE = 4

SIZE_OPT_HDR_OFFSET = 16
SIZE_OPT_HDR_SIZE = 2

CHARACTERISTICS_OFFSET = 18
CHARACTERISTICS_SIZE = 2


def int_from_bytes(data, offset, size, byteorder='little'):
    return int.from_bytes(data[offset:offset + size], byteorder)


class PEFile:
    __slots__ = ('path', 'network_drive', '_version', '_product_name', '_coff_header', '_opt_header')

    def __init__(self, path, network_drive=None):
        self.path = path
        self.network_drive = network_drive
        self._version = None
        self._product_name = None
        self._coff_header = None
        self._opt_header = None

    def __repr__(self):
        exe_type_str = f'{PEMachineType.__name__}.{self.machine_type.name}'
        return f'{self.__class__.__name__}(file_name="{self.file_name}", ' \
               f'version_string={self.version_string}, ' \
               f'exe_type={exe_type_str})'

    def __hash__(self):
        return hash((self.machine_type.value,) + self.version)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    @property
    def file_name(self):
        return os.path.basename(self.path)

    @property
    def version(self):
        if self._version is None:
            vi = get_version_info(self.path)
            self._version = tuple(int(i) for i in re.split('[.-]', vi.product_version))

        return self._version

    @property
    def product_name(self):
        if self._product_name is None:
            vi = get_version_info(self.path)
            self._product_name = vi.product_name

        return self._product_name

    @property
    def version_string(self):
        return '.'.join(str(i) for i in self.version)

    @property
    def version_major(self):
        if self.version:
            return self.version[0]

    @property
    def version_minor(self):
        if len(self.version) > 1:
            return self.version[1]

    @property
    def version_build(self):
        if len(self.version) > 2:
            return self.version[2]

    @property
    def version_revision(self):
        if len(self.version) > 3:
            return self.version[3]

    @property
    def machine_type(self):
        value = self.get_value_from_coff_header(MACHINE_TYPE_OFFSET, MACHINE_TYPE_SIZE)
        return PEMachineType(value)

    @property
    def number_of_sections(self):
        return self.get_value_from_coff_header(N_SECTIONS_OFFSET, N_SECTIONS_SIZE)

    @property
    def created(self):
        return self.get_value_from_coff_header(DATE_TIME_OFFSET, DATE_TIME_SIZE)

    @property
    def coff_table_ptr(self):
        return self.get_value_from_coff_header(SYM_TABLE_PTR_OFFSET, SYM_TABLE_PTR_SIZE)

    @property
    def number_of_symbols(self):
        return self.get_value_from_coff_header(N_SYMBOLS_OFFSET, N_SYMBOLS_SIZE)

    @property
    def optional_header_size(self):
        return self.get_value_from_coff_header(SIZE_OPT_HDR_OFFSET, SIZE_OPT_HDR_SIZE)

    @property
    def characteristics(self):
        value = self.get_value_from_coff_header(CHARACTERISTICS_OFFSET, CHARACTERISTICS_SIZE)
        return PECharacteristics(value)

    def get_headers(self):
        with open(self.path, 'rb') as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

            try:
                sig_idx = mm.find(PE_SIG)
                hdr_idx = sig_idx + len(PE_SIG)
                self._coff_header = bytes(mm[hdr_idx:hdr_idx + COFF_HEADER_SIZE])
                opt_hdr_size = int_from_bytes(
                    self._coff_header,
                    SIZE_OPT_HDR_OFFSET,
                    SIZE_OPT_HDR_SIZE
                )

                if opt_hdr_size:
                    opt_hdr_idx = hdr_idx + COFF_HEADER_SIZE
                    self._opt_header = bytes(mm[opt_hdr_idx:opt_hdr_idx + opt_hdr_size])

            finally:
                mm.close()

    def get_coff_header(self):
        if self._coff_header is None:
            self.get_headers()

        return self._coff_header

    def get_optional_header(self):
        if self._opt_header is None:
            self.get_headers()

        return self._opt_header

    def get_value_from_coff_header(self, offset, size, byteorder='little'):
        return int_from_bytes(self.get_coff_header(), offset, size, byteorder)


class PEFileLocator:
    def __init__(self, *search_paths, matcher=None):
        self.search_paths = search_paths
        self.matcher = matcher
        self.__file_manager = FileManager()
        self.__network_drives = {}

    @property
    def network_drives(self):
        return tuple(self.__network_drives.values())

    def add_network_drive(self, remote_name, username=None, password=None,
                          flags=WConnectFlags.TEMPORARY):
        network_drive = drive_manager.find(remote_name=remote_name)

        if network_drive is None:

            if username is None or password is None:
                raise ValueError('username and password must be specified to map drive')

            network_drive = drive_manager.get_available_drive()

            network_drive.connect(
                remote_name,
                username=username,
                password=password,
                flags=flags
            )

        self.__network_drives[remote_name.lower()] = network_drive
        self.__file_manager.add_drive(network_drive.remote_name)

    def get_network_drive_from_path(self, path):
        path = path.lower()

        for remote_name, network_drive in self.__network_drives.items():
            if path.startswith(remote_name):
                return network_drive

    def get_file(self, path):
        file_obj = self.__file_manager.get_file(path)
        path = file_obj.get_path()
        network_drive = self.get_network_drive_from_path(path)
        return PEFile(path, network_drive=network_drive)

    def find_file(self, case_insensitive=True, sub_string=True, **attributes):
        it = self.iter_find_files(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )
        return next((obj for obj in it), None)

    def iter_find_files(self, case_insensitive=True, sub_string=True, **attributes):
        unique_files = set()

        for search_path in self.search_paths:
            network_drive = self.get_network_drive_from_path(search_path)

            for file_path in iter_find_files(search_path, self.matcher):
                pe_file = PEFile(file_path, network_drive=network_drive)

                if pe_file in unique_files:
                    continue

                match_found = cmp_attrs(
                    pe_file,
                    attrs=attributes,
                    case_insensitive=case_insensitive,
                    sub_string=sub_string
                )

                if match_found:
                    yield pe_file

                unique_files.add(pe_file)
