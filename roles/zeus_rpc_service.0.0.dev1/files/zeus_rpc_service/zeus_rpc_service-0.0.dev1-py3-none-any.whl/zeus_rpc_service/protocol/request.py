# request.py
from .base import RpcSerializableChannel
from zeus_utils import kwargs2str


MAX_RPC_REQUEST_STR_LEN = 256


class RpcRequestPacket(RpcSerializableChannel):
    __slots__ = RpcSerializableChannel.__slots__ + (
        'session_uuid',
        'plugin_name',
        'class_name',
        'object_hash',
        'attribute_name',
        'callable_args',
        'callable_kwargs',
        'context_uuid'
    )

    def __init__(self, send_func, session_uuid=None, plugin_name=None, class_name=None,
                 object_hash=None, attribute_name=None, callable_args=None, callable_kwargs=None,
                 context_uuid=None):
        super(RpcRequestPacket, self).__init__(send_func=send_func)
        self.session_uuid = session_uuid
        self.plugin_name = plugin_name
        self.class_name = class_name
        self.object_hash = object_hash
        self.attribute_name = attribute_name
        self.callable_args = callable_args
        self.callable_kwargs = callable_kwargs
        self.context_uuid = context_uuid

    def __str__(self):
        kwargs_str = kwargs2str(
            session_uuid=self.session_uuid,
            plugin_name=self.plugin_name,
            class_name=self.class_name,
            object_hash=self.object_hash,
            attribute_name=self.attribute_name,
            callable_args=self.callable_args,
            callable_kwargs=self.callable_kwargs,
            context_uuid=self.context_uuid,
        )

        if len(kwargs_str) > MAX_RPC_REQUEST_STR_LEN:
            kwargs_str = f'{kwargs_str[:MAX_RPC_REQUEST_STR_LEN]}...'

        return f'{self.__class__.__name__}({kwargs_str})'

    def __getattr__(self, item):
        return self.wrap_remote_attribute(item)

    def wrap_remote_attribute(self, name):
        if self.send_func is None:
            raise AttributeError(f"'{self.__class__.__name__}' instance has no attribute '{name}'")

        self.attribute_name = name

        def _remote_attribute_wrapper(*args, **kwargs):
            self.callable_args = args
            self.callable_kwargs = kwargs
            return self.send_func(self)

        return _remote_attribute_wrapper
