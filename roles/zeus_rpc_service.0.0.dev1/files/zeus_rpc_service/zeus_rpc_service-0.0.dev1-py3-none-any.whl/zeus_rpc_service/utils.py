# utils.py
import os
import ast
from zeus_utils import find_by_attrs, findall_by_attrs


# def get_default_python_exe():
#     """
#     Get the path of the default Python executable based on the location of
#     the file the os module is loaded from. This is used instead of
#     sys.executable to determine the python.exe path when running from a
#     Windows service, which reports the executable as pythonservice.exe.
#
#     :return:
#     """
#     os_file = os.__file__
#     py_root_dir = os_file.split(r'\lib')[0]
#     return os.path.join(py_root_dir, 'python.exe')


class ClassNode:
    def __init__(self, node):
        self._node = node
        self._functions = None

    @property
    def name(self):
        return self._node.name

    @property
    def bases(self):
        return [base.attr for base in self._node.bases]

    @property
    def functions(self):
        if self._functions is None:
            self._functions = []

            for node in ast.walk(self._node):
                if isinstance(node, ast.FunctionDef):
                    self._functions.append(node.name)

        return set(self._functions)


class ClassNodeParser:

    @classmethod
    def from_file(cls, path):
        with open(path, 'r') as f:
            return cls(f.read())

    def __init__(self, code):
        self.code = code
        self._nodes = []
        self._parsed = False

    def __iter__(self):
        self.parse()

        for node in self._nodes:
            yield node

    def parse(self):
        if not self._parsed:
            root = ast.parse(self.code)

            for node in ast.walk(root):
                if isinstance(node, ast.ClassDef):
                    cls_node = ClassNode(node)
                    self._nodes.append(cls_node)

            self._parsed = True

        return self

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        self.parse()
        return find_by_attrs(
            self._nodes,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        self.parse()
        return findall_by_attrs(
            self._nodes,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )
