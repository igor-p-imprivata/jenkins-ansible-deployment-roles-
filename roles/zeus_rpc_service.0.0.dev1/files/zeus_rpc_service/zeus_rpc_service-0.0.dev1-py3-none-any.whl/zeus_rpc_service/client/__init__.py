# __init__.py
from .session import RpcSession, DisconnectActions
from .client import RpcServiceProxy, STATION_NAME_SERVICES, STATION_NAME_CONSOLE
from .remote_plugins import remote_plugin_registry, RemotePlugin, RemotePluginManager
# from .remote_service_installer import RemoteServiceInstaller


__all__ = [
    'RpcSession', 'RpcServiceProxy', 'remote_plugin_registry', 'RemotePlugin',
    'RemotePluginManager', 'DisconnectActions', 'STATION_NAME_SERVICES', 'STATION_NAME_CONSOLE'
]
