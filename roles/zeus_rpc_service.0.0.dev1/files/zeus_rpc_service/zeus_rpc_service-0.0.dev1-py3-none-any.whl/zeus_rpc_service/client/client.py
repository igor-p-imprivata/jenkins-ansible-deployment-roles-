# client.py
import time
import socket
import logging
import atexit
from zeus_rpc_service.definitions import (
    SVC_PORT,
    PLUGIN_NAME_ROOT,
    SERVICES_SESSION_ID,
    STATION_NAME_SERVICES,
    STATION_NAME_CONSOLE

)
from zeus_rpc_service.client.session import RpcSession, DisconnectActions


logger = logging.getLogger(__name__)

WAIT_PING_INTERVAL = 1
WAIT_SOCKET_TIMEOUT = 0.5


class RpcServiceProxy:
    def __init__(self, host, port=SVC_PORT, path=None):
        self.host = host
        self.port = port
        self.path = path
        self._sessions_by_station_name = {}
        self._dc_registered = False
        self._register_disconnect()

    def __repr__(self):
        return f'{self.__class__.__name__}(host="{self.host}", port={self.port})'

    @property
    def services_session(self):
        return self.get_session(STATION_NAME_SERVICES)

    @property
    def console_session(self):
        return self.get_session(STATION_NAME_CONSOLE)

    def _register_disconnect(self):
        if not self._dc_registered:
            atexit.register(self.disconnect)
            self._dc_registered = True

    def _unregister_disconnect(self):
        if self._dc_registered:
            atexit.unregister(self.disconnect)
            self._dc_registered = False

    def get_session(self, station_name: str, index: int = 0) -> RpcSession:
        sessions = self._sessions_by_station_name.get(station_name)

        if sessions and index < len(sessions):
            return sessions[index]

        raise RuntimeError(f'"{station_name}" has no connected sessions')

    def get_remote_plugin_names(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.get_plugin_names()

    def update_remote_plugin_names(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.update_plugin_names()

    def get_remote_plugin(self, plugin_name=PLUGIN_NAME_ROOT, station_name=STATION_NAME_SERVICES,
                          index=0):
        session = self.get_session(station_name, index=index)
        return session.get_remote_plugin(plugin_name=plugin_name)

    def wait_for_services_session(self, timeout=None, socket_timeout=WAIT_SOCKET_TIMEOUT,
                                  interval=WAIT_PING_INTERVAL):
        orig_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(socket_timeout)
        start = time.time()

        try:
            while True:
                try:
                    return self.connect_services_session()
                except socket.timeout:
                    if timeout is not None and (time.time() - start) > timeout:
                        raise TimeoutError()

                    time.sleep(interval)

        finally:
            socket.setdefaulttimeout(orig_timeout)

    def connect_session(self, station_name, session_id, port, path=None,
                        disconnect_action=DisconnectActions.CLEAR_SESSION):

        session = RpcSession(
            host=self.host,
            port=port,
            url_path=path,
            station_name=station_name,
            session_id=session_id
        )

        self._sessions_by_station_name.setdefault(session.station_name, [])
        sessions = self._sessions_by_station_name[session.station_name]
        session_index = len(sessions)

        logger.debug(f'{repr(self)}: connecting {repr(session)} (index={session_index})')

        session.connect(disconnect_action=disconnect_action)

        self._sessions_by_station_name[session.station_name].append(session)
        logger.debug(f'{repr(self)}: successfully connected to {repr(session)} (index={session_index})')
        return session

    def disconnect_session(self, station_name, index=0):
        session = self.get_session(station_name, index=index)

        logger.debug(f'{repr(self)}: disconnecting {repr(session)} (index={index})')

        if session.disconnect():
            logger.debug(f'{repr(self)}: successfully disconnected from {repr(session)} '
                         f'(index={index})')

            self._unregister_disconnect()

    def connect_services_session(self):
        return self.connect_session(
            station_name=STATION_NAME_SERVICES,
            session_id=SERVICES_SESSION_ID,
            port=self.port,
            path=self.path
        )

    def disconnect_services_session(self, index=0):
        self.disconnect_session(STATION_NAME_SERVICES, index=index)

    def disconnect_console_session(self, index=0):
        self.disconnect_session(STATION_NAME_CONSOLE, index=index)

    def connect(self):
        logger.info(f'{repr(self)}: connecting to service...')

        services_session = self.connect_services_session()

        logger.info(f'{repr(self)}: successfully connected to service')

        return services_session

    def disconnect(self):
        logger.info(f'{repr(self)}: disconnecting from service...')

        for station_name, sessions in tuple(self._sessions_by_station_name.items()):

            for i in range(len(sessions)):
                self.disconnect_session(station_name, index=i)

        logger.info(f'{repr(self)}: successfully disconnected from service')
        self._sessions_by_station_name.clear()

    def get_remote_globals(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.get_remote_globals()

    def get_remote_locals(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.get_remote_locals()

    def get_resource(self, tag, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.get_resource(tag)

    def copy_file(self, tag, src, dest_dir=None, file_name=None, fail_if_exists=False,
                  cleanup=True, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.copy_file(
            tag=tag,
            src=src,
            dest_dir=dest_dir,
            file_name=file_name,
            fail_if_exists=fail_if_exists,
            cleanup=cleanup
        )

    def send_file(self, tag, src, dest_dir=None, cleanup=True, station_name=STATION_NAME_SERVICES,
                  index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.send_file(
            tag=tag,
            src=src,
            dest_dir=dest_dir,
            cleanup=cleanup
        )

    def find_package(self, *, station_name=STATION_NAME_SERVICES, index=0,
                     case_insensitive=True, sub_string=True, **attributes):
        session = self.get_session(station_name=station_name, index=index)
        return session.find_remote_package(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def install_package(self, name=None, source=None, extra_args=None, remote_source_path=None,
                        force=False, wait_timeout=None, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.install_remote_package(
            name=name,
            source=source,
            extra_args=extra_args,
            remote_source_path=remote_source_path,
            force=force,
            wait_timeout=wait_timeout
        )

    def uninstall_package(self, name=None, source=None, extra_args=None,
                          remote_source_path=None, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.uninstall_remote_package(
            name=name,
            source=source,
            extra_args=extra_args,
            remote_source_path=remote_source_path
        )

    def import_module(self, name, code=None, path=None, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.import_remote_module(
            name=name,
            code=code,
            path=path
        )

    def unload_module(self, name, raise_if_non_existent=False, station_name=STATION_NAME_SERVICES,
                      index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.unload_remote_module(
            name=name,
            raise_if_non_existent=raise_if_non_existent
        )

    def import_package(self, package_info=None, name=None, location=None,
                       station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.import_remote_package(
            package_info=package_info,
            name=name,
            location=location
        )

    def get_imports(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.get_remote_imports()

    def find_import(self, *, station_name=STATION_NAME_SERVICES, index=0,
                    case_insensitive=True, sub_string=True, **attributes):
        session = self.get_session(station_name=station_name, index=index)
        return session.find_remote_import(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def findall_imports(self, *, station_name=STATION_NAME_SERVICES, index=0,
                        case_insensitive=True, sub_string=True, **attributes):
        session = self.get_session(station_name=station_name, index=index)
        return session.findall_remote_imports(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def add_plugin(self, plugin_definition, force=False, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.add_plugin(plugin_definition, force=force)

    def remove_plugin(self, plugin_definition, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.remove_plugin(plugin_definition)

    def get_plugin(self, plugin_definition, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.get_plugin(plugin_definition)

    def add_extended_request_handler(self, name, import_path,
                                     station_name=STATION_NAME_SERVICES, index=0, **kwargs):
        session = self.get_session(station_name=station_name, index=index)
        return session.add_extended_request_handler(
            name=name,
            import_path=import_path,
            **kwargs
        )

    def remove_extended_request_handler(self, name, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name=station_name, index=index)
        return session.remove_extended_request_handler(name=name)
