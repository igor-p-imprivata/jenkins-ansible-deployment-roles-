# users.py
import os
import atexit
import win32api
import win32security
from zeus_utils import SingletonMeta
from zeus_win32_utils import (
    lookup_account_sid, lookup_account_name, get_username, get_user_token_for_session,
    get_known_folder_path, UserNameFormat, LogonType, LogonProvider, FolderId
)

LOCAL_SYSTEM_SID = 'S-1-5-18'


def normalize_name(username, domain, desired_format, lowercase=True):
    if desired_format not in UserNameFormat:
        desired_format = UserNameFormat(desired_format)

    if '@' in username:
        current_fmt = UserNameFormat.UPN
        account_name = username

    elif domain is not None:
        current_fmt = UserNameFormat.SAM
        account_name = f'{username}\\{domain}'

    elif '\\' in username:
        current_fmt = UserNameFormat.SAM
        account_name = username

    else:
        raise ValueError(f'Unknown current name format: {username}, {domain}')

    if current_fmt is desired_format:
        result = account_name

    else:
        result = win32security.TranslateName(account_name, current_fmt, desired_format.value)

    if lowercase:
        result = result.lower()

    return result


# noinspection PyMethodMayBeStatic
class User:
    @classmethod
    def from_current_user(cls):
        return cls.from_name(get_username())

    @classmethod
    def from_sid(cls, sid_string):
        name, domain, _ = lookup_account_sid(sid_string)
        return cls(name=name, sid_string=sid_string, domain=domain)

    @classmethod
    def from_name(cls, name):
        sid_string, domain, _ = lookup_account_name(name)
        return cls(name=name, sid_string=sid_string, domain=domain)

    def __init__(self, name, domain, sid_string):
        self.name = name
        self.sid_string = sid_string
        self.domain = domain
        self.token = None
        self._impersonated_user = None

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    def __hash__(self):
        return hash(self.sid_string)

    @property
    def sam_name(self):
        return f'{self.domain}\\{self.name}'

    @property
    def upn_name(self):
        return win32security.TranslateName(self.sam_name, win32api.NameSamCompatible,
                                           win32api.NameUserPrincipal)

    @property
    def impersonated_user(self):
        return self._impersonated_user

    def _ensure_token(self, password=None, **kwargs):
        if self.token is None:

            if password is None:
                raise RuntimeError('call logon method first or supply password')

            logon_type = kwargs.get('logon_type', LogonType.BATCH)
            logon_provider = kwargs.get('logon_provider', LogonProvider.DEFAULT)

            self.logon(password, logon_type=logon_type, logon_provider=logon_provider)

    def get_sid(self, password=None, **kwargs):
        self._ensure_token(password=password, **kwargs)
        sid, _ = win32security.GetTokenInformation(self.token, win32security.TokenUser)
        return sid

    def normalize_name(self, desired_format, lowercase=True):
        return normalize_name(self.name, self.domain, desired_format, lowercase=lowercase)

    def get_profile_folder_path(self):
        return get_known_folder_path(FolderId.Profile)

    def get_desktop_path(self):
        return os.path.join(self.get_profile_folder_path(), 'Desktop')

    def ensure_reverted(self):
        if self._impersonated_user is not None:
            self.revert()

    def ensure_token_closed(self):
        if self.token is not None:
            self.token.Close()
            self.token = None

    def logon(self, password, logon_type=LogonType.INTERACTIVE,
              logon_provider=LogonProvider.DEFAULT):
        if logon_type not in LogonType:
            logon_type = LogonType(logon_type)

        if logon_provider not in LogonProvider:
            logon_provider = LogonProvider(logon_provider)

        self.token = win32security.LogonUser(self.name, self.domain, password,
                                             logon_type.value, logon_provider.value)

        atexit.register(self.ensure_token_closed)

    def impersonate(self, username, password):
        impersonated_user = User.from_name(username)
        impersonated_user.logon(password)

        win32security.ImpersonateLoggedOnUser(impersonated_user.token)

        self._impersonated_user = impersonated_user
        atexit.register(self.ensure_reverted)
        return impersonated_user

    def revert(self):
        win32security.RevertToSelf()
        self._impersonated_user = None

    def get_session_token(self, session_id, password=None, **kwargs):
        impersonate = kwargs.pop('impersonate', False)
        self._ensure_token(password=password, **kwargs)
        return get_user_token_for_session(self.token, session_id, impersonate=impersonate)


# noinspection PyMethodMayBeStatic
class UserManager(metaclass=SingletonMeta):
    def get_current_user_name(self):
        return get_username()

    def get_current_user(self):
        return User.from_current_user()

    def get_user_from_name(self, name):
        return User.from_name(name)

    def get_user_from_sid(self, sid):
        return User.from_sid(sid)

    def revert_to_self(self):
        win32security.RevertToSelf()

    def logon_user(self, name, password):
        user = User.from_name(name)
        user.logon(password)
        return user

    def get_local_system_user(self):
        return User.from_sid(LOCAL_SYSTEM_SID)


user_manager = UserManager()
