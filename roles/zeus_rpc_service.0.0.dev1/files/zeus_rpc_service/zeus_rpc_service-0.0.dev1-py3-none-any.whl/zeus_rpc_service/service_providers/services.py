# services.py
import atexit
import pywintypes
import win32service
from zeus_utils import find_by_attrs, findall_by_attrs, SingletonMeta


class ServiceConfig:
    __slots__ = (
        'service_type', 'start_type', 'error_control', 'binary_path_name', 'load_order_group',
        'tag_id', 'dependencies', 'service_start_name', 'display_name'
    )

    def __init__(self, service_type, start_type, error_control, binary_path_name, load_order_group,
                 tag_id, dependencies, service_start_name, display_name):
        self.service_type = service_type
        self.start_type = start_type
        self.error_control = error_control
        self.binary_path_name = binary_path_name
        self.load_order_group = load_order_group
        self.tag_id = tag_id
        self.dependencies = dependencies
        self.service_start_name = service_start_name
        self.display_name = display_name


class Service:
    def __init__(self, sc_manager_handle, name, display_name, status):
        self._sc_manager_handle = sc_manager_handle
        self.name = name
        self.display_name = display_name
        self.status = status
        self._handle = None
        self._config = None

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    @property
    def type(self):
        return self.ensure_config().service_type

    @property
    def start_type(self):
        return self.ensure_config().start_type

    @property
    def error_control(self):
        return self.ensure_config().error_control

    @property
    def binary_path_name(self):
        return self.ensure_config().binary_path_name

    @property
    def load_order_group(self):
        return self.ensure_config().load_order_group

    @property
    def tag_id(self):
        return self.ensure_config().tag_id

    @property
    def dependencies(self):
        return self.ensure_config().dependencies

    @property
    def start_name(self):
        return self.ensure_config().service_start_name

    def open(self):
        if self._handle is None:
            self._handle = win32service.OpenService(
                self._sc_manager_handle,
                self.name,
                win32service.SERVICE_QUERY_CONFIG
            )
            atexit.register(self.close)

    def close(self):
        if self._handle is not None:
            win32service.CloseServiceHandle(self._handle)
            self._handle = None

    def query_config(self):
        self.open()
        self._config = config = ServiceConfig(*win32service.QueryServiceConfig(self._handle))
        return config

    def ensure_config(self):
        if self._config is None:
            return self.query_config()

        return self._config


class ServiceManager(metaclass=SingletonMeta):
    def __init__(self):
        self._handle = None

    def open(self):
        if self._handle is None:
            self._handle = win32service.OpenSCManager(
                None,
                None,
                win32service.SC_MANAGER_ALL_ACCESS
            )
            atexit.register(self.close)

    def close(self):
        if self._handle is not None:
            win32service.CloseServiceHandle(self._handle)
            self._handle = None

    def enumerate(self):
        self.open()

        services = win32service.EnumServicesStatus(
            self._handle,
            win32service.SERVICE_DRIVER | win32service.SERVICE_WIN32,
            win32service.SERVICE_STATE_ALL
        )

        for service_info in services:
            service = Service(self._handle, *service_info)

            # noinspection PyUnresolvedReferences
            try:
                service.open()
            except pywintypes.error:
                continue

            yield service

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(
            self.enumerate(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(
            self.enumerate(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )


service_manager = ServiceManager()


