# pip_cli.py
import os
import time
import logging
import subprocess as sp
import pkg_resources
from importlib import invalidate_caches
from zeus_utils import find_by_attrs, findall_by_attrs, SingletonMeta


DEFAULT_POLL_INTERVAL = 0.25

logger = logging.getLogger(__name__)


def normalize_package_name(name):
    return name.replace('-', '_')


def normalize_package_version(version):
    version_parts = []

    for part_str in version.split('.'):
        try:
            part = int(part_str)
        except ValueError:
            part = part_str

        version_parts.append(part)

    return tuple(version_parts)


def get_top_level_import_name(import_name):
    return import_name.split('.')[0]


def find_pip_exe():
    os_file = os.__file__
    py_root_dir = os_file.split(r'\lib')[0]
    pip_exe = os.path.join(py_root_dir, 'Scripts\\pip.exe')

    if not os.path.exists(pip_exe):
        raise RuntimeError('Unable to find pip.exe')

    return pip_exe


# noinspection PyMethodMayBeStatic
class PipCommandLineInterface(metaclass=SingletonMeta):
    def __init__(self):
        super(PipCommandLineInterface, self).__init__()
        self.pip_exe = find_pip_exe()

    def __repr__(self):
        return f'{self.__class__.__name__}(pip_exe="{self.pip_exe}")'

    def pip_main(self, arg_list, **kwargs):
        command_line = f'"{self.pip_exe}" {sp.list2cmdline(arg_list)}'

        logger.debug(f'{repr(self)}: pip_main -> command_line: {command_line}, kwargs: {kwargs}')
        proc = sp.run(command_line, stdout=sp.PIPE, stderr=sp.PIPE, **kwargs)
        return {
            'args':   proc.args, 'returncode': proc.returncode, 'stdout': proc.stdout,
            'stderr': proc.stderr
        }

    def install(self, package, extra_args=None):
        extra_args = extra_args or ()
        proc_kwargs = self.pip_main(['install', package, *extra_args])
        invalidate_caches()
        return proc_kwargs

    def uninstall(self, package, source=None, extra_args=None):
        extra_args = extra_args or ()

        if source is not None:
            if os.path.isfile(source):
                cwd = os.path.dirname(source)

            elif os.path.isdir(source):
                cwd = source

            else:
                raise ValueError(f'Invalid source: {source}')

        else:
            cwd = os.getcwd()

        proc_kwargs = self.pip_main(['uninstall', package, '-y', *extra_args], cwd=cwd)
        invalidate_caches()
        return proc_kwargs


_pip_cli = PipCommandLineInterface()


class PackageInfo:
    @classmethod
    def from_distribution(cls, distribution):
        name = normalize_package_name(distribution.project_name)
        version = normalize_package_version(distribution.version)
        return cls(name=name, location=distribution.location, version=version)

    def __init__(self, name, location, version):
        self.name = name
        self.location = location
        self.version = version

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", location="{self.location}", ' \
               f'version={self.version})'

    def __hash__(self):
        return hash((self.name, self.location) + self.version)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    def __getstate__(self):
        return {
            'name': self.name,
            'location': self.location,
            'version': self.version
        }

    def __setstate__(self, state):
        self.__dict__.update(state)

    def uninstall(self, source=None, extra_args=None):
        return _pip_cli.uninstall(package=self.name, source=source, extra_args=extra_args)


# noinspection PyMethodMayBeStatic
class PythonPackageManager:
    def install(self, package, extra_args=None):
        return _pip_cli.install(package=package, extra_args=extra_args)

    def refresh_packages(self):
        # noinspection PyProtectedMember
        pkg_resources._initialize_master_working_set()

    def enumerate(self):
        for dist in pkg_resources.working_set:
            yield PackageInfo.from_distribution(dist)

    def wait_for_package(self, *, timeout=None, case_insensitive=True, sub_string=True,
                         **attributes):
        poll_interval = attributes.pop('poll_interval', DEFAULT_POLL_INTERVAL)
        start = time.time()

        while True:
            package_info = self.find(
                case_insensitive=case_insensitive,
                sub_string=sub_string,
                **attributes
            )

            if package_info is not None:
                return package_info

            if timeout is not None and (time.time() - start) > timeout:
                raise TimeoutError()

            self.refresh_packages()
            time.sleep(poll_interval)

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(
            self.enumerate(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(
            self.enumerate(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )
