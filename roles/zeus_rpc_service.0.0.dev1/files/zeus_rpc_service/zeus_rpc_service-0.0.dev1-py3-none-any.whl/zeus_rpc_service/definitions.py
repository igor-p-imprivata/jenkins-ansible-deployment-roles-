# definitions.py
import os


PACKAGE_ROOT_DIRECTORY = os.path.abspath(os.path.dirname(__file__))

SVC_PORT = 11111

SESSION_LOGS_REL_DIR = 'logs\\sessions'
SESSION_LOG_NAME_FMT = 'RpcServerSession{}.log'

PLUGIN_NAME_ROOT = 'root'
PLUGIN_NAME_FILES = 'files'
PLUGIN_NAME_EVENTS = 'events'
PLUGIN_NAME_CODE_IMPORTER = 'code_importer'
PLUGIN_NAME_PACKAGES = 'packages'
# PLUGIN_NAME_PROCESSES = 'processes'


SERVICES_SESSION_ID = 0

STATION_NAME_SERVICES = 'Services'
STATION_NAME_CONSOLE = 'Console'


__all__ = [
    'PACKAGE_ROOT_DIRECTORY',
    'SESSION_LOGS_REL_DIR',
    'SESSION_LOG_NAME_FMT',
    'SVC_PORT',
    'PLUGIN_NAME_ROOT',
    'PLUGIN_NAME_FILES',
    'PLUGIN_NAME_EVENTS',
    # 'PLUGIN_NAME_PROCESSES',
    'PLUGIN_NAME_CODE_IMPORTER',
    'PLUGIN_NAME_PACKAGES',
    'SERVICES_SESSION_ID',
    'STATION_NAME_SERVICES',
    'STATION_NAME_CONSOLE'
]
