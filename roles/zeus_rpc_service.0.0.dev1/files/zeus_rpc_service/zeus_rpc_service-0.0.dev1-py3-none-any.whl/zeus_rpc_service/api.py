# api.py
# from .client import ZeusRpcServiceSession
# from .protocol import SVC_PORT
# from .resources import ResourceRequirements, RequirementKeys
#
#
# def create_resource_requirements():
#     requirements = ResourceRequirements()
#     requirements.associate_callable(RequirementKeys.NETWORK_DRIVES,
#                                     class_=ZeusRpcServiceSession,
#                                     method_name='map_network_drive')
#     requirements.associate_callable(RequirementKeys.NETWORK_FILES,
#                                     class_=ZeusRpcServiceSession,
#                                     method_name='copy_file')
#     return requirements
#
#
# def create_service_session(host, account_name, password, port=SVC_PORT, resource_requirements=None):
#     if isinstance(resource_requirements, str):
#         resource_requirements = ResourceRequirements.from_file(resource_requirements)
#
#     svc_session = ZeusRpcServiceSession(host=host, account_name=account_name, account_password=password,
#                                         port=port, resource_requirements=resource_requirements)
#     svc_session.setup()
#     return svc_session
