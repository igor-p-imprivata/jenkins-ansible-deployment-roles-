# importer.py
import os
import sys
import logging
import importlib.util as importlib_util
from importlib import invalidate_caches


logger = logging.getLogger(__name__)


def import_module_from_spec(spec, code=None, update_sys_modules=True):
    module_ = importlib_util.module_from_spec(spec)

    if update_sys_modules:
        sys.modules[spec.name] = module_

    if code is not None:
        exec(code, module_.__dict__)

    else:
        spec.loader.exec_module(module_)

    return module_


class PythonCodeImporter:
    def __init__(self):
        self.__modules = {}

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def unload(self, name):
        module_ = self.__modules.pop(name, None)

        if module_ is not None:
            logger.info(f'{repr(self)}: unload -> {repr(module_)}')
            del module_

    def clear(self):
        for name in list(self.__modules.keys()):
            self.unload(name)

    def import_module(self, name, code=None, path=None):
        if code is None and path is None:
            raise ValueError('Either code or path must be specified')

        invalidate_caches()

        if path is not None:
            spec = importlib_util.spec_from_file_location(name, path)

        else:
            spec = importlib_util.spec_from_loader(name, loader=None)

        self.__modules[name] = import_module_from_spec(spec, code=code)

    def import_package(self, name, path):
        logger.info(f'{repr(self)}: import_package -> name: "{name}", path: "{path}"')
        module_path = os.path.join(path, '__init__.py')
        self.import_module(name=name, path=module_path)

    def import_from(self, name, attr):
        module_ = self.__modules.get(name)

        if module_ is None:
            raise ValueError(f'Module "{name}" is not imported')

        return getattr(module_, attr)
