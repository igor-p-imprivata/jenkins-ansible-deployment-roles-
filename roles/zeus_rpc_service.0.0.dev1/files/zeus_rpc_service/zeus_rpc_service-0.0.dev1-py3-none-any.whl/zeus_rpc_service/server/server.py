# server.py
import logging
from uuid import uuid4
from zeus_rpc_service.protocol import (
    RpcSessionObjectCache,
    RpcRequestPacket,
    RpcResponsePacket
)
from zeus_rpc_service.definitions import (
    PLUGIN_NAME_ROOT,
    PLUGIN_NAME_CODE_IMPORTER,
    PLUGIN_NAME_PACKAGES,
    PLUGIN_NAME_FILES,
    PLUGIN_NAME_EVENTS,
)
from .base import BaseRpcServer, BaseRpcRequestHandler
from .local_plugins import LocalPluginManager, ImmutableLocalPlugin
from .immutable_plugins import (
    get_top_level_import_name,
    PythonCodeImporter,
    PythonPackageManager,
    FileManager,
    EventManager,
)


logger = logging.getLogger(__name__)


# noinspection PyMethodMayBeStatic
class RpcServer:
    def __init__(self, host, port, default_directory=None):
        self.host = host
        self.port = port
        self.quit = False
        self.default_directory = default_directory

        self._sessions = {}

        self._plugin_manager = LocalPluginManager()

        self._code_importer = PythonCodeImporter()
        self._package_manager = PythonPackageManager()
        self._file_manager = FileManager(default_directory=default_directory)
        self._event_manager = EventManager()
        # self._proc_manager = ProcessManager()

        # core plugins
        self._plugin_manager.add_plugin_from_implementation(
            name=PLUGIN_NAME_ROOT,
            implementation=self,
            plugin_type=ImmutableLocalPlugin
        )

        self._plugin_manager.add_plugin_from_implementation(
            name=PLUGIN_NAME_CODE_IMPORTER,
            implementation=self._code_importer,
            plugin_type=ImmutableLocalPlugin
        )

        self._plugin_manager.add_plugin_from_implementation(
            name=PLUGIN_NAME_PACKAGES,
            implementation=self._package_manager,
            plugin_type=ImmutableLocalPlugin
        )

        self._plugin_manager.add_plugin_from_implementation(
            name=PLUGIN_NAME_FILES,
            implementation=self._file_manager,
            plugin_type=ImmutableLocalPlugin
        )

        self._plugin_manager.add_plugin_from_implementation(
            name=PLUGIN_NAME_EVENTS,
            implementation=self._event_manager,
            plugin_type=ImmutableLocalPlugin
        )

        # self._plugin_manager.add_plugin_from_implementation(
        #     name=PLUGIN_NAME_PROCESSES,
        #     implementation=self._proc_manager,
        #     plugin_type=ImmutableLocalPlugin
        # )

        self._xml_rpc_server = BaseRpcServer(host=self.host, port=self.port)

        self._xml_rpc_server.register_instance(self)

    def __repr__(self):
        return f'{self.__class__.__name__}(host="{self.host}", port={self.port})'

    def _import_from_path(self, import_path):
        top_level_name = get_top_level_import_name(import_path)
        logger.debug(f'{repr(self)}: _import_from_path -> import_path: {import_path}, '
                     f'top_level_name: {top_level_name}')

        if top_level_name not in self._code_importer:
            package = self._package_manager.find(name=top_level_name)

            if package is None:
                raise ImportError(f'"{top_level_name}" not installed')

            # the package is installed but not imported
            logger.debug(f'{repr(self)}: _import_from_path -> {top_level_name} is installed but '
                         f'not imported, doing import')

            self._code_importer.import_package(
                name=package.name,
                location=package.location
            )

        obj = self._code_importer.get(import_path)

        if obj is None:
            raise ImportError(f'Invalid import_path: {import_path}')

        return obj

    def add_plugin_from_implementation(self, name, implementation):
        logger.debug(f'{repr(self)}: add_plugin_from_implementation -> name: {name}, '
                     f'implementation: {repr(implementation)}')

        self._plugin_manager.add_plugin_from_implementation(
            name=name,
            implementation=implementation
        )

    def add_plugin(self, plugin):
        logger.debug(f'{repr(self)}: add_plugin -> plugin: {repr(plugin)}')

        self._plugin_manager.add_plugin(plugin=plugin)

    def remove_plugin(self, name):
        logger.debug(f'{repr(self)}: remove_plugin -> name: {name}')

        self._plugin_manager.remove_plugin(name=name)

    def get_globals(self):
        return {key: repr(value) for key, value in globals().items()}

    def get_locals(self):
        return {key: repr(value) for key, value in locals().items()}

    def get_plugin(self, name):
        return self._plugin_manager.get_plugin(name)

    def get_plugin_version_info(self):
        return self._plugin_manager.get_plugin_version_info()

    def create_session_context(self, context_request=None, *, src_uuid=None, keyword_mapping=None):
        session_cache = self._sessions.get(context_request.session_uuid)

        if session_cache is None:
            raise ValueError(f'Invalid session_uuid: {context_request.session_uuid}')

        context = session_cache.create_context(
            src_uuid=src_uuid,
            keyword_mapping=keyword_mapping
        )

        if context_request is not None:

            for item_request in context_request:
                import_path = item_request.import_path
                call_import = item_request.call_import
                call_args = item_request.call_args
                call_kwargs = item_request.call_kwargs
                method_name = item_request.method_name

                try:
                    context_item = item_request.get_item()

                    if context_item is None:
                        value = self._import_from_path(item_request.import_path)

                        if item_request.call_import:
                            args = item_request.call_args or ()
                            kwargs = item_request.call_kwargs or {}
                            value = value(*args, **kwargs)

                        if item_request.method_name is not None:
                            value = getattr(value, item_request.method_name)

                        item_request.set_value(value)
                        context_item = item_request.get_item()

                    assert context_item is not None
                    context.add_item(context_item)

                except Exception as exc:
                    raise RuntimeError(f'Exception during context item request '
                                       f'\n\t(import_path={import_path}, call_import={call_import}, '
                                       f'call_args={call_args}, call_kwargs={call_kwargs}, '
                                       f'method_name={method_name})\nException: \n\t{str(exc)}')

        return context.uuid

    def clear_session_context(self, session_uuid, context_uuid):
        session_cache = self._sessions.get(session_uuid)

        if session_cache is None:
            raise ValueError(f'Invalid session_uuid: {session_uuid}')

        session_cache.clear_context(context_uuid)

    def add_ext_request_handler(self, ext_handler):
        BaseRpcRequestHandler.register_ext_handler(ext_handler)

    def remove_ext_request_handler(self, name):
        BaseRpcRequestHandler.unregister_ext_handler(name)

    def get_session_count(self):
        return len(self._sessions)

    def create_session(self):
        session_uuid = str(uuid4())

        logger.debug(f'{repr(self)}: creation_session -> session_uuid: {session_uuid}')

        self._sessions[session_uuid] = RpcSessionObjectCache(session_uuid)
        return session_uuid

    def clear_session(self, session_uuid):
        session_object_cache = self._sessions.pop(session_uuid, None)

        if session_object_cache is not None:
            session_object_cache.clear()

    def get_plugin_names(self):
        return list(self._plugin_manager.keys())

    def get_local_plugin_names(self):
        return list(self._plugin_manager.get_local_plugin_names())

    def get_immutable_plugin_names(self):
        return self._plugin_manager.get_immutable_plugin_names()

    def handle_request(self, binary):
        rpc_request = RpcRequestPacket.deserialize(binary)

        logger.debug(f'{repr(self)}: handle_request -> rpc_request: {str(rpc_request)}')

        session_uuid = rpc_request.session_uuid
        class_name = rpc_request.class_name
        plugin_name = rpc_request.plugin_name
        session_cache = self._sessions.get(session_uuid)

        if class_name is not None:
            logger.debug(f'{repr(self)}: handle_request -> retrieving object from cache')
            object_hash = rpc_request.object_hash

            if object_hash is None:
                raise ValueError('object_hash must be defined with class_name')

            if session_cache is None:
                raise ValueError(f'Invalid session: {session_uuid}')

            callable_object = session_cache.get_wrapper(
                class_name=class_name,
                object_hash=object_hash
            )

        else:
            logger.debug(f'{repr(self)}: handle_request -> retrieving plugin')
            callable_object = self._plugin_manager.get_plugin(plugin_name)

        if callable_object is None:
            raise ValueError(f'No such plugin: {plugin_name}')

        attr_name = rpc_request.attribute_name
        context_uuid = rpc_request.context_uuid

        if context_uuid is not None:

            if session_uuid is None:
                raise ValueError(f'Invalid session: {session_uuid}')

            ctx = session_cache.get_context(context_uuid)

            if ctx is None:
                raise ValueError(f'Invalid context_uuid: {context_uuid}')

            logger.debug(f'{repr(self)}: handle_request -> context: {repr(ctx)}')

            args = ctx.args
            kwargs = ctx.kwargs

        else:
            args = rpc_request.callable_args or ()
            kwargs = rpc_request.callable_kwargs or {}

        logger.debug(f'{repr(self)}: handle_request -> '
                     f'local_object_wrapper: {repr(callable_object)}, '
                     f'attribute_name: {attr_name}, args: {args}, kwargs: {kwargs}')

        unmarshaled_data = callable_object(attr_name, *args, **kwargs)

        response = RpcResponsePacket(
            unmarshaled_data=unmarshaled_data,
            session_cache=session_cache
        )
        response.marshal()
        return response.serialize()

    def ping(self):
        return True

    def shutdown(self):
        self.quit = True

    def serve_forever(self):
        logger.debug(f'{repr(self)}: serve_forever -> starting...')

        while not self.quit:
            self._xml_rpc_server.handle_request()

        logger.debug(f'{repr(self)}: serve_forever -> stopping...')
