import atexit
from uuid import uuid4
import win32event
from zeus_win32_utils import create_security_attributes


class GlobalEvent:
    @classmethod
    def open(cls, name, access=win32event.EVENT_ALL_ACCESS, inherit_handle=False):
        handle = win32event.OpenEvent(access, inherit_handle, f'Global\{name}')
        return cls(handle=handle, name=name)

    @classmethod
    def create(cls, name=None, sa=None, manual_reset=False, signaled=False):
        name = name or str(uuid4())
        sa = sa or create_security_attributes()
        handle = win32event.CreateEvent(sa, manual_reset, signaled, f'Global\{name}')
        return cls(handle=handle, name=name)

    def __init__(self, handle, name):
        self.handle = handle
        self.name = name
        atexit.register(self.close)

    def close(self):
        if self.handle is not None:
            self.handle.Close()
            self.handle = None

    def set(self):
        if self.handle is None:
            raise RuntimeError('Event closed')

        win32event.SetEvent(self.handle)

    def is_set(self):
        if self.handle is None:
            raise RuntimeError('Event closed')

        return win32event.WaitForSingleObject(self.handle, 0) == win32event.WAIT_OBJECT_0

    def wait(self, timeout=None):
        if self.handle is None:
            raise RuntimeError('Event closed')

        timeout = (timeout * 1000) if timeout is not None else win32event.INFINITE
        return win32event.WaitForSingleObject(self.handle, timeout) == win32event.WAIT_OBJECT_0

    def reset(self):
        if self.handle is None:
            raise RuntimeError('Event closed')

        win32event.ResetEvent(self.handle)


class EventManager:
    def __init__(self):
        self._cache = {}

    def clear(self):
        self._cache.clear()

    def create_event(self):
        event = GlobalEvent.create()
        self._cache[event.name] = event
        return event

    def open_event(self, name):
        event = GlobalEvent.open(name)
        self._cache[event.name] = event
        return event

    def wait_for_event(self, name, timeout=None):
        event = self._cache.get(name)

        if event is None:
            event = self.open_event(name)

        return event.wait(timeout=timeout)

    def set_event(self, name):
        event = self._cache.get(name)

        if event is None:
            event = self.open_event(name)

        event.set()

    def reset_event(self, name):
        event = self._cache.get(name)

        if event is None:
            event = self.open_event(name)

        event.reset()

    def check_event(self, name):
        event = self._cache.get(name)

        if event is None:
            event = self.open_event(name)

        return event.is_set()

    def delete_event(self, name):
        if name in self._cache:
            del self._cache[name]
