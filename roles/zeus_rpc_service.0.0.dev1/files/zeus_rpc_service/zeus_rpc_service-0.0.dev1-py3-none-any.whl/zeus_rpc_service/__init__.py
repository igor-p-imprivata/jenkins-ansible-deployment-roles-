# __init__.py
from zeus_rpc_service.service import (
    install_service,
    remove_service,
    start_service,
    stop_service
)
from zeus_rpc_service.server import (
    RpcServer,
    ExtendedRequestHandler
)
from zeus_rpc_service.client import (
    RpcServiceProxy,
    STATION_NAME_SERVICES,
    STATION_NAME_CONSOLE
)
from zeus_rpc_service.plugins import PluginDefinition
from zeus_rpc_service.definitions import (
    SVC_PORT,
    PLUGIN_NAME_ROOT,
    PLUGIN_NAME_CODE_IMPORTER,
    PLUGIN_NAME_PACKAGES,
    PLUGIN_NAME_EVENTS,
    PLUGIN_NAME_FILES,
)

__all__ = [
    'RpcServer',

    'RpcServiceProxy',

    'ExtendedRequestHandler',

    'PluginDefinition',

    'install_service',
    'remove_service',
    'start_service',
    'stop_service',

    'SVC_PORT',

    'PLUGIN_NAME_ROOT',
    'PLUGIN_NAME_CODE_IMPORTER',
    'PLUGIN_NAME_PACKAGES',
    'PLUGIN_NAME_FILES',
    'PLUGIN_NAME_EVENTS',

    'STATION_NAME_SERVICES',
    'STATION_NAME_CONSOLE',
]
