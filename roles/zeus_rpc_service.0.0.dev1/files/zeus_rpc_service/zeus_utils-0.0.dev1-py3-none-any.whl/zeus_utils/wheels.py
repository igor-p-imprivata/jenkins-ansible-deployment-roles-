# wheels.py
import zipfile


METADATA_EXT = 'METADATA'


def _int_or_str(value):
    try:
        return int(value)
    except ValueError:
        return value


def normalize_package_name(name):
    return name.replace('-', '_')


def normalize_package_version(version):
    return tuple(map(_int_or_str, version.split('.')))


class WheelMetadata:
    def __init__(self, path):
        self.path = path
        self.__metadata = None

    def __repr__(self):
        return f'{self.__class__.__name__}(path="{self.path}")'

    def __str__(self):
        lines = [repr(self) + ':']

        for key, value in self.items():
            lines.append(f'\t{key} = {value}')

        return '\n'.join(lines)

    def __iter__(self):
        self._ensure_metadata()
        yield from self.keys()

    def __contains__(self, item):
        return item.lower() in self.__metadata

    def __len__(self):
        return len(self.__metadata)

    def __getitem__(self, item):
        self._ensure_metadata()
        return self.__metadata[item.lower()]

    @property
    def package_name(self):
        self._ensure_metadata()
        return normalize_package_name(self.__metadata['name'])

    @property
    def package_version(self):
        self._ensure_metadata()
        return normalize_package_version(self.__metadata['version'])

    def _read_metadata(self):
        with zipfile.ZipFile(self.path) as zf:
            for file_name in zf.namelist():
                if file_name.endswith(METADATA_EXT):
                    metadata = zf.open(file_name).read().decode('utf-8', 'strict')
                    break
            else:
                raise RuntimeError(f'Unable to find {METADATA_EXT} file')

        return metadata

    def _ensure_metadata(self):
        if self.__metadata is None:
            md = self._read_metadata()
            md_map = {}

            for line in filter(None, (line.strip() for line in md.splitlines() if ':' in line)):
                key, value = tuple(part.strip() for part in line.split(':', 1))
                key = key.lower()

                if key in md_map:

                    if not isinstance(md_map[key], list):
                        existing_value = md_map.pop(key)
                        md_map[key] = [existing_value]

                    md_map[key].append(value)

                else:
                    md_map[key] = value

            self.__metadata = md_map

    def keys(self):
        self._ensure_metadata()
        yield from self.__metadata.keys()

    def values(self):
        self._ensure_metadata()
        yield from self.__metadata.values()

    def items(self):
        self._ensure_metadata()
        yield from self.__metadata.items()
