# __init__.py
from .core import get_version_info, FileManager


__all__ = ['get_version_info', 'FileManager']
