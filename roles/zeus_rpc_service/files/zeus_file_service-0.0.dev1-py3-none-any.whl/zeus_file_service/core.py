# core.py
import os
import time
import logging
import pywintypes
import win32api
import win32file
from enum import Enum
from string import ascii_uppercase
from shutil import rmtree
from zeus_utils import (
    split_path, find_by_attrs, findall_by_attrs, unzip_from_bytes, LanguageID
)
from zeus_win32_utils import BinaryType


FILE_ROOT_NAME = 'COMPUTER'
DEFAULT_POLL_INTERVAL = 0.2
FILE_VERSION_INFO_TRANS_ARRAY = 'Translation'

logger = logging.getLogger(__name__)


def get_version_info(file_path):
    return FileVersionInfo(file_path)


class FileVersionSubBlockRoots(Enum):
    ROOT = '\\'
    VAR_FILE_INFO = '\\VarFileInfo'
    STRING_FILE_INFO = '\\StringFileInfo'


class FileVersionNumericVersionKeys(Enum):
    FILE = 'FileVersion'
    PRODUCT = 'ProductVersion'


class FileVersionStringNames(Enum):
    COMMENTS = 'Comments'
    INTERNAL_NAME = 'InternalName'
    PRODUCT_NAME = 'ProductName'
    COMPANY_NAME = 'CompanyName'
    LEGAL_COPYRIGHT = 'LegalCopyright'
    PRODUCT_VERSION = 'ProductVersion'
    FILE_DESCRIPTION = 'FileDescription'
    LEGAL_TRADEMARKS = 'LegalTrademarks'
    PRIVATE_BUILD = 'PrivateBuild'
    FILE_VERSION = 'FileVersion'
    ORIGINAL_FILENAME = 'OriginalFilename'
    SPECIAL_BUILD = 'SpecialBuild'


class FileVersionInfo:
    @staticmethod
    def numeric_version_to_tuple(version_ms, version_ls):
        return (
            (version_ms >> 16) & 0xFFFF,
            (version_ms >> 0) & 0xFFFF,
            (version_ls >> 16) & 0xFFFF,
            (version_ls >> 0) & 0xFFFF
        )

    def __init__(self, file_path):
        self.file_path = file_path
        self._languages = None
        self._code_pages = None
        self._string_cache = {}
        self._root_info = None
        self._version_tuple_cache = None

    @property
    def languages(self):
        self.ensure_languages_and_code_pages()
        return tuple(self._languages)

    @property
    def code_pages(self):
        self.ensure_languages_and_code_pages()
        return tuple(self._code_pages)

    @property
    def comments(self):
        return self.get_string(FileVersionStringNames.COMMENTS)

    @property
    def internal_name(self):
        return self.get_string(FileVersionStringNames.INTERNAL_NAME)

    @property
    def product_name(self):
        return self.get_string(FileVersionStringNames.PRODUCT_NAME)

    @property
    def product_version(self):
        return self.get_string(FileVersionStringNames.PRODUCT_VERSION)

    @property
    def file_description(self):
        return self.get_string(FileVersionStringNames.FILE_DESCRIPTION)

    @property
    def legal_trademarks(self):
        return self.get_string(FileVersionStringNames.LEGAL_TRADEMARKS)

    @property
    def private_build(self):
        return self.get_string(FileVersionStringNames.PRIVATE_BUILD)

    @property
    def file_version(self):
        return self.get_string(FileVersionStringNames.FILE_VERSION)

    @property
    def original_filename(self):
        return self.get_string(FileVersionStringNames.ORIGINAL_FILENAME)

    @property
    def special_build(self):
        return self.get_string(FileVersionStringNames.SPECIAL_BUILD)

    @property
    def file_version_tuple(self):
        return self.get_version_tuple(FileVersionNumericVersionKeys.FILE)

    @property
    def product_version_tuple(self):
        return self.get_version_tuple(FileVersionNumericVersionKeys.PRODUCT)

    def get_sub_block(self, root, trunk=None, leaf=None):
        if root not in FileVersionSubBlockRoots:
            root = FileVersionSubBlockRoots(root)

        parts = [root.value]

        if trunk is not None:
            parts.append(trunk)

        if leaf is not None:
            if leaf == FILE_VERSION_INFO_TRANS_ARRAY:
                parts.append(leaf)

            else:
                if leaf not in FileVersionStringNames:
                    leaf = FileVersionStringNames(leaf)

                parts.append(leaf.value)

        sub_block = '\\'.join(parts)
        return win32api.GetFileVersionInfo(self.file_path, sub_block)

    def ensure_languages_and_code_pages(self):
        if self._languages is None and self._code_pages is None:
            self._languages = []
            self._code_pages = []

            results = self.get_sub_block(FileVersionSubBlockRoots.VAR_FILE_INFO,
                                         leaf=FILE_VERSION_INFO_TRANS_ARRAY)

            if not results:
                raise RuntimeError(f'No translations for {self.file_path}')

            for lang_id, code_page in results:
                self._languages.append(LanguageID(lang_id))
                self._code_pages.append(code_page)

    def ensure_root_info(self):
        if self._root_info is None:
            self._root_info = self.get_root_info()

    def ensure_version_tuples(self):
        if self._version_tuple_cache is None:
            self._version_tuple_cache = {}
            file_version = FileVersionNumericVersionKeys.FILE.value
            product_version = FileVersionNumericVersionKeys.PRODUCT.value
            self.ensure_root_info()

            mapping = {
                file_version: {},
                product_version: {}
            }

            for key, value in self._root_info.items():
                sub_map = mapping.get(key[:-2])

                if sub_map is not None:
                    sub_map[key[-2:]] = value

            for key, value in mapping.items():
                as_tuple = self.numeric_version_to_tuple(value['MS'], value['LS'])
                self._version_tuple_cache[FileVersionNumericVersionKeys(key)] = as_tuple

    def get_version_tuple(self, version_key):
        if version_key not in FileVersionNumericVersionKeys:
            version_key = FileVersionNumericVersionKeys(version_key)

        self.ensure_version_tuples()
        return self._version_tuple_cache[version_key]

    def get_string(self, string_name, lang_id=None, code_page=None):
        self.ensure_languages_and_code_pages()
        lang_id = lang_id or self._languages[0]
        code_page = code_page or self._code_pages[0]

        if lang_id not in LanguageID:
            lang_id = LanguageID(lang_id)

        if string_name not in FileVersionStringNames:
            string_name = FileVersionStringNames(string_name)

        cache_key = (lang_id.value, code_page, string_name.value)
        string = self._string_cache.get(cache_key)

        if string is None:
            lang_code_page = '{:04x}{:04x}'.format(lang_id.value, code_page)
            string = self.get_sub_block(root=FileVersionSubBlockRoots.STRING_FILE_INFO,
                                        trunk=lang_code_page,
                                        leaf=string_name)
            self._string_cache[cache_key] = string

        return string

    def get_string_info(self, lang_id=None, code_page=None):
        string_info = {}

        for string_name in FileVersionStringNames:
            string_info[string_name.value] = self.get_string(string_name, lang_id=lang_id,
                                                             code_page=code_page)

        return string_info

    def get_root_info(self):
        return self.get_sub_block(root=FileVersionSubBlockRoots.ROOT)


class FileObject:
    def __init__(self, name, parent=None):
        self.name = name
        self.parent = parent
        self._children = {}
        self._path = None
        self._enumerated = False

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    def __str__(self):
        return f'{self.__class__.__name__}(path="{self.get_path()}")'

    def __iter__(self):
        self._ensure_enumerated()

        for child in self._children.values():
            yield child
            yield from child

    def __getitem__(self, item):
        if not isinstance(item, str):
            raise TypeError(f'{self.__class__.__name__} indices must be str')

        self._ensure_enumerated()

        if os.sep in item:
            current = self

            for name in split_path(item):
                child = current.get_child(name)

                if child is None:
                    raise ValueError(f'{current} has no child named "{name}"')

                current = child

            return current

        else:
            return self.get_child(item)

    @property
    def path(self):
        return self.get_path()

    def _ensure_enumerated(self):
        if not self._enumerated:
            self.enumerate()
            self._enumerated = True

    def get_child(self, name):
        self._ensure_enumerated()
        return self._children.get(name.lower())

    def enumerate(self):
        pass

    def get_path(self):
        if self._path is None:
            current = self
            names = []

            while current.name != FILE_ROOT_NAME:
                names.append(current.name)
                current = current.parent

            names.reverse()
            self._path = os.path.join(*names)

        return self._path

    def delete(self):
        raise NotImplementedError()

    def clear(self):
        for child in self._children.values():
            child.clear()

        self._children.clear()
        self._enumerated = False


class File(FileObject):
    def __init__(self, name, parent=None):
        super(File, self).__init__(name, parent=parent)
        self.mode = None
        self._file_version_info = None
        self._enumerated = True
        self._handle = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    @property
    def version_info(self):
        if self._file_version_info is None:
            self._file_version_info = FileVersionInfo(self.get_path())

        return self._file_version_info

    @property
    def binary_type(self):
        # noinspection PyUnresolvedReferences
        try:
            return BinaryType(win32file.GetBinaryType(self.get_path()))
        except pywintypes.error:
            pass

    def open(self, mode='r'):
        self.mode = mode
        self._handle = open(self.get_path(), mode)

    def close(self):
        self._handle.close()
        self._handle = None

    def read(self, n=-1):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        return self._handle.read(n)

    def write(self, s):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        self._handle.write(s)

    def readline(self, limit=-1):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        return self._handle.readline(limit)

    def readlines(self, hint=-1):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        return self._handle.readlines(hint)

    def writelines(self, lines):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        self._handle.writelines(lines)

    def readable(self):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        return self._handle.readable()

    def writable(self):
        if self._handle is None:
            raise RuntimeError(f'{self.get_path()} is not open')

        return self._handle.writable()

    def delete(self):
        win32api.DeleteFile(self.get_path())


class Directory(FileObject):
    def enumerate(self):
        path = self.get_path()

        try:
            names = os.listdir(path)
        except PermissionError:
            return

        logger.debug(f'{repr(self)}: enumerate -> listdir results: {names}')

        for name in names:
            if os.path.isdir(os.path.join(path, name)):
                self.add_directory(name)

            else:
                self.add_file(name)

    def add_file(self, name):
        file_ = File(name, parent=self)
        self._children[file_.name.lower()] = file_
        return file_

    def add_directory(self, name):
        directory = Directory(name, parent=self)
        self._children[directory.name.lower()] = directory
        return directory

    def find(self, *root_paths, case_insensitive=True, sub_string=True, **attributes):
        self._ensure_enumerated()

        if root_paths:
            for root_path in root_paths:
                root = self.__getitem__(root_path)
                result = root.find(case_insensitive=case_insensitive, sub_string=sub_string,
                                   **attributes)

                if result is not None:
                    return result

        else:
            return find_by_attrs(iter(self), case_insensitive=case_insensitive,
                                 sub_string=sub_string, attrs=attributes)

    def findall(self, *root_paths, case_insensitive=True, sub_string=True, **attributes):
        self._ensure_enumerated()

        if root_paths:
            results = []

            for root_path in root_paths:
                root = self.__getitem__(root_path)
                result = root.findall(case_insensitive=case_insensitive, sub_string=sub_string,
                                      **attributes)
                results.extend(result)

            return results

        return findall_by_attrs(iter(self), case_insensitive=case_insensitive,
                                sub_string=sub_string, attrs=attributes)

    def delete(self):
        rmtree(self.get_path())


# noinspection PyMethodMayBeStatic
class FileManager(Directory):
    def __init__(self, default_directory=None):
        super(FileManager, self).__init__(name=FILE_ROOT_NAME)
        self._default_directory = None

        if default_directory is not None:
            self.set_default_directory(default_directory)

    def get_default_directory(self):
        if self._default_directory is None:
            self.set_default_directory('C:')

        return self._default_directory

    def set_default_directory(self, path):
        self._ensure_enumerated()
        self._default_directory = self.__getitem__(path)

    def enumerate(self):
        for letter in ascii_uppercase:
            drive_name = f'{letter}:\\'

            if os.path.exists(drive_name):
                self.add_directory(drive_name)

    def add_drive(self, path):
        if not path.endswith('\\'):
            path += '\\'

        self.add_directory(path)

    def get_path(self):
        return FILE_ROOT_NAME

    def delete_file(self, file_path):
        win32api.DeleteFile(file_path)

    def copy_file(self, src, dest_dir=None, file_name=None, fail_if_exists=False):
        if dest_dir is None:
            dest_dir = self.get_default_directory().path

        if file_name is None:
            file_name = split_path(src).pop()

        dest = os.path.join(dest_dir, file_name)
        win32api.CopyFile(src, dest, fail_if_exists)
        return self.wait_for_file(dest)

    def wait_for_file(self, path, timeout=None, interval=DEFAULT_POLL_INTERVAL):
        path = path.lower()
        start = time.time()
        parent_dir_name, file_name = os.path.split(path)
        parent_dir = self.__getitem__(parent_dir_name)

        if parent_dir is None:
            raise NotADirectoryError(f'"{parent_dir_name}"')

        logger.debug(f'wait_for_file -> parent_dir: {repr(parent_dir)}, file_name: {file_name}')

        while True:
            try:
                file_obj = parent_dir.get_child(file_name)
            except ValueError:
                file_obj = None

            if file_obj is not None:
                logger.debug(f'wait_for_file -> found file: {repr(file_obj)}')
                return file_obj

            if timeout is not None and (time.time() - start) > timeout:
                raise TimeoutError()

            logger.debug(f'wait_for_file -> file not found, clearing state and sleeping '
                         f'{interval} second(s)')

            parent_dir.clear()
            time.sleep(interval)

    def get_file(self, path):
        return self.__getitem__(path)

    def unzip(self, data, compression, extract_dir=None):
        unzipped_files = []

        if extract_dir is None:
            extract_dir = self.get_default_directory().path

        for path in unzip_from_bytes(extract_dir, data, compression=compression):
            unzipped_files.append(path)

        return [self.wait_for_file(path=path) for path in unzipped_files]
