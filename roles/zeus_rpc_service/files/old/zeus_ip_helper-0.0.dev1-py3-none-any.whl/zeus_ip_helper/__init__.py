# __init__.py
from .api import ping


__all__ = ['ping']
