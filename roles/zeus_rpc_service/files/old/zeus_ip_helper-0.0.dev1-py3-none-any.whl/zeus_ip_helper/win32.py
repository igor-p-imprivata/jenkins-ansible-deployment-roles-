# _win32.py
import re
import socket
import ctypes
from ctypes import wintypes
from uuid import uuid4
from enum import Enum
from ipaddress import ip_address as ip_addr_factory
from typing import Union
from .base import IcmpPacketBase, PingBase
from .enums import TcpState, TcpTableClass, UdpTableClass, IpNetTableTypes
from .utils import ObjectProxy, TableView, MacAddress
from .socket_utils import get_hostname, resolve, ip2int, int2ip, IPAddr
from .ctypes_utils import c_array_from_buffer


IP_ERR_STR_BUF_SIZE = 1000
ICMP_ECHO_REPLY_ERR_SIZE = 8

IGNORE_FIELD_VALUE = str(uuid4())


def _ignore_field(row_st, name):
    return IGNORE_FIELD_VALUE


####################
# TYPE DEFINITIONS #
####################
UCHAR = ctypes.c_ubyte
PUCHAR = ctypes.POINTER(UCHAR)
ULONGLONG = ctypes.c_ulonglong
NET_IFINDEX = wintypes.ULONG
IF_INDEX = NET_IFINDEX

MAC_ADDR_BYTES_LEN = 6
ERROR_BUFFER_OVERFLOW = 111
TCPIP_OWNER_MODULE_INFO_BASIC = 0  # TODO is this correct? one and only enum member

ANY_SIZE = 1
MAXLEN_PHYSADDR = 8
TCPIP_OWNING_MODULE_SIZE = 16
MAX_ADAPTER_DESCRIPTION_LENGTH = 128
MAX_ADAPTER_NAME_LENGTH = 256
MAX_ADAPTER_ADDRESS_LENGTH = 8

MIB_IPNET_TYPE_OTHER = 1
MIB_IPNET_TYPE_INVALID = 2
MIB_IPNET_TYPE_DYNAMIC = 3
MIB_IPNET_TYPE_STATIC = 4


# noinspection PyPep8Naming
class IP_OPTION_INFORMATION(ctypes.Structure):
    _fields_ = [
        ('Ttl', UCHAR),
        ('Tos', UCHAR),
        ('Flags', UCHAR),
        ('OptionsSize', UCHAR),
        ('OptionsData', PUCHAR),
    ]


PIP_OPTION_INFORMATION = ctypes.POINTER(IP_OPTION_INFORMATION)


# noinspection PyPep8Naming
class ICMP_ECHO_REPLY(ctypes.Structure):
    _fields_ = [
        ('Address', IPAddr),
        ('Status', wintypes.ULONG),
        ('RoundTripTime', wintypes.ULONG),
        ('DataSize', wintypes.USHORT),
        ('Reserved', wintypes.USHORT),
        ('Data', wintypes.LPVOID),
        ('Options', IP_OPTION_INFORMATION)
    ]


PICMP_ECHO_REPLY = ctypes.POINTER(ICMP_ECHO_REPLY)


class MIB_IPNETROW(ctypes.Structure):
    class _type_U(ctypes.Union):
        _fields_ = [
            ('dwType', wintypes.DWORD),
            ('Type', ctypes.c_int)
        ]

    _anonymous_ = ('u',)

    _fields_ = [
        ('dwIndex', IF_INDEX),
        ('dwPhysAddrLen', wintypes.DWORD),
        ('bPhysAddr', ctypes.c_ubyte * MAXLEN_PHYSADDR),
        ('dwAddr', wintypes.DWORD),
        ('u', _type_U)
    ]


class MIB_IPNETTABLE(ctypes.Structure):
    pass

PMIB_IPNETTABLE = ctypes.POINTER(MIB_IPNETTABLE)


class MIB_TCPROW(ctypes.Structure):
    class _type_U(ctypes.Union):
        _fields_ = [
            ('dwState', wintypes.DWORD),
            ('State', ctypes.c_int)
        ]

    _anonymous_ = ('u',)

    _fields_ = [
        ('u', _type_U),
        ('dwLocalAddr', wintypes.DWORD),
        ('dwLocalPort', wintypes.DWORD),
        ('dwRemoteAddr', wintypes.DWORD),
        ('dwRemotePort', wintypes.DWORD)
    ]


class MIB_TCPTABLE(ctypes.Structure):
    pass

PMIB_TCPTABLE = ctypes.POINTER(MIB_TCPTABLE)


class MIB_TCPROW_OWNER_MODULE(ctypes.Structure):
    _fields_ = [
        ('dwState', wintypes.DWORD),
        ('dwLocalAddr', wintypes.DWORD),
        ('dwLocalPort', wintypes.DWORD),
        ('dwRemoteAddr', wintypes.DWORD),
        ('dwRemotePort', wintypes.DWORD),
        ('dwOwningPid', wintypes.DWORD),
        ('liCreateTimestamp', wintypes.LARGE_INTEGER),
        ('OwningModuleInfo', ULONGLONG * TCPIP_OWNING_MODULE_SIZE)
    ]

PMIB_TCPROW_OWNER_MODULE = ctypes.POINTER(MIB_TCPROW_OWNER_MODULE)


class MIB_TCPTABLE_OWNER_MODULE(ctypes.Structure):
    pass

PMIB_TCPTABLE_OWNER_MODULE = ctypes.POINTER(MIB_TCPTABLE_OWNER_MODULE)


class MIB_TCPROW_OWNER_PID(ctypes.Structure):
    _fields_ = [
        ('dwState', wintypes.DWORD),
        ('dwLocalAddr', wintypes.DWORD),
        ('dwLocalPort', wintypes.DWORD),
        ('dwRemoteAddr', wintypes.DWORD),
        ('dwRemotePort', wintypes.DWORD),
        ('dwOwningPid', wintypes.DWORD)
    ]

PMIB_TCPROW_OWNER_PID = ctypes.POINTER(MIB_TCPROW_OWNER_PID)


class TCPIP_OWNER_MODULE_BASIC_INFO(ctypes.Structure):
    _fields_ = [
        ('pModuleName', wintypes.PWCHAR),
        ('pModulePath', wintypes.PWCHAR)
    ]

PTCPIP_OWNER_MODULE_BASIC_INFO = ctypes.POINTER(TCPIP_OWNER_MODULE_BASIC_INFO)


class MIB_TCPTABLE_OWNER_PID(ctypes.Structure):
    pass

PMIB_TCPTABLE_OWNER_PID = ctypes.POINTER(MIB_TCPTABLE_OWNER_PID)


class MIB_UDPROW(ctypes.Structure):
    _fields_ = [
        ('dwLocalAddr', wintypes.DWORD),
        ('dwLocalPort', wintypes.DWORD)
    ]


class MIB_UDPTABLE(ctypes.Structure):
    pass

PMIB_UDPTABLE = ctypes.POINTER(MIB_UDPTABLE)


class MIB_UDPROW_OWNER_MODULE(ctypes.Structure):
    _anonymous_ = ('u',)

    class _u_Type(ctypes.Union):
        _anonymous_ = ('st',)

        class _st_Type(ctypes.Structure):
            _fields_ = [
                ('SpecificPortBind', ctypes.c_int)
            ]

        _fields_ = [
            ('st', _st_Type),
            ('dwFlags', ctypes.c_int)
        ]

    _fields_ = [
        ('dwLocalAddr', wintypes.DWORD),
        ('dwLocalPort', wintypes.DWORD),
        ('dwOwningPid', wintypes.DWORD),
        ('liCreateTimestamp', wintypes.LARGE_INTEGER),
        ('u', _u_Type),
        ('OwningModuleInfo', ULONGLONG * TCPIP_OWNING_MODULE_SIZE)
    ]

PMIB_UDPROW_OWNER_MODULE = ctypes.POINTER(MIB_UDPROW_OWNER_MODULE)


class MIB_UDPTABLE_OWNER_MODULE(ctypes.Structure):
    pass

PMIB_UDPTABLE_OWNER_MODULE = ctypes.POINTER(MIB_UDPTABLE_OWNER_MODULE)


class MIB_UDPROW_OWNER_PID(ctypes.Structure):
    _fields_ = [
        ('dwLocalAddr', wintypes.DWORD),
        ('dwLocalPort', wintypes.DWORD),
        ('dwOwningPid', wintypes.DWORD)
    ]

PMIB_UDPROW_OWNER_PID = ctypes.POINTER(MIB_UDPROW_OWNER_PID)


class MIB_UDPTABLE_OWNER_PID(ctypes.Structure):
    pass

PMIB_UDPTABLE_OWNER_PID = ctypes.POINTER(MIB_UDPTABLE_OWNER_PID)


class IP_ADDRESS_STRING(ctypes.Structure):
    _fields_ = [
        ('String', ctypes.c_char * 16)
    ]


IP_MASK_STRING = IP_ADDRESS_STRING


# noinspection PyPep8Naming
class IP_ADDR_STRING(ctypes.Structure):
    pass


PIP_ADDR_STRING = ctypes.POINTER(IP_ADDR_STRING)

# noinspection PyTypeChecker
IP_ADDR_STRING._fields_ = [("Next", ctypes.POINTER(IP_ADDR_STRING)),
                           ("IpAddress", IP_ADDRESS_STRING),
                           ("IpMask", IP_MASK_STRING),
                           ("Context", wintypes.DWORD)]


# noinspection PyPep8Naming
class IP_ADAPTER_INFO(ctypes.Structure):
    pass


PIP_ADAPTER_INFO = ctypes.POINTER(IP_ADAPTER_INFO)

# noinspection PyTypeChecker
IP_ADAPTER_INFO._fields_ = [("Next", ctypes.POINTER(IP_ADAPTER_INFO)),
                            ("ComboIndex", wintypes.DWORD),
                            ("AdapterName", ctypes.c_char * (MAX_ADAPTER_NAME_LENGTH + 4)),
                            ("Description", ctypes.c_char * (MAX_ADAPTER_DESCRIPTION_LENGTH + 4)),
                            ("AddressLength", ctypes.c_uint),
                            ("Address", ctypes.c_ubyte * MAX_ADAPTER_ADDRESS_LENGTH),
                            ("Index", ctypes.c_ulong),
                            ("Type", ctypes.c_uint),
                            ("DhcpEnabled", ctypes.c_uint),
                            ("CurrentIpAddress", PIP_ADDR_STRING),
                            ("IpAddressList", IP_ADDR_STRING),
                            ("GatewayList", IP_ADDR_STRING),
                            ("DhcpServer", IP_ADDR_STRING),
                            ("HaveWins", ctypes.c_uint),
                            ("PrimaryWinsServer", IP_ADDR_STRING),
                            ("SecondaryWinsServer", IP_ADDR_STRING),
                            ("LeaseObtained", ctypes.c_ulong),
                            ("LeaseExpires", ctypes.c_ulong)]

####################
# Loaded libraries #
####################
kernel32 = ctypes.windll.kernel32
iphlpapi = ctypes.windll.iphlpapi

####################################
# Windows API function definitions #
####################################
GetLastError = kernel32.GetLastError
GetLastError.restype = wintypes.DWORD

GetIpErrorString = iphlpapi.GetIpErrorString
GetIpErrorString.argtypes = (ctypes.c_int, ctypes.c_wchar_p, wintypes.PDWORD)
GetIpErrorString.restype = wintypes.DWORD

IcmpCreateFile = iphlpapi.IcmpCreateFile
IcmpCreateFile.restype = wintypes.HANDLE

IcmpCloseHandle = iphlpapi.IcmpCloseHandle
IcmpCloseHandle.argtypes = (wintypes.HANDLE,)
IcmpCloseHandle.restype = wintypes.BOOL

IcmpSendEcho = iphlpapi.IcmpSendEcho
IcmpSendEcho.argtypes = (wintypes.HANDLE,
                         IPAddr,
                         wintypes.LPVOID,
                         wintypes.WORD,
                         PIP_OPTION_INFORMATION,
                         wintypes.LPVOID,
                         wintypes.DWORD,
                         wintypes.DWORD)
IcmpSendEcho.restype = wintypes.DWORD

GetIpNetTable = iphlpapi.GetIpNetTable
GetIpNetTable.argtypes = (PMIB_IPNETTABLE, wintypes.PULONG, wintypes.BOOL)
GetIpNetTable.restype = wintypes.ULONG

FlushIpNetTable = iphlpapi.FlushIpNetTable
FlushIpNetTable.argtypes = (wintypes.DWORD,)
FlushIpNetTable.restype = wintypes.DWORD

GetTcpTable = iphlpapi.GetTcpTable
GetTcpTable.argtypes = (PMIB_TCPTABLE, wintypes.PULONG, wintypes.BOOL)
GetTcpTable.restype = wintypes.ULONG

GetExtendedTcpTable = iphlpapi.GetExtendedTcpTable
GetExtendedTcpTable.argtypes = (wintypes.LPVOID,
                                wintypes.PDWORD,
                                wintypes.BOOL,
                                wintypes.ULONG,
                                ctypes.c_int,
                                wintypes.ULONG)
GetExtendedTcpTable.restype = wintypes.DWORD

GetOwnerModuleFromTcpEntry = iphlpapi.GetOwnerModuleFromTcpEntry
GetOwnerModuleFromTcpEntry.argtypes = (PMIB_TCPROW_OWNER_MODULE,
                                       ctypes.c_int,
                                       wintypes.LPVOID,
                                       wintypes.PDWORD)
GetOwnerModuleFromTcpEntry.restype = wintypes.DWORD

GetExtendedUdpTable = iphlpapi.GetExtendedUdpTable
GetExtendedUdpTable.argtypes = (wintypes.LPVOID,
                                wintypes.PDWORD,
                                wintypes.BOOL,
                                wintypes.ULONG,
                                ctypes.c_int,
                                wintypes.ULONG)
GetExtendedUdpTable.restype = wintypes.DWORD

GetOwnerModuleFromUdpEntry = iphlpapi.GetOwnerModuleFromUdpEntry
GetOwnerModuleFromUdpEntry.argtypes = (PMIB_UDPROW_OWNER_MODULE,
                                       ctypes.c_int,
                                       wintypes.LPVOID,
                                       wintypes.PDWORD)
GetOwnerModuleFromUdpEntry.restype = wintypes.DWORD

GetAdaptersInfo = iphlpapi.GetAdaptersInfo
GetAdaptersInfo.restype = wintypes.ULONG
GetAdaptersInfo.argtypes = (PIP_ADAPTER_INFO, wintypes.PULONG)

######################################
# Windows specific functions/classes #
######################################

_tcp_tbl_cls2struct_types = {
    TcpTableClass.BASIC_ALL: (MIB_TCPTABLE, MIB_TCPROW),
    TcpTableClass.BASIC_CONNECTIONS: (MIB_TCPTABLE, MIB_TCPROW),
    TcpTableClass.BASIC_LISTENER: (MIB_TCPTABLE, MIB_TCPROW),

    TcpTableClass.OWNER_MODULE_ALL: (MIB_TCPTABLE_OWNER_MODULE, MIB_TCPROW_OWNER_MODULE),
    TcpTableClass.OWNER_MODULE_CONNECTIONS: (MIB_TCPTABLE_OWNER_MODULE, MIB_TCPROW_OWNER_MODULE),
    TcpTableClass.OWNER_MODULE_LISTENER: (MIB_TCPTABLE_OWNER_MODULE, MIB_TCPROW_OWNER_MODULE),

    TcpTableClass.OWNER_PID_ALL: (MIB_TCPTABLE_OWNER_PID, MIB_TCPROW_OWNER_PID),
    TcpTableClass.OWNER_PID_CONNECTIONS: (MIB_TCPTABLE_OWNER_PID, MIB_TCPROW_OWNER_PID),
    TcpTableClass.OWNER_PID_LISTENER: (MIB_TCPTABLE_OWNER_PID, MIB_TCPROW_OWNER_PID)
}


def tcp_tbl_cls2struct_types(tbl_cls):
    if tbl_cls not in TcpTableClass:
        tbl_cls = TcpTableClass(tbl_cls)

    return _tcp_tbl_cls2struct_types[tbl_cls]


_udp_tbl_cls2struct_types = {
    UdpTableClass.BASIC: (MIB_UDPTABLE, MIB_UDPROW),
    UdpTableClass.OWNER_PID: (MIB_UDPTABLE_OWNER_PID, MIB_UDPROW_OWNER_PID),
    UdpTableClass.OWNER_MODULE: (MIB_UDPROW_OWNER_MODULE, MIB_UDPTABLE_OWNER_MODULE)
}


def udp_tbl_cls2struct_types(tbl_cls):
    if tbl_cls not in UdpTableClass:
        tbl_cls = UdpTableClass(tbl_cls)

    return _udp_tbl_cls2struct_types[tbl_cls]


def get_extended_tcp_table(buffer, p_size, order, ip_version=socket.AF_INET,
                           table_class=TcpTableClass.OWNER_MODULE_ALL):
    af = wintypes.ULONG(ip_version)
    return GetExtendedTcpTable(buffer, p_size, order, af, table_class, 0)


def get_extended_udp_table(buffer, p_size, order, ip_version=socket.AF_INET,
                           table_class=UdpTableClass.OWNER_MODULE):
    af = wintypes.ULONG(ip_version)
    return GetExtendedUdpTable(buffer, p_size, order, af, table_class, 0)


def ip_addr_string2discrete_ip(ip_addr_string):
    node = ip_addr_string

    while node:
        ip_address = node.IpAddress

        if ip_address and ip_address != b'0.0.0.0':
            return ip_address.String.decode('utf-8', 'strict')

        node = node.Next


def calc_response_size(request_size: int):
    return ctypes.sizeof(ICMP_ECHO_REPLY) + request_size + ICMP_ECHO_REPLY_ERR_SIZE


def get_ip_error_string(errno: int, buf_size: int = IP_ERR_STR_BUF_SIZE):
    dw_buf_size = wintypes.DWORD(buf_size)
    buf = ctypes.create_unicode_buffer(dw_buf_size.value)
    GetIpErrorString(errno, buf, ctypes.byref(dw_buf_size))
    return buf.value


class IpHelperTableRow(ObjectProxy):
    def __init__(self, row_struct, **get_attr_map):
        super(IpHelperTableRow, self).__init__(obj=row_struct,
                                               normalize_name_func=ObjectProxy.to_lower_snake_case,
                                               **get_attr_map)

    def get_attr_names(self):
        # noinspection PyProtectedMember
        return [name for name, _ in self.object._fields_]


class NetworkProtocolTableRow(IpHelperTableRow):
    def __init__(self, row_struct, get_owner_module, **get_attr_map):
        self._get_owner_module = get_owner_module
        super(NetworkProtocolTableRow, self).__init__(row_struct=row_struct, **get_attr_map)

    def get_attrs(self):
        size = wintypes.DWORD(0)
        buf = None
        self._get_owner_module(ctypes.byref(self.object), TCPIP_OWNER_MODULE_INFO_BASIC,
                               buf, ctypes.byref(size))

        buf = ctypes.create_unicode_buffer(size.value)
        self._get_owner_module(ctypes.byref(self.object), TCPIP_OWNER_MODULE_INFO_BASIC,
                               buf, ctypes.byref(size))
        st = ctypes.cast(buf, PTCPIP_OWNER_MODULE_BASIC_INFO).contents
        self._attrs['module_name'] = ctypes.wstring_at(st.pModuleName)
        self._attrs['module_path'] = ctypes.wstring_at(st.pModulePath)
        super(NetworkProtocolTableRow, self).get_attrs()


class TcpTableRow(NetworkProtocolTableRow):

    def __init__(self, row_struct):

        def addr_get_attr(row_st, name):
            le_value = getattr(row_st, name)
            return int2ip(le_value)

        def port_get_attr(row_st, name):
            le_value = getattr(row_st, name)
            return socket.ntohs(le_value)

        def state_get_attr(row_st, name):
            return TcpState(getattr(row_st, name))

        super(TcpTableRow, self).__init__(row_struct=row_struct,
                                          get_owner_module=GetOwnerModuleFromTcpEntry,
                                          dwLocalAddr=addr_get_attr,
                                          dwLocalPort=port_get_attr,
                                          dwRemoteAddr=addr_get_attr,
                                          dwRemotePort=port_get_attr,
                                          dwState=state_get_attr,
                                          liCreateTimestamp=ObjectProxy.IGNORE,
                                          OwningModuleInfo=ObjectProxy.IGNORE)


class UdpTableRow(NetworkProtocolTableRow):
    def __init__(self, row_struct):

        def addr_get_attr(row_st, name):
            le_value = getattr(row_st, name)
            return int2ip(le_value)

        def port_get_attr(row_st, name):
            le_value = getattr(row_st, name)
            return socket.ntohs(le_value)

        super(UdpTableRow, self).__init__(row_struct=row_struct,
                                          get_owner_module=GetOwnerModuleFromUdpEntry,
                                          dwLocalAddr=addr_get_attr,
                                          dwLocalPort=port_get_attr,
                                          liCreateTimestamp=ObjectProxy.IGNORE,
                                          OwningModuleInfo=ObjectProxy.IGNORE,
                                          u=ObjectProxy.IGNORE)


class IpNetTableRow(IpHelperTableRow):
    def __init__(self, row_struct):

        def addr_get_attr(row_st, name):
            le_value = getattr(row_st, name)
            return int2ip(le_value)

        def phys_addr_get_attr(row_st, name):
            phys_addr_len = row_st.dwPhysAddrLen
            b_phys_addr = getattr(row_st, name)

            try:
                mac_addr = MacAddress.from_iterable(b_phys_addr, phys_addr_len)
            except ValueError:
                return None
            else:
                return mac_addr

        def union_get_attr(row_st, name):
            u_type = getattr(row_st, name)
            return IpNetTableTypes(getattr(u_type, 'dwType'))

        super(IpNetTableRow, self).__init__(row_struct=row_struct,
                                            dwAddr=addr_get_attr,
                                            bPhysAddr=phys_addr_get_attr,
                                            u=union_get_attr)


class IpHelperTableView(TableView):
    def __init__(self, get_func, table_struct, row_struct, row_type=IpHelperTableRow,
                 exclude_row_func=None, extra_args=None, generator=None):
        super(IpHelperTableView, self).__init__(generator=generator)
        self._get_func = get_func
        self._table_struct = table_struct
        self._row_struct = row_struct
        self._row_type = row_type
        self._exclude_row_func = exclude_row_func
        self._extra_args = tuple(extra_args or [])
        self._table = None

    def get_field_names(self, obj):
        return list(obj.keys())

    def get_table_row(self, obj):
        return list(obj.values())

    def iter_objects(self):
        order = wintypes.BOOL(False)
        size = wintypes.ULONG(0)

        self._get_func(None, ctypes.byref(size), order, *self._extra_args)

        self._table_struct._fields_ = [
            ('dwNumEntries', wintypes.DWORD),
            ('table', self._row_struct * size.value)
        ]

        self._table = self._table_struct()
        self._get_func(ctypes.byref(self._table), ctypes.byref(size), order)
        exclude_row_func = self._exclude_row_func

        for row_struct in self._table.table:
            if exclude_row_func is not None and exclude_row_func(row_struct):
                continue

            yield self._row_type(row_struct)


class TcpTableView(IpHelperTableView):
    def __init__(self, generator=None):
        attr_names = ('dwLocalAddr', 'dwLocalPort', 'dwRemoteAddr', 'dwRemotePort')

        def exclude_row_func(row_struct):
            return sum(getattr(row_struct, name) for name in attr_names) == 0

        super(TcpTableView, self).__init__(get_func=get_extended_tcp_table,
                                           table_struct=MIB_TCPTABLE_OWNER_MODULE,
                                           row_struct=MIB_TCPROW_OWNER_MODULE,
                                           row_type=TcpTableRow,
                                           exclude_row_func=exclude_row_func,
                                           generator=generator)


class UdpTableView(IpHelperTableView):
    def __init__(self, generator=None):
        attr_names = ('dwLocalAddr', 'dwLocalPort', 'dwOwningPid')

        def exclude_row_func(row_struct):
            return sum(getattr(row_struct, name) for name in attr_names) == 0

        super(UdpTableView, self).__init__(get_func=get_extended_udp_table,
                                           table_struct=MIB_UDPTABLE_OWNER_MODULE,
                                           row_struct=MIB_UDPROW_OWNER_MODULE,
                                           row_type=UdpTableRow,
                                           exclude_row_func=exclude_row_func,
                                           generator=generator)


class IpNetTableView(IpHelperTableView):
    def __init__(self, generator=None):
        attr_names = ('dwIndex', 'dwPhysAddrLen', 'dwAddr')

        def exclude_row_func(row_struct):
            return sum(getattr(row_struct, name) for name in attr_names) == 0

        super(IpNetTableView, self).__init__(get_func=GetIpNetTable,
                                             table_struct=MIB_IPNETTABLE,
                                             row_struct=MIB_IPNETROW,
                                             row_type=IpNetTableRow,
                                             exclude_row_func=exclude_row_func,
                                             generator=generator)


ip_net_table_view = IpNetTableView()
tcp_table_view = TcpTableView()
udp_table_view = UdpTableView()


class AdapterInfoRow(IpHelperTableRow):
    def __init__(self, row_struct):
        super(AdapterInfoRow, self).__init__(row_struct=row_struct)

    def flush_ip_net_table(self):
        dw_index = wintypes.DWORD(self.index)
        ret = FlushIpNetTable(dw_index)

        if ret != 0:
            raise WindowsError(ret, ctypes.FormatError(ret))


class AdapterInfoTableView(TableView):
    def __init__(self, generator=None):
        super(AdapterInfoTableView, self).__init__(generator=generator)

    def get_field_names(self, obj):
        return list(obj.keys())

    def get_table_row(self, obj):
        return list(obj.values())

    def iter_objects(self):
        buffer_len = ctypes.c_ulong(0)

        rc = GetAdaptersInfo(None, ctypes.byref(buffer_len))

        if rc != ERROR_BUFFER_OVERFLOW:
            raise WindowsError(rc, ctypes.FormatError(rc))

        # noinspection PyCallingNonCallable,PyTypeChecker
        buf = (IP_ADAPTER_INFO * int((buffer_len.value / ctypes.sizeof(IP_ADAPTER_INFO))))()
        rc = GetAdaptersInfo(buf, ctypes.byref(buffer_len))

        if rc != 0:
            raise WindowsError(rc, ctypes.FormatError(rc))

        for adapter in buf:
            yield AdapterInfoRow(adapter)


adapter_info_view = AdapterInfoTableView()


class IcmpPacket(IcmpPacketBase):
    @property
    def round_trip_time_ms(self):
        if self._reply is not None:
            return self._reply.RoundTripTime

    @property
    def remote_hostname(self):
        if self._reply is not None:
            return get_hostname(str(self._reply.Address))

    @property
    def remote_ip_address(self):
        if self._reply is not None:
            return ip_addr_factory(str(self._reply.Address))

    @property
    def ttl(self):
        if self._reply is not None:
            return self._reply.Options.Ttl

    @property
    def tos(self):
        if self._reply is not None:
            return self._reply.Options.Tos

    @property
    def timed_out(self):
        return self.exc_args is not None and self.exc_args[0] == 11010

    def send(self):
        self.response_data = bytearray(calc_response_size(len(self.request_data)))

        req_data = c_array_from_buffer(ctypes.c_ubyte, self.request_data)
        resp_data = c_array_from_buffer(ctypes.c_ubyte, self.response_data)

        handle = IcmpCreateFile()

        try:
            ret = IcmpSendEcho(handle,
                               ip2int(str(self.destination)),
                               req_data,
                               len(req_data),
                               None,
                               resp_data,
                               len(resp_data),
                               self.timeout_ms)

            assert 0 <= ret <= 1

            if ret == 0:
                last_error = GetLastError()
                err_string = get_ip_error_string(errno=last_error)
                self.exc_args = (last_error, err_string)

            else:
                p_echo_reply = ctypes.cast(ctypes.addressof(resp_data), PICMP_ECHO_REPLY)
                self._reply = p_echo_reply.contents

        finally:
            IcmpCloseHandle(handle)


class Ping(PingBase):
    def __init__(self, host: str, count: int, size: int, timeout: Union[int, float]):
        super(Ping, self).__init__(packet_type=IcmpPacket, host=host, count=count, size=size,
                                   timeout=timeout)

    @property
    def getaddrinfo_failed(self):
        return self._exc_args is not None and self._exc_args[0] == 11004

    def resolve_destination(self):
        try:
            destination = resolve(self.host, timeout=self.timeout)
        except socket.gaierror as exc:
            self._exc_args = exc.args
            return

        if destination is None:
            self._exc_args = (11004, 'getaddrinfo failed')
            return

        return destination
