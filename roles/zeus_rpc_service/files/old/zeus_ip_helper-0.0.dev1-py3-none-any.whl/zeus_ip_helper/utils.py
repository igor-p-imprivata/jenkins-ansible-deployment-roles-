# utils.py
import re
from collections import Callable, Iterable
from enum import Enum
from uuid import uuid4
from itertools import zip_longest
from prettytable import PrettyTable


MAC_ADDR_BYTES_LEN = 6


def cmp_attrs(obj, case_insensitive, sub_string, attrs, has_attr_func=hasattr, get_attr_func=getattr):
    for key, value in attrs.items():
        if not has_attr_func(obj, key):
            return False

        obj_attr_value = get_attr_func(obj, key)

        # str
        if isinstance(value, str) and isinstance(obj_attr_value, str):
            if case_insensitive:
                value = value.lower()
                obj_attr_value = obj_attr_value.lower()

            if (sub_string and value not in obj_attr_value) or obj_attr_value != value:
                return False

        # int
        elif isinstance(value, int):
            if int(value) != int(obj_attr_value):
                return False

        # func/callable
        elif isinstance(value, Callable):
            if not value(obj_attr_value):
                return False

        # re.match
        elif hasattr(value, 'match'):
            if not value.match(obj_attr_value):
                return False

        # identity
        else:
            if value is not obj_attr_value:
                return False

    return True


def iter_find_by_attrs(objects, case_insensitive, sub_string, attrs, has_attr_func=hasattr,
                       get_attr_func=getattr):
    for obj in objects:
        is_match = cmp_attrs(obj, case_insensitive=case_insensitive, sub_string=sub_string,
                             attrs=attrs, has_attr_func=has_attr_func, get_attr_func=get_attr_func)

        if is_match:
            yield obj


class SingletonMeta(type):
    _ = {}

    def __call__(cls, *args, **kwargs):
        instance = SingletonMeta._.get(cls)

        if instance is None:
            SingletonMeta._[cls] = instance = super(SingletonMeta, cls).__call__(*args, **kwargs)

        return instance


class ObjectProxy:
    _ignore_attr_value = str(uuid4())

    @staticmethod
    def _mark_ignore(*args):
        return ObjectProxy._ignore_attr_value

    IGNORE = _mark_ignore

    @staticmethod
    def to_lower_snake_case(name):
        return '_'.join((re.findall('[A-Z][^A-Z]*', name))).lower()

    def __init__(self, obj, normalize_name_func=None, **get_attr_map):
        self.object = obj
        self._normalize_name_func = normalize_name_func
        self._get_attr_map = get_attr_map
        self._attrs = {}
        self._attrs_resolved = False

    def __repr__(self):
        self._ensure_attrs_resolved()
        attrs_str_parts = []

        for key, value in self._attrs.items():
            if isinstance(value, Enum):
                value = value.name

            elif isinstance(value, str):
                value = f"'{value}'"

            attrs_str_parts.append(f'{key}={value}')

        return f'{self.__class__.__name__}({", ".join(attrs_str_parts)})'

    def __getattr__(self, item):
        self._ensure_attrs_resolved()

        try:
            return self._attrs[item]
        except KeyError:
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{item}'")

    def _ensure_attrs_resolved(self):
        if not self._attrs_resolved:
            self.get_attrs()
            self._attrs_resolved = True

    def get_attr_names(self):
        return []

    def get_attrs(self):
        normalize_name = self._normalize_name_func
        ignore_attr_value = self._ignore_attr_value

        # noinspection PyProtectedMember
        for name in self.get_attr_names():
            get_attr_func = self._get_attr_map.get(name, getattr)
            value = get_attr_func(self.object, name)

            if value == ignore_attr_value:
                continue

            if normalize_name is not None:
                name = normalize_name(name)

            self._attrs[name] = value

    def keys(self):
        self._ensure_attrs_resolved()
        return self._attrs.keys()

    def values(self):
        self._ensure_attrs_resolved()
        return self._attrs.values()

    def items(self):
        self._ensure_attrs_resolved()
        return self._attrs.items()

    def get(self, key, default=None):
        return self._attrs.get(key, default)


class TableView:
    def __init__(self, generator=None):
        self._generator = generator

    def __str__(self):
        table = PrettyTable(title=self.__class__.__name__)
        field_names = None

        for obj in self:

            if field_names is None:
                table.field_names = field_names = self.get_field_names(obj)

            row = self.get_table_row(obj)
            table.add_row(row)

        return str(table)

    def __iter__(self):
        gen = self._generator if self._generator is not None else self.iter_objects()

        for obj in gen:
            yield obj

    def __call__(self, *, case_insensitive=True, sub_string=True, **attrs):
        if not attrs:
            return self

        gen = iter_find_by_attrs(iter(self), case_insensitive=case_insensitive,
                                 sub_string=sub_string, attrs=attrs)
        return self.__class__(gen)

    def get_field_names(self, obj):
        return []

    def get_table_row(self, obj):
        return []

    def iter_objects(self):
        pass


class MacAddress:
    __slots__ = ('_raw',)

    @classmethod
    def from_iterable(cls, iterable, length=None):
        if length is None:
            length = len(iterable)

        if length != MAC_ADDR_BYTES_LEN:
            raise ValueError(f'MAC address must have {MAC_ADDR_BYTES_LEN} bytes.')

        return cls(bytes(iterable[:MAC_ADDR_BYTES_LEN]))

    @classmethod
    def from_string(cls, string, sep=':'):
        octets = string.split(sep)

        if len(octets) != MAC_ADDR_BYTES_LEN:
            raise ValueError(f'MAC address must have {MAC_ADDR_BYTES_LEN} bytes.')

        return cls(bytes(int(o, 16) for o in octets))

    def __init__(self, raw):
        self._raw = raw

    def __repr__(self):
        return f'{self.__class__.__name__}({self._raw})'

    def __str__(self):
        return f"{':'.join(format(b, '02x') for b in self._raw)}"

    def __len__(self):
        return MAC_ADDR_BYTES_LEN

    def __hash__(self):
        return hash(str(self))

    def __eq__(self, other):
        if isinstance(other, (str, MacAddress)):
            return hash(self) == hash(other)

        if not isinstance(other, Iterable):
            return False

        fill = object()
        return all(a == b for a, b in zip_longest(self._raw, other, fillvalue=fill))

    def __iter__(self):
        for b in self._raw:
            yield b

    def __getitem__(self, item):
        return self._raw[item]

    def to_string(self):
        return str(self)

    def to_bytes(self):
        return bytes(self._raw)
