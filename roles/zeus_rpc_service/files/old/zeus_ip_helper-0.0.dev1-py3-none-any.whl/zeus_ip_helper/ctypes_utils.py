# ctypes_utils.py
# noinspection PyProtectedMember
from ctypes import _SimpleCData
from typing import Type
from .utils import SingletonMeta


__all__ = ['c_array_from_buffer']


class CArrayFactory(metaclass=SingletonMeta):
    def __init__(self):
        self._proto_cache = {}

    def __call__(self, ctype: Type[_SimpleCData], buffer: bytearray):
        self._proto_cache.setdefault(ctype, {})
        buf_len = len(buffer)
        proto = self._proto_cache[ctype].get(buf_len)

        if proto is None:
            # noinspection PyTypeChecker
            self._proto_cache[ctype][buf_len] = proto = (ctype * buf_len)

        return proto.from_buffer(buffer)


c_array_from_buffer = CArrayFactory()

