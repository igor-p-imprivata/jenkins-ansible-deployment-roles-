# exceptions


class ZeusIpHelperError(OSError):
    pass


class PingError(ZeusIpHelperError):
    pass
