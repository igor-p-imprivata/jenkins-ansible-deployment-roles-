# api.py
import platform
from typing import Union


OS_NAME = platform.system()

if OS_NAME == 'Windows':
    from .win32 import Ping

elif OS_NAME == 'Linux':
    raise NotImplementedError()

else:
    raise RuntimeError(f'{OS_NAME} not supported')


DEFAULT_COUNT = 4
DEFAULT_SIZE = 32
DEFAULT_TIMEOUT = 4


def ping(host: str,
         count: int = DEFAULT_COUNT,
         size: int = DEFAULT_SIZE,
         timeout: Union[int, float] = DEFAULT_TIMEOUT) -> Ping:
    """

    :param host:
    :param count:
    :param size:
    :param timeout:
    :return:
    """
    p = Ping(host=host, count=count, size=size, timeout=timeout)
    p.send()
    return p
