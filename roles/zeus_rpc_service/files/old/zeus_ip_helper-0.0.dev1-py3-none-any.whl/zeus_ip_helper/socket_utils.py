# socket_utils.py
import socket
import atexit
import struct
import ctypes
from queue import Queue, Empty as queue_Empty
from threading import Thread
from ipaddress import ip_address as ip_addr_factory
from .utils import SingletonMeta


__all__ = ['get_hostname', 'get_numeric_address', 'resolve', 'ip2int', 'int2ip', 'IPAddr']


def ip2int(ip):
    return IPAddr(struct.unpack('L', socket.inet_aton(ip))[0])


def int2ip(addr):
    return socket.inet_ntoa(struct.pack("L", addr))


def get_hostname(ip_address: str) -> str:
    return socket.gethostbyaddr(ip_address)[0]


def get_numeric_address(host, callback=None):
    try:
        result = socket.getaddrinfo(host, None)[0][-1][0]
    except socket.gaierror as exc:
        result = exc

    if callback is not None:
        callback(result)

    return result


class IPAddr(ctypes.Structure):
    """
    https://github.com/rabimba/p2pScrapper/blob/master/BitTorrent-5.2.2/BTL/iptypes.py

    """
    _fields_ = [
        ('S_addr', ctypes.c_ulong)
    ]

    def __str__(self):
        return socket.inet_ntoa(struct.pack('L', self.S_addr))


class NumericAddressResolver(metaclass=SingletonMeta):
    def __init__(self):
        self._unjoined_threads = set()
        atexit.register(self._cleanup)

    def __call__(self, host, timeout):
        result_queue = Queue(maxsize=1)
        callback = result_queue.put_nowait
        t = Thread(target=get_numeric_address, args=(host, callback))
        t.daemon = True
        t.start()

        try:
            result = result_queue.get(timeout=timeout)
        except queue_Empty:
            self._unjoined_threads.add(t)
            return

        if isinstance(result, Exception):
            t.join()
            del t
            raise result

        ip_address = ip_addr_factory(result)
        t.join()
        del t
        return ip_address

    def _cleanup(self):
        for t in self._unjoined_threads:
            t.join()
            del t

        self._unjoined_threads.clear()


resolve = NumericAddressResolver()
