# enums.py
from enum import IntEnum


class TcpState(IntEnum):
    CLOSED = 1
    LISTEN = 2
    SYN_SENT = 3
    SYN_RCVD = 4
    ESTAB = 5
    FIN_WAIT1 = 6
    FIN_WAIT2 = 7
    CLOSE_WAIT = 8
    CLOSING = 9
    LAST_ACK = 10
    TIME_WAIT = 11
    DELETE_TCB = 12


class TcpTableClass(IntEnum):
    BASIC_LISTENER = 0
    BASIC_CONNECTIONS = 1
    BASIC_ALL = 2
    OWNER_PID_LISTENER = 3
    OWNER_PID_CONNECTIONS = 4
    OWNER_PID_ALL = 5
    OWNER_MODULE_LISTENER = 6
    OWNER_MODULE_CONNECTIONS = 7
    OWNER_MODULE_ALL = 8


class UdpTableClass(IntEnum):
    BASIC = 0
    OWNER_PID = 1
    OWNER_MODULE = 2


class IpNetTableTypes(IntEnum):
    STATIC = 4
    DYNAMIC = 3
    WRONG = 2
    OTHER = 1
