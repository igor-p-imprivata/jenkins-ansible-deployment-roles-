# base.py
import abc
from typing import Union, Type
from ipaddress import IPv4Address, IPv6Address
from .exceptions import PingError


class IcmpPacketBase(metaclass=abc.ABCMeta):
    __slots__ = ('destination', 'request_data', 'response_data', 'timeout_ms', 'exc_args', '_reply')

    def __init__(self,
                 destination: Union[IPv4Address, IPv6Address],
                 request_size: int,
                 timeout_ms: int):
        self.destination = destination
        self.request_data = bytearray(request_size)
        self.response_data = None
        self.timeout_ms = timeout_ms
        self.exc_args = None
        self._reply = None

    def __str__(self):
        if self.timed_out:
            return 'Request timed out.'

        ms = self.round_trip_time_ms
        time_str = f'<1' if ms == 0 else f'={ms}'
        n_bytes = len(self.request_data)
        addr = str(self.destination)
        return f'Reply from {addr}: bytes={n_bytes} time{time_str}ms TTL={self.ttl}'

    @property
    @abc.abstractmethod
    def round_trip_time_ms(self):
        raise NotImplemented

    @property
    @abc.abstractmethod
    def remote_hostname(self):
        raise NotImplemented

    @property
    @abc.abstractmethod
    def remote_ip_address(self):
        raise NotImplemented

    @property
    @abc.abstractmethod
    def ttl(self):
        raise NotImplemented

    @property
    @abc.abstractmethod
    def tos(self):
        raise NotImplemented

    @property
    @abc.abstractmethod
    def timed_out(self):
        raise NotImplemented

    @abc.abstractmethod
    def send(self):
        raise NotImplemented


class PingBase(metaclass=abc.ABCMeta):
    def __init__(self, packet_type: Type[IcmpPacketBase], host: str, count: int, size: int,
                 timeout: Union[int, float]):
        self.packet_type = packet_type
        self.host = host
        self.count = count
        self.size = size
        self.timeout = timeout
        self.packets = []
        self._destination = None
        self._ok = None
        self._exc_args = None
        self._sent = False

    def __str__(self):
        self._ensure_sent()

        if self.getaddrinfo_failed:
            return f'Ping request could not find host {self.host}. Please check the name and try again.'

        lines = []

        if self.host == str(self._destination):
            dest_str = str(self._destination)

        else:
            dest_str = f'{self.host} [{str(self._destination)}]'

        lines.append(f'Pinging {dest_str} with {self.size} bytes of data:')
        lines.extend(str(p) for p in self.packets)
        lines.append('\r')
        lines.append(f'Ping statistics for {str(self._destination)}:')
        sent = len(self.packets)
        received = sum(0 if p.exc_args else 1 for p in self.packets)
        lost = sent - received
        percentage = int((lost / sent) * 100)
        lines.append(f'\tPackets: Sent = {sent}, Received = {received}, Lost = {lost} ({percentage}% loss),')

        measurable_packets = [p for p in self.packets if not p.timed_out]

        if measurable_packets:
            lines.append('Approximate round trip times in milli-seconds:')
            minimum = self.min_round_trip_ms
            maximum = self.max_round_trip_ms
            avg = self.average_round_trip_ms
            lines.append(f'\tMinimum = {minimum}ms, Maximum = {maximum}ms, Average = {avg}ms')

        return '\n'.join(lines)

    def __iter__(self):
        self._ensure_sent()

        for packet in self.packets:
            yield packet

    def __bool__(self):
        return self.ok

    def __len__(self):
        self._ensure_sent()
        return len(self.packets)

    def __getitem__(self, item):
        self._ensure_sent()
        return self.packets[item]

    @property
    def ok(self) -> bool:
        self._ensure_sent()

        if self._ok is None:
            try:
                self.raise_for_status()
            except PingError:
                self._ok = False
            else:
                self._ok = len(self.packets) >= 1

        return self._ok

    @property
    def remote_hostname(self):
        if not self.ok:
            return ()

        hostnames = {p.remote_hostname for p in self.packets}
        assert len(hostnames) == 1
        return hostnames.pop()

    @property
    def remote_ip_address(self):
        if not self.ok:
            return ()

        ip_addresses = {p.remote_ip_address for p in self.packets}
        assert len(ip_addresses) == 1
        return ip_addresses.pop()

    @property
    def average_round_trip_ms(self):
        self._ensure_sent()
        return int(sum(p.round_trip_time_ms for p in self.packets) / len(self.packets))

    @property
    def max_round_trip_ms(self):
        self._ensure_sent()
        return max(p.round_trip_time_ms for p in self.packets)

    @property
    def min_round_trip_ms(self):
        self._ensure_sent()
        return min(p.round_trip_time_ms for p in self.packets)

    @property
    @abc.abstractmethod
    def getaddrinfo_failed(self):
        raise NotImplemented

    @abc.abstractmethod
    def resolve_destination(self):
        raise NotImplemented

    def raise_for_status(self):
        self._ensure_sent()

        if self._exc_args:
            raise PingError(*self._exc_args)

        for packet in self.packets:
            if packet.exc_args:
                raise PingError(*packet.exc_args)

    def send(self):
        if not self._sent:
            try:
                # ICMP lies below the concept of ports/services in the network stack
                if '://' in self.host:
                    self.host = self.host.split('://')[-1]

                self._destination = dest = self.resolve_destination()

                if dest is None:
                    return

                timeout_ms = int(self.timeout * 1000)

                for _ in range(self.count):
                    packet = self.packet_type(dest, self.size, timeout_ms)
                    packet.send()
                    self.packets.append(packet)

            finally:
                self._sent = True

    _ensure_sent = send
