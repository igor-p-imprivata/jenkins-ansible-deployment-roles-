# core.py
import os
import io
import time
import logging
import warnings
import zipfile
import importlib.util
import pickle
import marshal
import tempfile
import shutil
import subprocess as sp
from struct import calcsize
from collections import deque
from contextlib import contextmanager
# from collections import Callable
# noinspection PyProtectedMember
from ctypes import _SimpleCData
from typing import Type, Callable, Any
from types import FunctionType
from functools import reduce, partial, wraps
from operator import ior
from string import Formatter


try:
    from logging import NullHandler
except ImportError:
    class NullHandler(logging.Handler):
        def emit(self, record):
            pass


LOG_MSG_FMT = '[%(asctime)s][%(levelname)s]: %(message)s'
LOG_TIMESTAMP_FMT = '%m/%d/%y %H:%M:%S'


ior_iterable = partial(reduce, ior)

# noinspection PyProtectedMember
_logging_name_to_level = logging._nameToLevel

_default_formatter = Formatter()


def get_format_field_names(fmt_str, formatter=None):
    formatter = formatter or _default_formatter
    return [name for _, name, _, _ in formatter.parse(fmt_str) if name is not None]


def suppress_warnings():
    warnings.simplefilter('ignore')


def config_logging(level, log_file=None, console=True, capture_warnings=False, add_null_handler=True,
                   **third_party_logs):
    orig_level_str = None
    upper_level_str = None

    try:
        upper_level_str = level.upper()
    except AttributeError:
        if not isinstance(level, int):
            raise TypeError('Invalid level type: {}'.format(type(level)))

    else:
        orig_level_str = level

    if orig_level_str is not None:
        try:
            # noinspection PyProtectedMember
            log_level = _logging_name_to_level[upper_level_str]
        except KeyError:
            # noinspection PyProtectedMember
            log_level = _logging_name_to_level[orig_level_str]

    else:
        log_level = level

    formatter = logging.Formatter(LOG_MSG_FMT, LOG_TIMESTAMP_FMT)
    logging.root.setLevel(log_level)

    if capture_warnings:
        logging.captureWarnings(True)

    else:
        logging.captureWarnings(False)
        suppress_warnings()

    handlers = []

    if console:
        handlers.append(logging.StreamHandler())

    if log_file:
        handlers.append(logging.FileHandler(log_file))

    if add_null_handler:
        handlers.append(NullHandler())

    for handler in handlers:
        handler.setLevel(log_level)
        handler.setFormatter(formatter)
        logging.root.addHandler(handler)

    third_party_logs.setdefault('requests', 'warning')
    third_party_logs.setdefault('urllib3', 'warning')
    third_party_logs.setdefault('aiohttp', 'critical')

    for package_name, log_level_name in list(third_party_logs.items()):
        _logger = logging.getLogger(package_name)
        log_level = getattr(logging, log_level_name.upper())
        _logger.setLevel(log_level)


def arg2str(arg):
    return f'"{arg}"' if isinstance(arg, str) else str(arg)


def args2str(*args, sep=', '):
    return sep.join(arg2str(arg) for arg in args)


def kwargs2str(sep=', ', fmt='{}={}', **kwargs):
    return sep.join(fmt.format(k, arg2str(v)) for k, v in kwargs.items())


def params2str(*args, sep=', ', fmt='{}={}', **kwargs):
    return f'{args2str(*args)}{kwargs2str(sep=sep, fmt=fmt, **kwargs)}'


def cmp_attrs(obj: Any, attrs: dict, case_insensitive: bool, sub_string: bool,
              has_attr_func: Callable[[Any, str], bool] = hasattr,
              get_attr_func: Callable[[Any, str], Any] = getattr):

    for key, value in attrs.items():
        if not has_attr_func(obj, key):
            return 0

        obj_attr_value = get_attr_func(obj, key)

        # str
        if isinstance(value, str) and isinstance(obj_attr_value, str):
            if case_insensitive:
                value = value.lower()
                obj_attr_value = obj_attr_value.lower()

            if not (sub_string and value in obj_attr_value) and not obj_attr_value == value:
                return 0

        # int
        elif isinstance(value, int):
            if int(value) != int(obj_attr_value):
                return 0

        # func/callable
        elif isinstance(value, Callable) and not isinstance(value, type):
            if not value(obj_attr_value):
                return 0

        # re.match
        elif hasattr(value, 'match'):
            if not value.match(obj_attr_value):
                return 0

        # identity
        else:
            if value is not obj_attr_value:
                return 0

    return 1


def findall_by_attrs(objects, case_insensitive, sub_string, attrs, has_attr_func=hasattr,
                     get_attr_func=getattr):
    results = []

    for obj in objects:
        is_match = cmp_attrs(obj,
                             attrs=attrs,
                             case_insensitive=case_insensitive,
                             sub_string=sub_string,
                             has_attr_func=has_attr_func,
                             get_attr_func=get_attr_func)

        if is_match:
            results.append(obj)

    return results


def find_by_attrs(objects, case_insensitive, sub_string, attrs, has_attr_func=hasattr,
                  get_attr_func=getattr):
    for obj in objects:
        is_match = cmp_attrs(obj,
                             attrs=attrs,
                             case_insensitive=case_insensitive,
                             sub_string=sub_string,
                             has_attr_func=has_attr_func,
                             get_attr_func=get_attr_func)

        if is_match:
            return obj

    else:
        return None


def find_by_attrs_multi_source(sources, case_insensitive, sub_string, attrs, has_attr_func=hasattr,
                               get_attr_func=getattr):

    for objects in sources:
        result = find_by_attrs(
            objects=objects,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attrs,
            has_attr_func=has_attr_func,
            get_attr_func=get_attr_func
        )

        if result is not None:
            return result


def findall_by_attrs_multi_source(sources, case_insensitive, sub_string, attrs, has_attr_func=hasattr,
                                  get_attr_func=getattr):
    all_results = []

    for objects in sources:
        results = findall_by_attrs(
            objects=objects,
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attrs,
            has_attr_func=has_attr_func,
            get_attr_func=get_attr_func
        )
        all_results.extend(results)

    return all_results


def exhaust_iterator(iterator):
    deque(iterator, maxlen=0)


def iter_c_string_array(string_array, delimiter=b'\x00'):
    yield from filter(None, string_array[:len(string_array)].split(delimiter))


def get_package_from_site_packages(package_name):
    python_dir = os.path.dirname(get_default_python_exe())
    site_packages_dir = os.path.join(python_dir, 'Lib\\site-packages')
    package_root = os.path.join(site_packages_dir, package_name)

    if not os.path.exists(package_root):
        raise ValueError(f'{package_name} does not exist in {site_packages_dir}')

    return package_root


def build_installed_package(package_name, version_tuple, package_root=None, use_wheel=True,
                            artifact_output_dir=None, python_exe=None, **setup_kwargs):
    package_root = package_root or get_package_from_site_packages(package_name)
    repackager = Repackager(
        package_name=package_name,
        version_tuple=version_tuple,
        package_root=package_root,
        use_wheel=use_wheel,
        artifact_output_dir=artifact_output_dir,
        python_exe=python_exe,
        **setup_kwargs
    )
    return repackager.build()


@contextmanager
def resource_wrapper(resource_opener, resource_closer):
    resource = resource_opener()

    try:
        yield resource
    finally:
        resource_closer(resource)


def split_path(path):
    parts = []
    head = path

    while True:
        head, tail = os.path.split(head)

        if head == '/' or not tail:

            if tail:
                parts.append(tail)

            if head and head != '/':
                parts.append(head)

            parts.reverse()
            return parts

        parts.append(tail)


def import_module_from_file(import_name, file_path):
    spec = importlib.util.spec_from_file_location(import_name, file_path)
    module_ = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module_)
    return module_


def iter_find_files(root, matcher, match_full_path=False):
    if hasattr(matcher, 'match'):
        matcher = matcher.match

    for path, sub_dirs, files in os.walk(root):

        for file_ in files:
            if match_full_path:
                file_ = os.path.join(path, file_)

            if matcher(file_):
                yield file_ if match_full_path else os.path.join(path, file_)


def zip_to_bytes(file_path, compression=zipfile.ZIP_DEFLATED):
    zip_buffer = io.BytesIO()
    file_name = os.path.basename(file_path)

    with open(file_path, 'rb') as f:
        with zipfile.ZipFile(zip_buffer, 'w', compression, allowZip64=False) as zf:
            zf.writestr(file_name, f.read())

        return zip_buffer.getvalue()


def unzip_from_bytes(extract_dir, data, compression=zipfile.ZIP_DEFLATED):
    zip_buffer = io.BytesIO(data)

    with zipfile.ZipFile(zip_buffer, 'r', compression, allowZip64=False) as zf:
        zf.extractall(path=extract_dir)
        info_list = zf.infolist()

    return [os.path.abspath(os.path.join(extract_dir, zi.filename)) for zi in info_list]


def wheel_metadata_to_dict(wheel_path):
    md_dict = {}

    with zipfile.ZipFile(wheel_path) as zf:
        for file_name in zf.namelist():
            if file_name.endswith('METADATA'):
                metadata = zf.open(file_name).read().decode('utf-8', 'strict')
                break
        else:
            raise RuntimeError('Unable to find METADATA file')

    for line in metadata.splitlines():
        line = line.strip()

        if not line or ':' not in line:
            continue

        key, value = tuple(part.strip() for part in line.split(':', 1))

        if key in md_dict:

            if not isinstance(md_dict[key], list):
                existing_value = md_dict.pop(key)
                md_dict[key] = [existing_value]

            md_dict[key].append(value)

        else:
            md_dict[key] = value

    return md_dict


def get_default_python_exe():
    """
    Get the path of the default Python executable based on the location of
    the file the os module is loaded from. This is used instead of
    sys.executable to determine the python.exe path when running from a
    Windows service, which reports the executable as pythonservice.exe.

    :return:
    """
    os_file = os.__file__
    py_root_dir = os_file.split(r'\lib')[0]
    return os.path.join(py_root_dir, 'python.exe')


def get_python_bitness():
    return calcsize('P') * 8


class SingletonMeta(type):
    _ = {}

    def __call__(cls, *args, **kwargs):
        instance = SingletonMeta._.get(cls)

        if instance is None:
            SingletonMeta._[cls] = instance = super(SingletonMeta, cls).__call__(*args, **kwargs)

        return instance


# noinspection PyMissingConstructor
class KeyTransformDict(dict):
    @classmethod
    def from_keys(cls, key_transform, target):
        dict_ = dict.fromkeys(key_transform, target.keys())
        return cls(dict_)

    def __init__(self, key_transform, *args, **kwargs):
        self._key_transform = key_transform
        self._real_key_map = {}
        self.update(*args, **kwargs)

    def __str__(self):
        return str({self._real_key_map[k]: v for k, v in dict.items(self)})

    def __repr__(self):
        return str(self)

    def __setitem__(self, key, value):
        new_key = self._key_transform(key)
        self._real_key_map[new_key] = key
        dict.__setitem__(self, new_key, value)

    def __getitem__(self, item):
        return dict.__getitem__(self, self._key_transform(item))

    def __delitem__(self, key):
        dict.__delitem__(self, self._key_transform(key))

    def __contains__(self, item):
        return dict.__contains__(self, self._key_transform(item))

    def keys(self):
        return (self._real_key_map[key] for key in dict.keys(self))

    def items(self):
        return ((self._real_key_map[k], v) for k, v in dict.items(self))

    def get(self, key, default=None):
        return dict.get(self, self._key_transform(key), default)

    def pop(self, key, default=None):
        return dict.pop(self, self._key_transform(key), default)

    def copy(self):
        new_copy = self.__class__()
        new_copy.update({self._real_key_map[k]: v for k, v in dict.items(self)})
        return new_copy

    def setdefault(self, key, default=None):
        new_key = self._key_transform(key)
        self._real_key_map[new_key] = key
        dict.setdefault(new_key, default)

    def clear(self):
        self._real_key_map.clear()
        dict.clear(self)

    def to_dict(self):
        return dict(self.items())

    def update(self, *args, **kwargs):
        for key, value in dict(*args, **kwargs).items():
            self.__setitem__(key, value)

    def maps_to(self, key):
        new_key = self._key_transform(key)
        return self._real_key_map.get(new_key)


class CArrayFactory(metaclass=SingletonMeta):
    def __init__(self):
        self._proto_cache = {}

    def __call__(self, ctype: Type[_SimpleCData], buffer: bytearray):
        self._proto_cache.setdefault(ctype, {})
        buf_len = len(buffer)
        proto = self._proto_cache[ctype].get(buf_len)

        if proto is None:
            # noinspection PyTypeChecker
            self._proto_cache[ctype][buf_len] = proto = (ctype * buf_len)

        return proto.from_buffer(buffer)


c_array_from_buffer = CArrayFactory()


class CallableSerializer:
    def __init__(self, callable_):
        if not isinstance(callable_, Callable):
            raise TypeError(f'{self.__class__.__name__} only accepts callable objects')

        self.callable = callable_

    def __getstate__(self):
        return {
            'marshaled_bytecode': marshal.dumps(self.callable.__code__),
            'pickled_name': pickle.dumps(self.callable.__name__),
            'pickled_arguments': pickle.dumps(self.callable.__defaults__),
            'pickled_closure': pickle.dumps(self.callable.__closure__)
        }

    def __setstate__(self, state):
        bytecode = marshal.loads(state['marshaled_bytecode'])
        name = pickle.loads(state['pickled_name'])
        arguments = pickle.loads(state['pickled_arguments'])
        closure = pickle.loads(state['pickled_closure'])
        self.callable = FunctionType(bytecode, globals(), name, arguments, closure)


class DefinitionReader:
    def __init__(self, root_directory):
        self.root_directory = root_directory
        self.lines = None
        self._value_cache = {}

    def __str__(self):
        self.ensure_read()
        return '\n'.join(self.lines)

    def __iter__(self):
        self.ensure_read()

        for line in self.lines:
            yield line

    def ensure_read(self):
        if self.lines is None:
            self.lines = []

            def matcher(file_path):
                path_parts = split_path(file_path)
                file_name = path_parts.pop()
                directories = set(path_parts)

                if 'build' in directories:
                    return False

                return file_name == 'definitions.py'

            it = iter_find_files(self.root_directory, matcher=matcher, match_full_path=True)
            module_path = next(f for f in it)

            with open(module_path, 'r') as f:
                for line in f.readlines():
                    line = line.strip()

                    if not line:
                        continue

                    self.lines.append(line)

    def get_value(self, name, converter=None):
        value = self._value_cache.get(name)

        if value is None:
            self.ensure_read()

            for line in self.lines:

                if line.startswith(name):
                    value = line.split('=')[-1].strip()

                    if converter is not None:
                        value = converter(value)

                    self._value_cache[name] = value
                    break

            else:
                raise ValueError(f'Unable to find "{name}"')

        return value


class Repackager:
    DEFAULT_LICENSE = 'MIT'
    DEFAULT_PLATFORMS = ['win32']
    DEFAULT_CLASSIFIERS = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3.6'
    ]

    SETUP_FMT = """from setuptools import setup{use_find_packages}

setup(
    name={name},
    version_info={version_info},
    version={version},
    description={description},
    author={author},
    author_email={author_email},
    license={license},
    platforms={platforms},
    classifiers={classifiers},
    packages={packages},
    install_requires={install_requires},
)
"""

    def __init__(self, package_name, version_tuple, package_root, version_string=None,
                 install_requires=None, license_=None, description=None, author=None,
                 author_email=None, platforms=None, classifiers=None, packages=None,
                 use_wheel=True, artifact_output_dir=None, python_exe=None):
        self.package_root = package_root
        version_string = version_string or '.'.join(str(i) for i in version_tuple)

        self.setup_fmt_kwargs = dict(
            use_find_packages=', find_packages' if packages is None else '',
            name=f"'{package_name}'",
            version_info=version_tuple,
            version=f"'{version_string}'",
            description=description or "''",
            author=author or "''",
            author_email=author_email or "''",
            license=f"'{license_ or self.DEFAULT_LICENSE}'",
            platforms=platforms or self.DEFAULT_PLATFORMS,
            classifiers=classifiers or self.DEFAULT_CLASSIFIERS,
            packages=packages or 'find_packages()',
            install_requires=install_requires or []
        )
        self.use_wheel = use_wheel
        self.artifact_output_dir = artifact_output_dir or ''
        self.python_exe = python_exe or get_default_python_exe()
        self.tmp_dir = None

    def raise_for_valid_package(self):
        if not os.path.exists(self.package_root):
            raise NotADirectoryError(f'{self.package_root} does not exist')

        if '__init__.py' not in set(os.listdir(self.package_root)):
            raise RuntimeError(f'{self.package_root} is not a valid package')

    def copy_package(self):
        package_dir_name = os.path.basename(self.package_root)
        dst = os.path.join(self.tmp_dir, package_dir_name)
        shutil.copytree(self.package_root, dst)

    def create_setup_file(self):
        fmt_kwargs = {k: str(v) for k, v in self.setup_fmt_kwargs.items()}
        setup_text = self.SETUP_FMT.format(**fmt_kwargs)

        with open(os.path.join(self.tmp_dir, 'setup.py'), 'w') as f:
            f.write(setup_text)

    def run_setup(self):
        wheel_arg = ' bdist_wheel' if self.use_wheel else ''
        cmd_line = f'"{self.python_exe}" setup.py sdist{wheel_arg}'
        proc = sp.run(cmd_line, stdout=sp.PIPE, stderr=sp.PIPE, cwd=self.tmp_dir)

        try:
            proc.check_returncode()
        except sp.CalledProcessError:
            raise RuntimeError(f'Error running command: {cmd_line}, stderr: {proc.stderr}, stdout: {proc.stdout}')

        return proc.stdout

    def copy_artifact(self):
        dist_dir = os.path.join(self.tmp_dir, 'dist')

        if self.use_wheel:
            def _matcher(file_name):
                return file_name.endswith('.whl')

        else:
            def _matcher(file_name):
                return file_name.endswith('.gz')

        dist_binary = next(iter_find_files(dist_dir, _matcher))

        if dist_binary is None:
            raise RuntimeError(f'No binary file found in {dist_dir}')

        dist_file_name = os.path.basename(dist_binary)
        output_path = os.path.join(self.artifact_output_dir, dist_file_name)
        shutil.copyfile(dist_binary, output_path)
        return output_path

    def build(self):
        self.raise_for_valid_package()
        self.tmp_dir = tempfile.mkdtemp()

        try:
            self.copy_package()
            self.create_setup_file()
            self.run_setup()
            return self.copy_artifact()
        finally:
            shutil.rmtree(self.tmp_dir, ignore_errors=True)


class SimpleTimer:
    def __init__(self, time_func=time.perf_counter):
        self._time_func = time_func
        self._results = {}

    def __call__(self, func):
        time_func = self._time_func
        results = self._results

        @wraps(func)
        def _inner(*args, **kwargs):
            start = time_func()
            ret = func(*args, **kwargs)
            results[func.__name__] = time_func() - start
            return ret

        return _inner

    def get_result(self, func):
        if isinstance(func, str):
            key = func

        elif hasattr(func, '__name__'):
            key = func.__name__

        else:
            raise ValueError(f'Invalid result key: {func}')

        return self._results.get(key)
