# remote_service_impl.py
import zipfile
from subprocess import CompletedProcess
from zeus_utils import zip_to_bytes
from zeus_win32_utils import WConnectFlags
from zeus_rpc_service.protocol import RpcRemoteObjectProxy
from zeus_rpc_service.remote_services import remote_service_registry, RemoteService
from zeus_rpc_service.definitions import (
    SVC_NAME_SYSTEM, SVC_NAME_DRIVES, SVC_NAME_FILES, SVC_NAME_CMD,
    SVC_NAME_USERS, SVC_NAME_PROCESSES, SVC_NAME_MSI, SVC_NAME_REGISTRY, SVC_NAME_SESSIONS,
    SVC_NAME_PACKAGES, SVC_NAME_CODE_IMPORTER
)


# class RootService(RemoteService):
#     _name_ = SVC_NAME_ROOT
#
#     def ping(self):
#         return self.rpc_request.ping()
#
#     def get_service_names(self):
#         return self.rpc_request.get_service_names()
#
#     def create_session(self):
#         return self.rpc_request.create_session()
#
#     def clear_session(self, session_uuid):
#         self.rpc_request.clear_session(session_uuid=session_uuid)
#
#     def get_session_count(self):
#         return self.rpc_request.get_session_count()
#
#     def shutdown_server(self):
#         self.rpc_request.shutdown()
#
#     def create_session_context(self, context_request=None, *, src_uuid=None, keyword_mapping=None):
#         return self.rpc_request.create_session_context(
#             context_request=context_request,
#             src_uuid=src_uuid,
#             keyword_mapping=keyword_mapping
#         )
#
#     def clear_session_context(self, context_uuid, session_uuid=None):
#         session_uuid = session_uuid or self.session_uuid
#         return self.rpc_request.clear_session_context(
#             session_uuid=session_uuid,
#             context_uuid=context_uuid
#         )
#
#     def add_service(self, service_name=None, import_path=None, call_service_import=False,
#                     service_args=None, service_kwargs=None, context_uuid=None):
#
#         if context_uuid is None:
#             if service_name is None:
#                 raise ValueError(f'service_name must be specified')
#
#             if import_path is None:
#                 raise ValueError(f'import_path must be specified')
#
#             context_request = self.create_context_request()
#
#             context_request.add_item_request(
#                 key='name',
#                 value=service_name,
#                 evaluated=True
#             )
#
#             context_request.add_item_request(
#                 key='service',
#                 import_path=import_path,
#                 call_import=call_service_import,
#                 call_args=service_args,
#                 call_kwargs=service_kwargs,
#                 evaluated=False
#             )
#
#             context_uuid = self.create_session_context(context_request)
#
#         with self.session_context(context_uuid):
#             return self.rpc_request.add_service()
#
#     def remove_service(self, name):
#         return self.rpc_request.remove_service(name=name)
#
#     def add_ext_request_handler(self, name=None, import_path=None, context_uuid=None,
#                                 **handler_kwargs):
#
#         if context_uuid is None:
#             if name is None:
#                 raise ValueError(f'name must be specified')
#
#             if import_path is None:
#                 raise ValueError(f'import_path must be specified')
#
#             context_request = self.create_context_request()
#
#             context_request.add_item_request(
#                 key='name',
#                 value=name,
#                 evaluated=True
#             )
#
#             context_request.add_item_request(
#                 key='ext_handler',
#                 import_path=import_path,
#                 call_import=True,
#                 call_kwargs=dict(name=name, **handler_kwargs),
#                 evaluated=False
#             )
#
#             context_uuid = self.create_session_context(context_request)
#
#         with self.session_context(context_uuid):
#             return self.rpc_request.add_ext_request_handler()
#
#     def remove_ext_request_handler(self, name):
#         return self.rpc_request.remove_ext_request_handler(name=name)
#
#     def spawn_rpc_server(self, session_id, port, python_exe=None, default_directory=None,
#                          timeout=None, **kwargs):
#         return self.rpc_request.spawn_rpc_server(
#             session_id=session_id,
#             port=port,
#             python_exe=python_exe,
#             default_directory=default_directory,
#             timeout=timeout,
#             **kwargs
#         )



