# sessions.py
import pywintypes
import win32ts
import ctypes
from ctypes import wintypes
from zeus_utils import find_by_attrs, findall_by_attrs, SingletonMeta
from zeus_win32_utils import (
    dirty_cast, get_user_sid, get_session_token, WTSConnectionState, SessionInfoClass,
    SESSION_INFO_NOT_USED, WTS_CLIENT_DISPLAY
)
from .users import User


WTS_CURRENT_SERVER_HANDLE = wintypes.HANDLE(0)
WTS_CURRENT_SESSION = wintypes.DWORD(-1)

# WTSAPI32.DLL

wtsapi32 = ctypes.windll.Wtsapi32

WTSQuerySessionInformation = wtsapi32.WTSQuerySessionInformationA
WTSQuerySessionInformation.argtypes = (wintypes.HANDLE, wintypes.DWORD, ctypes.c_int,
                                       ctypes.POINTER(wintypes.LPSTR),
                                       ctypes.POINTER(wintypes.DWORD))
WTSQuerySessionInformation.restype = wintypes.BOOL

WTSFreeMemory = wtsapi32.WTSFreeMemory
WTSFreeMemory.argtypes = (wintypes.LPVOID,)


def convert_session_info(info_class, res, string_ptr):
    ret_val = None

    if info_class is SessionInfoClass.IS_REMOTE_SESSION:
        ret_val = bool(res)

    elif info_class is SessionInfoClass.CLIENT_PROTOCOL_TYPE:
        ret_val = dirty_cast(string_ptr, wintypes.USHORT).value

    elif info_class is SessionInfoClass.CLIENT_PRODUCT_ID:
        ret_val = dirty_cast(string_ptr, wintypes.USHORT).value

    elif info_class is SessionInfoClass.SESSION_ID:
        ret_val = dirty_cast(string_ptr, wintypes.ULONG).value

    elif info_class is SessionInfoClass.CLIENT_DISPLAY:
        wcd = dirty_cast(string_ptr, WTS_CLIENT_DISPLAY)
        ret_val = wcd.HorizontalResolution, wcd.VerticalResolution, wcd.ColorDepth

    else:
        ptr_val = string_ptr.value

        if ptr_val is not None:
            ret_val = ptr_val.decode('utf-8', 'strict')

    return ret_val


def query_session_information(info_class, session_id=WTS_CURRENT_SESSION,
                              server=WTS_CURRENT_SERVER_HANDLE):
    if info_class not in SessionInfoClass:
        info_class = SessionInfoClass(info_class)

    if info_class in SESSION_INFO_NOT_USED:
        return None

    ptr = ctypes.c_char_p()
    bytes_returned = wintypes.DWORD(0)

    res = WTSQuerySessionInformation(
        server,
        session_id,
        info_class.value,
        ctypes.byref(ptr),
        ctypes.byref(bytes_returned)
    )

    try:
        return convert_session_info(info_class, res, ptr)
    finally:
        WTSFreeMemory(ptr)


class Session:
    __slots__ = ('session_id', 'station_name', 'connection_state')

    @classmethod
    def from_session_info(cls, session_info):
        session_id = session_info['SessionId']
        station_name = session_info['WinStationName']
        connection_state = WTSConnectionState(session_info['State'])
        return cls(session_id=session_id, station_name=station_name,
                   connection_state=connection_state)

    def __init__(self, session_id, station_name, connection_state):
        self.session_id = session_id
        self.station_name = station_name
        self.connection_state = connection_state

    def __str__(self):
        return f'{self.__class__.__name__}(session_id={self.session_id}, ' \
               f'station_name="{self.station_name}", ' \
               f'connection_state={self.connection_state.name})'

    @property
    def current_user_sam_name(self):
        return self.get_current_user_attribute('sam_name')

    @property
    def current_user_upn_name(self):
        return self.get_current_user_attribute('upn_name')

    @property
    def current_user_sid_string(self):
        return self.get_user_sid_string()

    @property
    def is_remote(self):
        return self.query(SessionInfoClass.IS_REMOTE_SESSION)

    def get_current_user_attribute(self, name):
        user = self.get_user()

        if user is not None:
            return getattr(user, name)

    def get_user_token(self):
        return win32ts.WTSQueryUserToken(self.session_id)

    def get_user_sid_string(self):
        # noinspection PyUnresolvedReferences
        try:
            token = self.get_user_token()
        except pywintypes.error:
            return None

        return get_user_sid(token)

    def get_user(self):
        sid_string = self.get_user_sid_string()

        if sid_string is not None:
            return User.from_sid(sid_string)

    def get_session_token(self):
        return get_session_token(self.session_id)

    def query(self, info_class):
        return query_session_information(
            info_class=info_class,
            session_id=self.session_id
        )


# noinspection PyMethodMayBeStatic
class SessionManager(metaclass=SingletonMeta):
    def enumerate(self):
        for session_info in win32ts.WTSEnumerateSessions():
            yield Session.from_session_info(session_info)

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(self.enumerate(), case_insensitive=case_insensitive,
                             sub_string=sub_string, attrs=attributes)

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(self.enumerate(), case_insensitive=case_insensitive,
                                sub_string=sub_string, attrs=attributes)

    def get_console_session_id(self):
        return win32ts.WTSGetActiveConsoleSessionId()


session_manager = SessionManager()
