# importer.py
import os
import sys
import logging
import importlib.util as importlib_util
from importlib import invalidate_caches


logger = logging.getLogger(__name__)


def create_module_spec(name, path=None):
    if path is not None:
        return importlib_util.spec_from_file_location(name, path)

    return importlib_util.spec_from_loader(name, loader=None)


def import_module_from_spec(spec, code=None, update_sys_modules=True):
    module_ = importlib_util.module_from_spec(spec)

    if update_sys_modules:
        sys.modules[spec.name] = module_

    if code is not None:
        exec(code, module_.__dict__)

    else:
        spec.loader.exec_module(module_)

    return module_


class PythonCodeImporter:
    def __init__(self):
        self.__modules = {}

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def __contains__(self, item):
        return item in self.__modules or item in sys.modules

    def unload(self, name, raise_if_non_existent=False):
        source_mappings = []

        if name in self.__modules:
            source_mappings.append(self.__modules)

        if name in sys.modules:
            source_mappings.append(sys.modules)

        if source_mappings:

            for source_mapping in source_mappings:
                module_ = source_mapping.pop(name)
                logger.info(f'{repr(self)}: unload -> {repr(module_)}')

                del module_

        elif raise_if_non_existent:
            raise ValueError(f'Module "{name}" is not imported')

    def clear(self):
        for name in list(self.__modules.keys()):
            self.unload(name)

    def import_module(self, name, code=None, path=None):
        if code is None and path is None:
            raise ValueError('Either code or path must be specified')

        invalidate_caches()
        spec = create_module_spec(name, path=path)
        self.__modules[name] = import_module_from_spec(spec, code=code)

    def import_package(self, name, location):
        logger.info(f'{repr(self)}: import_package -> name: "{name}", location: "{location}"')
        init_path = os.path.join(location, f'{name}\\__init__.py')
        self.import_module(name=name, path=init_path)

    def get(self, import_path, default=None):
        top_level_name, *descendant_names = import_path.split('.')
        current_obj = self.__modules.get(top_level_name, sys.modules.get(top_level_name))

        if current_obj is None:
            return default

        for name in descendant_names:
            current_obj = getattr(current_obj, name, None)

            if current_obj is None:
                return default

        return current_obj
