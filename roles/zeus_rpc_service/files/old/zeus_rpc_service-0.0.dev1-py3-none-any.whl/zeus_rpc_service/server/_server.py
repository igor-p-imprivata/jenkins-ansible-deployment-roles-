# _server.py
import sys
import traceback
from xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler, Fault


HTTP_METHOD_NAME_PREFIX = 'do_'


class RpcRequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = {'/', '/RPC2'}

    @classmethod
    def add_rpc_path(cls, path):
        if not path.startswith('/'):
            path = f'/{path}'

        cls.rpc_paths.add(path)

    # def do_GET(self):
    #     # Check that the path is legal
    #     if not self.is_rpc_path_valid():
    #         self.report_404()
    #         return
    #
    #     try:
    #         # Get arguments by reading body of request.
    #         # We read this in chunks to avoid straining
    #         # socket.read(); around the 10 or 15Mb mark, some platforms
    #         # begin to have problems (bug #792570).
    #         max_chunk_size = 10 * 1024 * 1024
    #         size_remaining = int(self.headers["content-length"])
    #         L = []
    #
    #         while size_remaining:
    #             chunk_size = min(size_remaining, max_chunk_size)
    #             chunk = self.rfile.read(chunk_size)
    #             if not chunk:
    #                 break
    #             L.append(chunk)
    #             size_remaining -= len(L[-1])
    #
    #         data = b''.join(L)
    #
    #         data = self.decode_request_content(data)
    #
    #         if data is None:
    #             return  # response has been sent
    #
    #         # In previous versions of SimpleXMLRPCServer, _dispatch
    #         # could be overridden in this class, instead of in
    #         # SimpleXMLRPCDispatcher. To maintain backwards compatibility,
    #         # check to see if a subclass implements _dispatch and dispatch
    #         # using that method if present.
    #         response = self.server._marshaled_dispatch(
    #             data, getattr(self, '_dispatch', None), self.path
    #         )
    #     except Exception as e:  # This should only happen if the module is buggy
    #         # internal error, report as HTTP server error
    #         self.send_response(500)
    #         self.send_header("Content-length", "0")
    #         self.end_headers()
    #     else:
    #         self.send_response(200)
    #
    #         self.send_header("Content-type", "text/xml")
    #
    #         if self.encode_threshold is not None:
    #             if len(response) > self.encode_threshold:
    #                 q = self.accept_encodings().get("gzip", 0)
    #                 if q:
    #                     try:
    #                         response = gzip_encode(response)
    #                         self.send_header("Content-Encoding", "gzip")
    #                     except NotImplementedError:
    #                         pass
    #
    #         self.send_header("Content-length", str(len(response)))
    #         self.end_headers()
    #         self.wfile.write(response)


class BaseRpcServer(SimpleXMLRPCServer):
    def _dispatch(self, method, params):
        try:
            return super(BaseRpcServer, self)._dispatch(method, params)
        except Exception:
            type_, value, tb = sys.exc_info()
            raise Fault(1, ''.join(traceback.format_exception(type_, value, tb)))

    # def _marshaled_dispatch(self, data, dispatch_method=None, path=None):
        # print(f'{self.__class__.__name__}._marshaled_dispatch -> data: {data}, dispatch_method: {dispatch_method}, path: {path}')
        # return super(BaseRpcServer, self)._marshaled_dispatch(data, dispatch_method=dispatch_method, path=path)

