# remote_service_installer.py
import logging
from zeus_utils import build_installed_package, wheel_metadata_to_dict
from zeus_rpc_service.definitions import STATION_NAME_SERVICES, SVC_PORT, SVC_NAME_ROOT
from zeus_rpc_service.client import RpcServiceProxy
from zeus_rpc_service.service_providers.packages import normalize_package_version


logger = logging.getLogger(__name__)


class RemoteServiceInstaller:
    def __init__(self, host, service_name, import_path, port=SVC_PORT, service_args=None,
                 service_kwargs=None, call_service_import=False, package_name=None,
                 package_version=None, package_root=None, package_installer=None,
                 package_build_kwargs=None, module_name=None, module_path=None, module_code=None,
                 ext_request_handler=False, ext_request_name=None,
                 station_name=STATION_NAME_SERVICES, session_index=0):
        self._proxy = RpcServiceProxy(host=host, port=port)

        self.service_name = service_name
        self.call_service_import = call_service_import
        self.service_args = service_args
        self.service_kwargs = service_kwargs

        self.import_path = import_path

        self.package_name = package_name
        self.package_version = package_version
        self.package_root = package_root
        self.package_installer = package_installer
        self.package_build_kwargs = package_build_kwargs or {}

        self.module_name = module_name
        self.module_path = module_path
        self.module_code = module_code

        self.ext_request_handler = ext_request_handler
        self.ext_request_name = ext_request_name

        self.station_name = station_name
        self.session_index = session_index

        self._pkg_meta_data = None
        self._remote_file_path = None
        self._connected = False
        self._ext_handler_ctx_uuid = None
        self._svc_ctx_uuid = None
        self._root_service = None

        self.raise_for_insufficient_info()

    def __repr__(self):
        return f'{self.__class__.__name__}(import_path="{self.import_path}")'

    def _ensure_connected(self):
        if not self._connected:
            self._proxy.connect()
            self._connected = True

    def _get_package_meta_data(self):
        if self.package_installer is not None and self._pkg_meta_data is None:
            if not self.package_installer.endswith('.whl'):
                raise ValueError(f'Unsupported package type: {self.package_installer}')

            self._pkg_meta_data = wheel_metadata_to_dict(self.package_installer)

        return self._pkg_meta_data

    def _get_remote_file_path(self):
        if self._remote_file_path is None:
            target = self.package_installer or self.module_path

            rfile = self._proxy.send_file(
                tag=target,
                src=target,
                station_name=self.station_name,
                index=self.session_index
            )
            self._remote_file_path = rfile.path

        return self._remote_file_path

    def raise_for_insufficient_info(self):
        if self.package_name is not None:
            if self.package_installer is None and self.package_version is None:
                raise ValueError('Either package_installer or package_version must be specified')

        if self.module_name is not None:
            if self.module_path is None and self.module_code is None:
                raise ValueError('Either module_path or module_code must be specified')

        if self.ext_request_handler and self.ext_request_name is None:
            raise ValueError('ext_request_name must be specified')

    def is_service_installed(self):
        self._ensure_connected()

        service_names = self._proxy.get_remote_service_names(
            station_name=self.station_name,
            index=self.session_index
        )
        return self.service_name in set(service_names)

    def get_installed_package(self):
        if self.package_name is not None:
            self._ensure_connected()
            return self._proxy.find_package(name=self.package_name)

    def get_local_package_version(self):
        if self.package_version is None:
            metadata = self._get_package_meta_data()
            return normalize_package_version(metadata['Version'])

        return self.package_version

    def import_module(self):
        self._ensure_connected()

        self._proxy.import_module(
            name=self.module_name,
            code=self.module_code,
            path=self.module_path,
            station_name=self.station_name,
            index=self.session_index
        )

    def uninstall_package(self):
        if not self.get_installed_package():
            return

        self._ensure_connected()

        self._proxy.uninstall_package(
            name=self.package_name,
            remote_source_path=self._get_remote_file_path()
        )

    def uninstall_service(self):
        if not self.is_service_installed():
            return

        self._ensure_connected()

        self._proxy.remove_service(
            service_name=self.service_name,
            station_name=self.station_name,
            index=self.session_index
        )

    def install_package(self, force=False):
        self._ensure_connected()

        if self.package_name is None:
            raise ValueError('package_name must be specified')

        if force:
            self.uninstall_package()

        package = self.get_installed_package()

        if package is not None:
            existing_version = tuple(package.version)

            if existing_version == self.get_local_package_version():
                return

            self.uninstall_package()

        self._proxy.install_package(
            name=self.package_name,
            remote_source_path=self._get_remote_file_path()
        )

    def handle_package_config(self, force=False):
        if self.package_name is not None:

            logger.info(f'{repr(self)}: handle_package_config')

            if self.package_installer is None:
                self.package_installer = build_installed_package(
                    package_name=self.package_name,
                    version_tuple=self.package_version,
                    package_root=self.package_root,
                    **self.package_build_kwargs
                )

            self.install_package(force=force)
            self._proxy.import_package(
                name=self.package_name,
                station_name=self.station_name,
                index=self.session_index
            )

    def get_root_service(self):
        if self._root_service is None:
            self._root_service = self._proxy.get_remote_service(
                service_name=SVC_NAME_ROOT,
                station_name=self.station_name,
                index=self.session_index
            )

        return self._root_service

    def handle_module_config(self):
        if self.module_name is not None:
            logger.info(f'{repr(self)}: handle_module_config')

            self.import_module()

    def handle_ext_handler_config(self):
        if self.ext_request_handler:
            logger.info(f'{repr(self)}: handle_ext_handler_config')

            root_service = self.get_root_service()
            context_request = root_service.create_context_request()

            context_request.add_item_request(
                key='name',
                value=self.ext_request_name,
                evaluated=True
            )

            context_request.add_item_request(
                key='ext_handler',
                import_path=self.import_path,
                call_import=self.call_service_import,
                call_args=self.service_args,
                call_kwargs=self.service_kwargs,
                evaluated=False
            )

            self._ext_handler_ctx_uuid = root_service.create_session_context(context_request)
            root_service.add_ext_request_handler(context_uuid=self._ext_handler_ctx_uuid)

    def handle_service_config(self):
        logger.info(f'{repr(self)}: handle_service_config')
        root_service = self.get_root_service()
        context_request = root_service.create_context_request()

        context_request.add_item_request(
            key='name',
            value=self.service_name,
            evaluated=True
        )

        if self._ext_handler_ctx_uuid is None:
            context_request.add_item_request(
                key='service',
                import_path=self.import_path,
                call_import=self.call_service_import,
                call_args=self.service_args,
                call_kwargs=self.service_kwargs,
                evaluated=False
            )

            svc_ctx_uuid = root_service.create_session_context(context_request)

        else:
            keyword_mapping = [('ext_handler', 'service')]
            svc_ctx_uuid = root_service.create_session_context(
                context_request=context_request,
                src_uuid=self._ext_handler_ctx_uuid,
                keyword_mapping=keyword_mapping
            )

        self._svc_ctx_uuid = svc_ctx_uuid
        root_service.add_service(context_uuid=svc_ctx_uuid)

    def handle_context_cleanup(self):
        logger.info(f'{repr(self)}: handle_context_cleanup')
        root_service = self.get_root_service()

        if self._ext_handler_ctx_uuid is not None:
            root_service.clear_session_context(self._ext_handler_ctx_uuid)
            self._ext_handler_ctx_uuid = None

        if self._svc_ctx_uuid is not None:
            root_service.clear_session_context(self._svc_ctx_uuid)
            self._svc_ctx_uuid = None

    def get_installed_service(self):
        self._ensure_connected()
        return self._proxy.get_remote_service(
            service_name=self.service_name,
            station_name=self.station_name,
            index=self.session_index
        )

    def install_service(self, force_service=False, force_package=False):
        if force_service:
            self.uninstall_service()

            if self.ext_request_handler:
                self._proxy.remove_extended_request_handler(self.ext_request_name)

        if not self.is_service_installed():
            self.handle_package_config(force=force_package)
            self.handle_module_config()

            self.handle_ext_handler_config()
            self.handle_service_config()

            self.handle_context_cleanup()

            self._proxy.update_remote_services(
                station_name=self.station_name,
                index=self.session_index
            )

        return self.get_installed_service()
