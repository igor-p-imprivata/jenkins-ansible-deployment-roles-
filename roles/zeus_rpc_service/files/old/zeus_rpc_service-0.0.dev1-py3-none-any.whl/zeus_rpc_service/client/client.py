# client.py
import time
import socket
import logging
import atexit
from enum import IntEnum
from functools import partial
from xmlrpc.client import ServerProxy, Fault
from zeus_ip_helper import ping
from zeus_utils import wheel_metadata_to_dict
from zeus_win32_utils import WConnectFlags
from zeus_reg import RegistryKeyFlags, RegistryDataTypes
from zeus_rpc_service.definitions import (
    SVC_PORT, SVC_NAME_ROOT, SVC_NAME_SESSIONS, SVC_NAME_SYSTEM, SVC_NAME_REGISTRY, SVC_NAME_DRIVES,
    SVC_NAME_FILES, SVC_NAME_PACKAGES, SVC_NAME_CODE_IMPORTER
)
from zeus_rpc_service.protocol import (RpcRequestPacket, RpcResponsePacket)
from zeus_rpc_service.service_providers.packages import (
    normalize_package_name, normalize_package_version
)
from zeus_rpc_service.resources import RpcResourceManager
from zeus_rpc_service.remote_services import RpcRemoteServiceManager
from zeus_rpc_service.exceptions import ZeusRpcServiceError


logger = logging.getLogger(__name__)

STATION_NAME_SERVICES = 'Services'
STATION_NAME_CONSOLE = 'Console'

SERVICES_SESSION_ID = 0

WAIT_PING_INTERVAL = 1
WAIT_SOCKET_TIMEOUT = 0.5

AUTO_LOGON_REG_KEY = 'HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon'
AUTO_LOGON_USERNAME_VALUE = 'DefaultUserName'
AUTO_LOGON_PASSWORD_VALUE = 'DefaultPassword'
AUTO_LOGON_DOMAIN_VALUE = 'DefaultDomainName'
AUTO_LOGON_SWITCH_VALUE = 'AutoAdminLogon'

AUTO_LOGON_VALUE_NAMES = (
    AUTO_LOGON_USERNAME_VALUE, AUTO_LOGON_PASSWORD_VALUE, AUTO_LOGON_DOMAIN_VALUE,
    AUTO_LOGON_SWITCH_VALUE
)


def wait_for_icmp_response(host, exit_condition, timeout=None, interval=WAIT_PING_INTERVAL):
    start = time.time()

    while True:
        ping_response = ping(host, count=1, timeout=interval)

        if exit_condition(ping_response):
            break

        if timeout is not None and (time.time() - start) > timeout:
            raise TimeoutError()

        time.sleep(interval)


def get_auto_logon_requirements(username=None, password=None, domain=None, enabled=True):
    name_values = []

    if username is not None:
        name_values.append((AUTO_LOGON_USERNAME_VALUE, username))

    if password is not None:
        name_values.append((AUTO_LOGON_PASSWORD_VALUE, password))

    if domain is not None:
        name_values.append((AUTO_LOGON_DOMAIN_VALUE, domain))

    name_values.append((AUTO_LOGON_SWITCH_VALUE, '1' if enabled else '0'))
    return name_values


class DisconnectActions(IntEnum):
    NONE = 0
    CLEAR_SESSION = 1
    SHUTDOWN_SERVER = 2


class RpcSession:
    def __init__(self, host, port, path=None, station_name=STATION_NAME_SERVICES,
                 session_id=SERVICES_SESSION_ID):
        if path is not None:
            if not path.startswith('/'):
                path = f'/{path}'

            if path.endswith('/'):
                path = path[:-1]

        self.host = host
        self.port = port
        self.path = path
        self.station_name = station_name
        self.session_id = session_id
        self.server_url = f'http://{host}:{port}{path or ""}'

        self._server = ServerProxy(self.server_url, allow_none=True)

        self._session_uuid = None
        self._service_manager = None
        self._resource_manager = None
        self._on_disconnect = None
        self._connected = False

    def __repr__(self):
        return f'{self.__class__.__name__}(station_name="{self.station_name}")'

    def __getattr__(self, item):
        return self.get_remote_service(item)

    def send_request(self, rpc_request):
        rpc_request.session_uuid = self._session_uuid

        logger.debug(f'{repr(self)}: sending to server -> {str(rpc_request)}')

        request_binary = rpc_request.serialize()

        try:
            response_binary = self._server.handle_request(request_binary)
        except Fault as exc:
            raise ZeusRpcServiceError(exc)

        response = RpcResponsePacket.deserialize(response_binary, send_func=self.send_request)
        return response.unmarshal()

    def raise_for_not_connected(self):
        if not self._connected:
            raise RuntimeError(f'{repr(self)} not connected')

    def clear_state(self):
        self._session_uuid = None
        self._service_manager = None
        self._resource_manager = None
        self._on_disconnect = None
        self._connected = False

    def set_on_disconnect(self, disconnect_action):
        if disconnect_action not in DisconnectActions:
            disconnect_action = DisconnectActions(disconnect_action)

        root_service = self.get_remote_service(SVC_NAME_ROOT)

        if disconnect_action is DisconnectActions.CLEAR_SESSION:
            self._on_disconnect = partial(root_service.clear_session, self._session_uuid)

        elif disconnect_action is DisconnectActions.SHUTDOWN_SERVER:
            self._on_disconnect = root_service.shutdown_server

        else:
            self._on_disconnect = None

    def connect(self, disconnect_action=DisconnectActions.CLEAR_SESSION):
        logger.info(f'{repr(self)}: connect -> creating session on server')

        root = RpcRequestPacket(
            send_func=self.send_request,
            service_name=SVC_NAME_ROOT
        )

        self._session_uuid = session_uuid = root.create_session()

        logger.info(f'{repr(self)}: connect -> created session_uuid: {session_uuid}')

        service_names = root.get_service_names()

        self._service_manager = RpcRemoteServiceManager(
            send_func=self.send_request,
            session_uuid=session_uuid,
        )
        self._service_manager.update_services(service_names)

        self._resource_manager = RpcResourceManager()

        self._connected = True

        logger.info(f'{repr(self)}: successfully connected -> service_names: {service_names}')

        self.set_on_disconnect(disconnect_action)

    def disconnect(self):
        if not self._connected:
            return False

        logger.info(f'{repr(self)}: disconnecting...')

        self.cleanup_resources()

        if self._on_disconnect is not None:
            self._on_disconnect()

        self.clear_state()

        logger.info(f'{repr(self)}: successfully disconnected')
        return True

    def get_remote_service(self, service=SVC_NAME_ROOT):
        self.raise_for_not_connected()
        return self._service_manager.get_remote_service(service)

    def cleanup_resources(self):
        logger.debug(f'{repr(self)}: cleaning up resources')
        self.raise_for_not_connected()
        self._resource_manager.cleanup()

    def register_resource(self, tag, resource, cleanup_func=None):
        self.raise_for_not_connected()
        self._resource_manager.register(tag, resource=resource, cleanup_func=cleanup_func)

    def get_resource(self, tag):
        self.raise_for_not_connected()
        return self._resource_manager.get(tag)

    def update_services(self):
        root_service = self._service_manager.get_remote_service(SVC_NAME_ROOT)
        service_names = root_service.get_service_names()
        logger.info(f'{repr(self)}: update_services -> service_names: {service_names}')
        self._service_manager.update_services(service_names)
        return service_names

    def get_service_names(self):
        return self.update_services()

    def create_context(self, context_request):
        context_request.session_uuid = self._session_uuid
        root_service = self._service_manager.get_remote_service(SVC_NAME_ROOT)
        return root_service.create_session_context(context_request)

    def clear_context(self, context_uuid):
        root_service = self._service_manager.get_remote_service(SVC_NAME_ROOT)
        root_service.clear_session_context(
            session_uuid=self._session_uuid, context_uuid=context_uuid
        )


class RpcServiceProxy:
    def __init__(self, host, port=SVC_PORT, path=None):
        self.host = host
        self.port = port
        self.path = path
        self._used_ports = {port}
        self._sessions_by_station_name = {}
        self._dc_registered = False
        self._register_disconnect()

    def __repr__(self):
        return f'{self.__class__.__name__}(host="{self.host}", port={self.port})'

    @property
    def services_session(self):
        return self.get_session(STATION_NAME_SERVICES)

    @property
    def console_session(self):
        return self.get_session(STATION_NAME_CONSOLE)

    def _register_disconnect(self):
        if not self._dc_registered:
            atexit.register(self.disconnect)
            self._dc_registered = True

    def _unregister_disconnect(self):
        if self._dc_registered:
            atexit.unregister(self.disconnect)
            self._dc_registered = False

    def get_session(self, station_name, index=0):
        sessions = self._sessions_by_station_name.get(station_name)

        if sessions and index < len(sessions):
            return sessions[index]

        raise RuntimeError(f'"{station_name}" has no connected sessions')

    def get_remote_service_names(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.get_service_names()

    def update_remote_services(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.update_services()

    def get_remote_service(self, service_name=SVC_NAME_ROOT, station_name=STATION_NAME_SERVICES,
                           index=0):
        session = self.get_session(station_name, index=index)
        return session.get_remote_service(service=service_name)

    def claim_available_port(self):
        port = self.port + 1

        while port in self._used_ports:
            port += 1

        self._used_ports.add(port)
        return port

    def release_port(self, port):
        self._used_ports.discard(port)

    def find_windows_session(self, *, case_insensitive=True, sub_string=True, **attributes):
        services_session = self.get_session(STATION_NAME_SERVICES)
        session_manager = services_session.get_remote_service(service=SVC_NAME_SESSIONS)
        return session_manager.find(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def wait_for_reboot(self, reboot_timeout=None):
        logger.info(f'{repr(self)}: waiting for {self.host} to reboot...')
        start = time.time()

        logger.debug(f'{repr(self)}: reboot -> waiting for {self.host} to become '
                     f'unreachable via ICMP')
        # wait until not ping-able
        wait_for_icmp_response(host=self.host,
                               exit_condition=lambda ping_response: not bool(ping_response),
                               timeout=reboot_timeout)

        logger.debug(f'{repr(self)}: reboot -> {self.host} unreachable via ICMP')

        logger.debug(f'{repr(self)}: reboot -> waiting for {self.host} to become '
                     f'reachable via ICMP')

        if reboot_timeout is not None:
            reboot_timeout -= (time.time() - start)

        # wait until ping-able
        wait_for_icmp_response(host=self.host,
                               exit_condition=lambda ping_response: bool(ping_response),
                               timeout=reboot_timeout)

        logger.debug(f'{repr(self)}: reboot -> {self.host} reachable via ICMP')

        logger.debug(f'{repr(self)}: reboot -> waiting for RPC service on {self.host}')

        if reboot_timeout is not None:
            reboot_timeout -= (time.time() - start)

        self.wait_for_services_session(timeout=reboot_timeout)

        elapsed_time = time.time() - start
        logger.debug(f'{repr(self)}: reboot -> RPC service on {self.host} reachable; '
                     f'elapsed_time: {elapsed_time} second(s)')

        logger.info(f'{repr(self)}: successfully rebooted {self.host}')

    def wait_for_services_session(self, timeout=None, socket_timeout=WAIT_SOCKET_TIMEOUT,
                                  interval=WAIT_PING_INTERVAL):
        orig_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(socket_timeout)
        start = time.time()

        try:
            while True:
                try:
                    return self.connect_services_session()
                except socket.timeout:
                    if timeout is not None and (time.time() - start) > timeout:
                        raise TimeoutError()

                    time.sleep(interval)

        finally:
            socket.setdefaulttimeout(orig_timeout)

    def connect_session(self, station_name, session_id, port, path=None,
                        disconnect_action=DisconnectActions.CLEAR_SESSION):

        session = RpcSession(
            host=self.host,
            port=port,
            path=path,
            station_name=station_name,
            session_id=session_id
        )

        self._sessions_by_station_name.setdefault(session.station_name, [])
        sessions = self._sessions_by_station_name[session.station_name]
        session_index = len(sessions)

        logger.debug(f'{repr(self)}: connecting {repr(session)} (index={session_index})')

        session.connect(disconnect_action=disconnect_action)

        self._sessions_by_station_name[session.station_name].append(session)
        logger.debug(f'{repr(self)}: successfully connected to {repr(session)} (index={session_index})')
        return session

    def disconnect_session(self, station_name, index=0):
        session = self.get_session(station_name, index=index)

        logger.debug(f'{repr(self)}: disconnecting {repr(session)} (index={index})')

        if session.disconnect():
            logger.debug(f'{repr(self)}: successfully disconnected from {repr(session)} '
                         f'(index={index})')

            self._unregister_disconnect()

    def connect_to_session_id(self, session_id, timeout=None, **kwargs):
        services_session = self.get_session(STATION_NAME_SERVICES)
        windows_session = self.find_windows_session(session_id=session_id)
        station_name = windows_session.station_name
        port = self.claim_available_port()
        root_service = services_session.get_remote_service(service=SVC_NAME_ROOT)
        root_service.spawn_rpc_server(
            session_id=session_id,
            port=port,
            timeout=timeout,
            **kwargs
        )

        try:
            session = self.connect_session(
                station_name=station_name,
                session_id=session_id,
                port=port,
                disconnect_action=DisconnectActions.SHUTDOWN_SERVER
            )
        except Exception:
            self.release_port(port)
            raise

        return session

    def connect_services_session(self):
        return self.connect_session(
            station_name=STATION_NAME_SERVICES,
            session_id=SERVICES_SESSION_ID,
            port=self.port,
            path=self.path
        )

    def disconnect_services_session(self, index=0):
        self.disconnect_session(STATION_NAME_SERVICES, index=index)

    def connect_console_session(self, timeout=None, **kwargs):
        windows_session = self.find_windows_session(station_name=STATION_NAME_CONSOLE)

        if windows_session is None:
            raise RuntimeError('No console session found on host')

        # if the windows_session is an RDP session, console is actually attached
        # to an active RDP session with the station name "RDP-Tcp#N"
        # if windows_session.is_remote:
        if windows_session.get_user() is None:
            windows_session = self.find_windows_session(station_name='RDP-Tcp#')
            session_id = windows_session.session_id

        else:
            services_session = self.get_session(STATION_NAME_SERVICES)
            session_manager = services_session.get_remote_service(service=SVC_NAME_SESSIONS)
            session_id = session_manager.get_console_session_id()

        return self.connect_to_session_id(
            session_id=session_id,
            timeout=timeout,
            **kwargs
        )

    def disconnect_console_session(self, index=0):
        self.disconnect_session(STATION_NAME_CONSOLE, index=index)

    def connect(self):
        logger.info(f'{repr(self)}: connecting to service...')

        services_session = self.connect_services_session()

        logger.info(f'{repr(self)}: successfully connected to service')

        return services_session

    def disconnect(self):
        logger.info(f'{repr(self)}: disconnecting from service...')

        for station_name, sessions in tuple(self._sessions_by_station_name.items()):

            for i in range(len(sessions)):
                self.disconnect_session(station_name, index=i)

        logger.info(f'{repr(self)}: successfully disconnected from service')
        self._sessions_by_station_name.clear()

    def get_resource(self, tag, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        return session.get_resource(tag)

    def reboot(self, message=None, timeout=0, force_apps_closed=True, wait=True,
               reboot_timeout=None):
        logger.info(f'{repr(self)}: rebooting {self.host}...')

        self.disconnect_session(STATION_NAME_CONSOLE)

        services_session = self.get_session(STATION_NAME_SERVICES)
        services_session.cleanup_resources()

        system_service = services_session.get_remote_service(SVC_NAME_SYSTEM)
        system_service.initiate_system_shutdown(
            message=message,
            timeout=timeout,
            force_apps_closed=force_apps_closed,
            reboot=True
        )

        self._sessions_by_station_name.clear()

        if wait:
            self.wait_for_reboot(reboot_timeout=reboot_timeout)

    def get_auto_logon_registry_key(self, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)

        system_service = session.get_remote_service(SVC_NAME_SYSTEM)
        os_bitness = system_service.get_os_bitness()

        key_flag = RegistryKeyFlags.WOW64_64_KEY if os_bitness == 64 else 0

        registry_service = session.get_remote_service(SVC_NAME_REGISTRY)
        return registry_service.get(AUTO_LOGON_REG_KEY, key_flag=key_flag)

    def get_auto_logon_registry_values(self, key=None, station_name=STATION_NAME_SERVICES, index=0):
        key = key or self.get_auto_logon_registry_key(
            station_name=station_name,
            index=index
        )

        if key is None:
            raise ValueError(f'Unable to find key: {AUTO_LOGON_REG_KEY}')

        return {name: key.get_value(name) for name in AUTO_LOGON_VALUE_NAMES}

    def enable_auto_logon(self, username=None, password=None, domain=None, key=None,
                          station_name=STATION_NAME_SERVICES, index=0):
        logger.debug(f'{repr(self)}: enable_auto_logon -> username: {username}, '
                     f'password: {password}, domain: {domain}')

        key = key or self.get_auto_logon_registry_key(station_name=station_name, index=index)
        reg_val_map = self.get_auto_logon_registry_values(key=key)
        requirements = get_auto_logon_requirements(
            username=username,
            password=password,
            domain=domain,
            enabled=True
        )

        for value_name, required_value in requirements:
            reg_val = reg_val_map.get(value_name)

            if reg_val is None:
                key.create_value(
                    name=value_name,
                    data_type=RegistryDataTypes.SZ,
                    value=required_value
                )

            elif reg_val.get() != required_value:
                key.set_value(
                    name=value_name,
                    data_type=RegistryDataTypes.SZ,
                    value=required_value
                )

    def check_auto_logon_enabled(self, username=None, password=None, domain=None, key=None,
                                 station_name=STATION_NAME_SERVICES, index=0):
        reg_val_map = self.get_auto_logon_registry_values(
            key=key,
            station_name=station_name,
            index=index
        )
        requirements = get_auto_logon_requirements(
            username=username,
            password=password,
            domain=domain,
            enabled=True
        )

        for value_name, required_value in requirements:
            reg_val = reg_val_map.get(value_name)

            if reg_val is None or reg_val.value != required_value:
                enabled = False
                break

        else:
            enabled = True

        logger.debug(f'{repr(self)}: check_auto_logon_enabled -> {enabled}')
        return enabled

    def ensure_auto_logon_enabled(self, username=None, password=None, domain=None,
                                  station_name=STATION_NAME_SERVICES, index=0):
        key = self.get_auto_logon_registry_key(station_name=station_name, index=index)

        enabled = self.check_auto_logon_enabled(
            username=username,
            password=password,
            domain=domain,
            key=key
        )

        if not enabled:
            self.enable_auto_logon(
                username=username,
                password=password,
                domain=domain,
                key=key
            )

    def disconnect_network_drives(self, station_name=STATION_NAME_SERVICES, index=0):
        drive_manager = self.get_remote_service(
            service_name=SVC_NAME_DRIVES,
            station_name=station_name,
            index=index
        )
        drive_manager.disconnect_drives()

    def map_network_drive(self, tag, remote_name, username, password,
                          flags=WConnectFlags.TEMPORARY, cleanup=True,
                          station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        drive_manager = session.get_remote_service(SVC_NAME_DRIVES)

        network_drive = drive_manager.map_network_drive(
            remote_name=remote_name,
            username=username,
            password=password,
            flags=flags
        )

        cleanup_func = network_drive.disconnect if cleanup else None

        session.register_resource(
            tag=tag,
            resource=network_drive,
            cleanup_func=cleanup_func
        )

        return network_drive

    def copy_file(self, tag, src, dest_dir=None, file_name=None, fail_if_exists=False,
                  cleanup=True, station_name=STATION_NAME_SERVICES, index=0):
        logger.debug(f'{repr(self)}: copy_file -> {src}')

        session = self.get_session(station_name, index=index)

        file_manager = session.get_remote_service(SVC_NAME_FILES)

        start = time.time()

        remote_file = file_manager.copy_file(
            src=src,
            dest_dir=dest_dir,
            file_name=file_name,
            fail_if_exists=fail_if_exists
        )

        elapsed_time = time.time() - start
        logger.debug(f'{repr(self)}: copy_file complete, elapsed_time: {elapsed_time}')

        cleanup_func = remote_file.delete if cleanup else None

        session.register_resource(
            tag=tag,
            resource=remote_file,
            cleanup_func=cleanup_func
        )

        return remote_file

    def send_file(self, tag, src, dest_dir=None, cleanup=True, station_name=STATION_NAME_SERVICES,
                  index=0):
        logger.debug(f'{repr(self)}: send_file -> {src}')

        session = self.get_session(station_name, index=index)

        file_manager = session.get_remote_service(SVC_NAME_FILES)

        start = time.time()

        remote_file = file_manager.send_file(
            src=src,
            dest_dir=dest_dir,
        )

        elapsed_time = time.time() - start
        logger.debug(f'{repr(self)}: send_file complete, elapsed_time: {elapsed_time}')

        cleanup_func = remote_file.delete if cleanup else None

        session.register_resource(
            tag=tag,
            resource=remote_file,
            cleanup_func=cleanup_func
        )

        return remote_file

    def find_package(self, *, station_name=STATION_NAME_SERVICES, index=0,
                     case_insensitive=True, sub_string=True, **attributes):
        package_manager = self.get_remote_service(
            service_name=SVC_NAME_PACKAGES,
            station_name=station_name,
            index=index
        )
        return package_manager.find_package(
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            **attributes
        )

    def install_package(self, name=None, source=None, extra_args=None, remote_source_path=None,
                        force=False, wait_timeout=None, station_name=STATION_NAME_SERVICES, index=0):
        if name is None and source is None:
            raise ValueError('Either name or source must be specified')

        if source is not None and not source.endswith('.whl'):
            raise ValueError('Only wheel package format is supported')

        package_manager = self.get_remote_service(
            service_name=SVC_NAME_PACKAGES,
            station_name=station_name,
            index=index
        )

        if source is not None:
            logger.info(f'{repr(self)}: install_package -> source: {source}')

            wheel_metadata = wheel_metadata_to_dict(source)
            name = normalize_package_name(wheel_metadata['Name'])
            version = normalize_package_version(wheel_metadata['Version'])
            existing_package = package_manager.find(name=name)

            if existing_package is not None:
                existing_version = tuple(existing_package.version)

                if existing_version == version and not force:
                    # nothing to do
                    logger.info(f'{repr(self)}: install_package -> required package version '
                                f'already installed')
                    return existing_package

            remote_file = self.send_file(
                tag=source,
                src=source,
                station_name=station_name,
                index=index
            )
            package = remote_file.path

        elif remote_source_path is not None:
            package = remote_source_path

        else:
            package = name
            logger.info(f'{repr(self)}: install_package -> name: {name}')

        stdout = package_manager.install(
            package=package,
            extra_args=extra_args
        )

        logger.debug(f'{repr(self)}: install_package -> stdout: {stdout}')

        return package_manager.wait_for_package(timeout=wait_timeout, name=name)

    def uninstall_package(self, name=None, source=None, extra_args=None,
                          remote_source_path=None, station_name=STATION_NAME_SERVICES, index=0):
        if name is None and source is None:
            raise ValueError('Either name or source must be specified')

        if source is not None and not source.endswith('.whl'):
            raise ValueError('Only wheel package format is supported')

        package_manager = self.get_remote_service(
            service_name=SVC_NAME_PACKAGES,
            station_name=station_name,
            index=index
        )

        importer = self.get_remote_service(
            service_name=SVC_NAME_CODE_IMPORTER,
            station_name=station_name,
            index=index
        )

        if source is not None:
            wheel_metadata = wheel_metadata_to_dict(source)
            name = normalize_package_name(wheel_metadata['Name'])

            remote_file = self.send_file(
                tag=source,
                src=source,
                station_name=station_name,
                index=index
            )
            source = remote_file.path

        elif remote_source_path is not None:
            source = remote_source_path

        else:
            source = None

        stdout = package_manager.uninstall(
            package=name, source=source, extra_args=extra_args
        )

        logger.info(f'{repr(self)}: uninstall_package -> stdout: {stdout}')

        importer.unload(name=name, raise_if_non_existent=False)
        package_manager.refresh_packages()

    def import_module(self, name, code=None, path=None, station_name=STATION_NAME_SERVICES, index=0):
        code_importer = self.get_remote_service(
            service_name=SVC_NAME_CODE_IMPORTER,
            station_name=station_name,
            index=index
        )

        if path is not None:
            remote_file = self.send_file(
                tag=path,
                src=path,
                station_name=station_name,
                index=index
            )
            path = remote_file.path

        return code_importer.import_module(name=name, code=code, path=path)

    def import_package(self, package_info=None, name=None, location=None,
                       station_name=STATION_NAME_SERVICES, index=0):
        if not any((package_info, name)):
            raise ValueError('Either package_info or name must be specified')

        if package_info is not None:
            name = package_info.name
            location = package_info.location

        elif location is None:
            package_manager = self.get_remote_service(
                service_name=SVC_NAME_PACKAGES,
                station_name=station_name,
                index=index
            )
            package_info = package_manager.find(name=name)

            if package_info is None:
                raise ValueError(f'Package "{name}" not installed')

            location = package_info.location

        code_importer = self.get_remote_service(
            service_name=SVC_NAME_CODE_IMPORTER,
            station_name=station_name,
            index=index
        )

        return code_importer.import_package(name=name, location=location)

    def add_service(self, service_name, import_path, call_service_import=False, service_args=None,
                    service_kwargs=None, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        root_service = session.get_remote_service(SVC_NAME_ROOT)

        result = root_service.add_service(
            service_name=service_name,
            import_path=import_path,
            call_service_import=call_service_import,
            service_args=service_args,
            service_kwargs=service_kwargs
        )

        session.update_services()
        return result

    def remove_service(self, service_name, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        root_service = session.get_remote_service(SVC_NAME_ROOT)
        result = root_service.remove_service(name=service_name)
        session.update_services()
        return result

    def add_extended_request_handler(self, name, import_path,
                                     station_name=STATION_NAME_SERVICES, index=0, **handler_kwargs):
        session = self.get_session(station_name, index=index)
        root = session.get_remote_service(SVC_NAME_ROOT)
        root.add_ext_request_handler(
            name=name,
            import_path=import_path,
            **handler_kwargs
        )

    def remove_extended_request_handler(self, name, station_name=STATION_NAME_SERVICES, index=0):
        session = self.get_session(station_name, index=index)
        root = session.get_remote_service(SVC_NAME_ROOT)
        root.remove_ext_request_handler(name=name)
