# objects.py
import inspect
from uuid import uuid4
from collections import deque, namedtuple, Callable
from .base import RpcSerializableObject, RpcSerializableChannel
from .request import RpcRequestPacket


__local_unbound_attr_cache = {}
_ctx_item_type = namedtuple('context_item', ['key', 'value'])


def _flatten_class_inheritance(cls):
    classes = []
    queue = deque([cls])

    while queue:
        current = queue.popleft()

        if current is object:
            classes.reverse()
            return classes

        classes.append(current)
        queue.extend(current.__bases__)


def _get_local_unbound_attr_map(type_):
    unbound_attr_map = __local_unbound_attr_cache.get(type_.__name__)

    if unbound_attr_map is None:
        unbound_attr_map = {}
        classes = _flatten_class_inheritance(type_)

        for cls_ in classes:
            for attr_name, unbound_attr_obj in cls_.__dict__.items():
                if attr_name.startswith('_'):
                    continue

                is_callable = isinstance(unbound_attr_obj, Callable)
                unbound_attr_map[attr_name] = (unbound_attr_obj, is_callable)

            __local_unbound_attr_cache[type_.__name__] = unbound_attr_map

    return unbound_attr_map


def is_custom_class_instance(obj):
    if isinstance(obj, type):
        raise TypeError('Argument must be an instance of a class')

    return hasattr(obj, '__dict__') or hasattr(obj, '__slots__')


def wrap_local_object(local_object):
    local_object_wrapper = RpcLocalObjectWrapper()
    return local_object_wrapper.wrap(local_object)


class RpcLocalObjectWrapper:
    def __init__(self):
        self.object = None
        self.unbound_attr_map = None
        self.callable_map = None
        self.class_name = None
        self.object_hash = None
        self.object_string = None

    def __getattr__(self, item):
        attr_info = self.unbound_attr_map.get(item)
        is_callable = self.callable_map.get(item)

        if attr_info is not None:
            unbound_attr, _ = attr_info

            if isinstance(unbound_attr, property):
                # noinspection PyUnusedLocal
                def _wrapper(*args, **kwargs):
                    return unbound_attr.__get__(self.object)

                return _wrapper

            if is_callable:
                return unbound_attr.__get__(self.object, self.object.__class__)

        if not is_callable:
            # noinspection PyUnusedLocal
            def _wrapper(*args, **kwargs):
                return getattr(self.object, item)

            return _wrapper

        return getattr(self.object, item)

    def wrap(self, local_object, **kwargs):
        cls = local_object.__class__
        unbound_attr_map = _get_local_unbound_attr_map(cls)
        callable_map = {}

        self.object = local_object
        self.unbound_attr_map = unbound_attr_map
        self.class_name = cls.__name__
        self.object_hash = hash(local_object)
        self.object_string = str(local_object)

        for key, value in unbound_attr_map.items():
            _, is_callable = value
            callable_map[key] = is_callable

        for attr_name in dir(local_object):
            if attr_name.startswith('_') or attr_name in callable_map:
                continue

            bound_attr = getattr(local_object, attr_name)

            if inspect.ismethod(bound_attr) or inspect.isfunction(bound_attr):
                is_callable = True

            else:
                is_callable = False

            callable_map[attr_name] = is_callable

        self.callable_map = callable_map
        return self

    def call_object(self, attribute_name, *callable_args, **callable_kwargs):
        return self.__getattr__(attribute_name)(*callable_args, **callable_kwargs)

    def to_proxy(self, session_uuid):
        return RpcRemoteObjectProxy(
            session_uuid=session_uuid,
            class_name=self.class_name,
            object_hash=self.object_hash,
            object_string=self.object_string,
            callable_map=self.callable_map
        )


class RpcRemoteObjectProxy(RpcSerializableChannel):
    __slots__ = RpcSerializableChannel.__slots__ + (
        'session_uuid',
        'class_name',
        'object_hash',
        'object_string',
        'callable_map',
        'rpc_request'
    )

    PRIVATE_SLOTS = {'rpc_request', *RpcSerializableChannel.PRIVATE_SLOTS}

    def __init__(self, session_uuid, class_name, object_hash, object_string, callable_map):
        super(RpcRemoteObjectProxy, self).__init__()
        self.session_uuid = session_uuid
        self.class_name = class_name
        self.object_hash = object_hash
        self.object_string = object_string
        self.callable_map = callable_map
        self.rpc_request = None

    def __str__(self):
        return self.object_string

    def __getattr__(self, item):
        if self.send_func is None:
            raise RuntimeError('send_func is not defined')

        try:
            is_callable = self.callable_map[item]
        except KeyError:
            raise AttributeError(f"'{self.class_name}' instance has no attribute '{item}'")

        if self.rpc_request is None:
            self.rpc_request = RpcRequestPacket(
                send_func=self.send_func,
                session_uuid=self.session_uuid,
                class_name=self.class_name,
                object_hash=self.object_hash
            )

        attr_wrapper = self.rpc_request.wrap_remote_attribute(item)
        return attr_wrapper if is_callable else attr_wrapper()


class RpcSessionContext:
    def __init__(self):
        self.uuid = str(uuid4())
        self.args = []
        self.kwargs = {}

    def add_item(self, context_item):
        if context_item.key is None:
            self.args.append(context_item.value)

        else:
            self.kwargs[context_item.key] = context_item.value


class RpcContextItemRequest(RpcSerializableObject):
    __slots__ = (
        '_value',
        'key',
        'import_path',
        'call_import',
        'call_args',
        'call_kwargs',
        'evaluated',
        'method_name'
    )

    def __init__(self, value=None, key=None, import_path=None, call_import=False,
                 call_args=None, call_kwargs=None, evaluated=False, method_name=None):
        self._value = value
        self.key = key
        self.import_path = import_path
        self.call_import = call_import
        self.call_args = call_args
        self.call_kwargs = call_kwargs
        self.evaluated = evaluated
        self.method_name = method_name

    def set_value(self, value):
        self._value = value
        self.evaluated = True

    def get_item(self):
        if self.evaluated:
            return _ctx_item_type(key=self.key, value=self._value)


class RpcContextRequest(RpcSerializableObject):
    __slots__ = (
        'session_uuid',
        'item_requests'
    )

    def __init__(self, session_uuid=None):
        self.session_uuid = session_uuid
        self.item_requests = []

    def __iter__(self):
        for item_request in self.item_requests:
            yield item_request

    def __len__(self):
        return len(self.item_requests)

    def __getitem__(self, item):
        return self.item_requests[item]

    def add_item_request(self, value=None, key=None, import_path=None, call_import=False,
                         call_args=None, call_kwargs=None, evaluated=False, method_name=None):
        if value is None and import_path is None:
            raise ValueError(f'Either value or import_path must be specified')

        item_request = RpcContextItemRequest(
            value=value,
            key=key,
            import_path=import_path,
            call_import=call_import,
            call_args=call_args,
            call_kwargs=call_kwargs,
            evaluated=evaluated,
            method_name=method_name
        )
        self.item_requests.append(item_request)


class RpcSessionObjectCache:
    def __init__(self, session_uuid):
        self.session_uuid = session_uuid
        self.__local_objects = {}
        self.__context = {}

    def create_context(self, src_uuid=None, keyword_mapping=None):
        ctx = RpcSessionContext()

        if src_uuid is not None and keyword_mapping is not None:
            src_ctx = self.get_context(src_uuid)

            if src_ctx is None:
                raise ValueError(f'Invalid src_uuid: {src_uuid}')

            if not isinstance(keyword_mapping, (dict, list, tuple)):
                raise TypeError(f'Invalid keyword_mapping type: {type(keyword_mapping).__name__}')

            if isinstance(keyword_mapping, dict):
                keyword_mapping = list(keyword_mapping.items())

            for src_key, dst_key in keyword_mapping:
                ctx_item = _ctx_item_type(
                    key=dst_key,
                    value=src_ctx.kwargs.get(src_key)
                )
                ctx.add_item(ctx_item)

        self.__context[ctx.uuid] = ctx
        return ctx

    def get_context(self, uuid):
        return self.__context.get(uuid)

    def clear_context(self, uuid):
        self.__context.pop(uuid, None)

    def cache_object(self, local_object):
        class_name = local_object.__class__.__name__
        object_hash = hash(local_object)

        self.__local_objects.setdefault(class_name, {})
        local_object_wrapper = self.__local_objects.get(object_hash)

        if local_object_wrapper is None:
            local_object_wrapper = wrap_local_object(local_object=local_object)
            self.__local_objects[class_name][object_hash] = local_object_wrapper

        return local_object_wrapper

    def cache_object_get_proxy(self, local_object):
        local_object_wrapper = self.cache_object(local_object=local_object)
        return local_object_wrapper.to_proxy(session_uuid=self.session_uuid)

    def get_wrapper(self, class_name, object_hash):
        class_storage = self.__local_objects.get(class_name)

        if class_storage is not None:
            return class_storage.get(object_hash)

    def get_proxy(self, class_name, object_hash):
        wrapper = self.get_wrapper(
            class_name=class_name,
            object_hash=object_hash
        )

        if wrapper is not None:
            return wrapper.to_proxy(session_uuid=self.session_uuid)

    def clear(self):
        self.__local_objects.clear()
