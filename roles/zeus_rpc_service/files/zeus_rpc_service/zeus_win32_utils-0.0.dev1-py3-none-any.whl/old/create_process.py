# create_process

# with_token = kwargs.pop('with_token', False)
#
#         if username is not None:
# logger.debug(f'{repr(self)}: create_process -> username: {username}')
#             user = User.from_name(username)
#
#             logger.debug(f'{repr(self)}: create_process -> getting session token for {username}')
#             token = user.get_session_token(session_id, password=password, **kwargs)
#
#             sid = user.get_sid()
#             # https://stackoverflow.com/a/21718198
#
#             logger.debug(f'{repr(self)}: create_process -> modifying DACL on windows station')
#             sec_info_dacl = win32security.DACL_SECURITY_INFORMATION
#
#             h_win_sta = win32process.GetProcessWindowStation()
#             logger.debug(f'{repr(self)}: create_process -> getting existing SECURITY_DESCRIPTOR for windows station')
#             existing_sd = win32security.GetUserObjectSecurity(h_win_sta, sec_info_dacl)
#
#             logger.debug(f'{repr(self)}: create_process -> getting existing ACL from SECURITY_DESCRIPTOR for windows station')
#             dacl = existing_sd.GetSecurityDescriptorDacl()
#
#             if dacl is None:
#                 logger.debug(f'{repr(self)}: create_process -> no existing ACL for windows station, creating new one')
#                 dacl = win32security.ACL()
#
#             trustee = dict(
#                 MultipleTrustee=None,
#                 MultipleTrusteeOperation=NO_MULTIPLE_TRUSTEE,
#                 TrusteeForm=win32security.TRUSTEE_IS_SID,
#                 TrusteeType=win32security.TRUSTEE_IS_USER,
#                 Identifier=sid
#             )
#
#             explicit_access = dict(
#                 Trustee=trustee,
#                 Inheritance=win32security.NO_INHERITANCE,
#                 AccessMode=win32security.SET_ACCESS,
#                 AccessPermissions=WINSTA_ALL_ACCESS | win32con.READ_CONTROL
#             )
#
#             logger.debug(f'{repr(self)}: create_process -> setting ACL entries for windows station')
#             dacl.SetEntriesInAcl([explicit_access])
#
#             logger.debug(f'{repr(self)}: create_process -> creating new SECURITY_DESCRIPTOR for windows station')
#             new_sd = win32security.SECURITY_DESCRIPTOR()
#             new_sd.Initialize()
#             logger.debug(f'{repr(self)}: create_process -> setting ACL on new SECURITY_DESCRIPTOR for windows station')
#             new_sd.SetSecurityDescriptorDacl(True, dacl, False)
#
#             logger.debug(f'{repr(self)}: create_process -> setting SECURITY_DESCRIPTOR on windows station')
#             win32security.SetUserObjectSecurity(h_win_sta, sec_info_dacl, new_sd)
#
#             logger.debug(f'{repr(self)}: create_process -> modifying DACL on desktop')
#
#             h_desktop = win32service.GetThreadDesktop(win32api.GetCurrentThreadId())
#
#             logger.debug(f'{repr(self)}: create_process -> getting existing SECURITY_DESCRIPTOR for desktop')
#             existing_sd = win32security.GetUserObjectSecurity(h_desktop, sec_info_dacl)
#
#             dacl = existing_sd.GetSecurityDescriptorDacl()
#
#             if dacl is None:
#                 logger.debug(f'{repr(self)}: create_process -> no existing ACL for desktop, creating new one')
#                 dacl = win32security.ACL()
#
#             trustee = dict(
#                 MultipleTrustee=None,
#                 MultipleTrusteeOperation=NO_MULTIPLE_TRUSTEE,
#                 TrusteeForm=win32security.TRUSTEE_IS_SID,
#                 TrusteeType=win32security.TRUSTEE_IS_USER,
#                 Identifier=sid
#             )
#
#             explicit_access = dict(
#                 Trustee=trustee,
#                 Inheritance=win32security.NO_INHERITANCE,
#                 AccessMode=win32security.SET_ACCESS,
#                 AccessPermissions=win32con.GENERIC_ALL
#             )
#
#             logger.debug(f'{repr(self)}: create_process -> setting ACL entries for desktop')
#             dacl.SetEntriesInAcl([explicit_access])
#
#             logger.debug(f'{repr(self)}: create_process -> creating new SECURITY_DESCRIPTOR for desktop')
#             new_sd = win32security.SECURITY_DESCRIPTOR()
#             new_sd.Initialize()
#
#             logger.debug(f'{repr(self)}: create_process -> setting ACL on new SECURITY_DESCRIPTOR for desktop')
#             new_sd.SetSecurityDescriptorDacl(True, dacl, False)
#
#             logger.debug(f'{repr(self)}: create_process -> setting SECURITY_DESCRIPTOR on desktop')
#             win32security.SetUserObjectSecurity(h_desktop, sec_info_dacl, new_sd)
#         else:
#             logger.debug(f'{repr(self)}: create_process -> getting session token')
#             token = get_session_token(session_id)

#                 if with_token:
#             logon_flags = kwargs.get('logon_flags', LOGON_WITH_PROFILE)
#
#             logger.debug(f'{repr(self)}: create_process -> calling create_process_with_token')
#
#             pid = create_process_with_token(*args,
#                                             token=token,
#                                             logon_flags=logon_flags,
#                                             app_name=app_name,
#                                             creation_flags=creation_flags,
#                                             environment=env,
#                                             current_directory=current_directory,
#                                             startup_info=si)

