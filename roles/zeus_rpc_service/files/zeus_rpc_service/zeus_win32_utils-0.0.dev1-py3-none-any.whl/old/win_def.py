# win_def.py
import ctypes
from ctypes import wintypes


kernel32 = ctypes.windll.kernel32

GetLastError = kernel32.GetLastError
GetLastError.restype = wintypes.DWORD

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = (wintypes.HANDLE,)
CloseHandle.restype = wintypes.BOOL

LocalFree = kernel32.LocalFree
LocalFree.argtypes = (wintypes.HANDLE,)
LocalFree.restype = wintypes.HANDLE

GetCurrentProcess = kernel32.GetCurrentProcess
GetCurrentProcess.restype = wintypes.HANDLE

GetLogicalDrives = kernel32.GetLogicalDrives
GetLogicalDrives.restype = wintypes.DWORD

GetLogicalDriveStrings = kernel32.GetLogicalDriveStringsA
GetLogicalDriveStrings.argtypes = (wintypes.DWORD, wintypes.LPSTR)
GetLogicalDriveStrings.restype = wintypes.DWORD

#
# CopyFile = kernel32.CopyFileA
# CopyFile.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, wintypes.BOOL)
# CopyFile.restype = wintypes.BOOL
#
# GetNativeSystemInfo = kernel32.GetNativeSystemInfo
# GetNativeSystemInfo.argtypes = (LPSYSTEM_INFO,)
#
# CreateEvent = kernel32.CreateEventA
# CreateEvent.argtypes = (LPSECURITY_ATTRIBUTES, wintypes.BOOL, wintypes.BOOL, wintypes.LPCSTR)
# CreateEvent.restype = wintypes.HANDLE
#
# SetEvent = kernel32.SetEvent
# SetEvent.argtypes = (wintypes.HANDLE,)
# SetEvent.restype = wintypes.BOOL
#
# OpenEvent = kernel32.OpenEventA
# OpenEvent.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.LPCSTR)
# OpenEvent.restype = wintypes.HANDLE
#
# ResetEvent = kernel32.ResetEvent
# ResetEvent.argtypes = (wintypes.HANDLE,)
# ResetEvent.restype = wintypes.BOOL
#
# WaitForSingleObject = kernel32.WaitForSingleObject
# WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
# WaitForSingleObject.restype = wintypes.DWORD
#
# CreateFile = kernel32.CreateFileA
# CreateFile.argtypes = (wintypes.LPCSTR, wintypes.DWORD, wintypes.DWORD, LPSECURITY_ATTRIBUTES,
#                        wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE)
# CreateFile.restype = wintypes.HANDLE
#
# ReadFile = kernel32.ReadFile
# ReadFile.argtypes = (wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD, wintypes.LPDWORD,
#                      LPOVERLAPPED)
# ReadFile.restype = wintypes.BOOL
#
# WriteFile = kernel32.WriteFile
# WriteFile.argtypes = (wintypes.HANDLE, wintypes.LPCVOID, wintypes.DWORD, wintypes.PDWORD,
#                       LPOVERLAPPED)
# WriteFile.restype = wintypes.BOOL
#
# # ADVAPI32.DLL
# advapi32 = ctypes.windll.advapi32
#
# GetUserName = advapi32.GetUserNameA
# GetUserName.argtypes = (wintypes.LPSTR, wintypes.LPDWORD)
# GetUserName.restype = wintypes.BOOL
#
# LogonUser = advapi32.LogonUserA
# LogonUser.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, wintypes.LPCSTR, wintypes.DWORD,
#                       wintypes.DWORD, wintypes.PHANDLE)
# LogonUser.restype = wintypes.BOOL
#
# ImpersonateLoggedOnUser = advapi32.ImpersonateLoggedOnUser
# ImpersonateLoggedOnUser.argtypes = (wintypes.HANDLE,)
# ImpersonateLoggedOnUser.restype = wintypes.BOOL
#
# RevertToSelf = advapi32.RevertToSelf
# RevertToSelf.restype = wintypes.BOOL
#
# OpenProcessToken = advapi32.OpenProcessToken
# OpenProcessToken.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.PHANDLE)
# OpenProcessToken.restype = wintypes.BOOL
#
# GetTokenInformation = advapi32.GetTokenInformation
# GetTokenInformation.argtypes = (wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD,
#                                 wintypes.PDWORD)
# GetTokenInformation.restype = wintypes.BOOL
#
# InitiateSystemShutdownEx = advapi32.InitiateSystemShutdownExA
# InitiateSystemShutdownEx.argtypes = (wintypes.LPSTR, wintypes.LPSTR, wintypes.DWORD, wintypes.BOOL,
#                                      wintypes.BOOL, wintypes.DWORD)
# InitiateSystemShutdownEx.restype = wintypes.BOOL
#
# LookupPrivilegeValue = advapi32.LookupPrivilegeValueA
# LookupPrivilegeValue.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, PLUID)
#
# ConvertSidToStringSid = advapi32.ConvertSidToStringSidA
# ConvertSidToStringSid.argtypes = (PSID, ctypes.POINTER(wintypes.LPSTR))
# ConvertSidToStringSid.restype = wintypes.BOOL
#
# ConvertStringSidToSid = advapi32.ConvertStringSidToSidA
# ConvertStringSidToSid.argtypes = (wintypes.LPCSTR, ctypes.POINTER(PSID))
# ConvertStringSidToSid.restype = wintypes.BOOL
#
# AdjustTokenPrivileges = advapi32.AdjustTokenPrivileges
# AdjustTokenPrivileges.argtypes = (wintypes.HANDLE, wintypes.BOOL, PTOKEN_PRIVILEGES, wintypes.DWORD,
#                                   PTOKEN_PRIVILEGES, wintypes.PDWORD)
# AdjustTokenPrivileges.restype = wintypes.BOOL
#
# LookupAccountName = advapi32.LookupAccountNameA
# LookupAccountName.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, PSID, wintypes.LPDWORD,
#                               wintypes.LPSTR, wintypes.LPDWORD, ctypes.POINTER(ctypes.c_uint))
# LookupAccountName.restype = wintypes.BOOL
#
# LookupAccountSid = advapi32.LookupAccountSidA
# LookupAccountSid.argtypes = (wintypes.LPCSTR, PSID, wintypes.LPSTR, wintypes.LPDWORD,
#                              wintypes.LPSTR, wintypes.LPDWORD, ctypes.POINTER(ctypes.c_uint))
# LookupAccountSid.restype = wintypes.BOOL
#
# CreateProcessAsUser = advapi32.CreateProcessAsUserA
# CreateProcessAsUser.argtypes = (wintypes.HANDLE,
#                                 wintypes.LPCSTR,
#                                 wintypes.LPSTR,
#                                 LPSECURITY_ATTRIBUTES,
#                                 LPSECURITY_ATTRIBUTES,
#                                 wintypes.BOOL,
#                                 wintypes.DWORD,
#                                 wintypes.LPVOID,
#                                 wintypes.LPCSTR,
#                                 LPSTARTUPINFO,
#                                 LPPROCESS_INFORMATION)
# CreateProcessAsUser.restype = wintypes.BOOL
#
# DuplicateTokenEx = advapi32.DuplicateTokenEx
# DuplicateTokenEx.argtypes = (wintypes.HANDLE, wintypes.DWORD, LPSECURITY_ATTRIBUTES, ctypes.c_int,
#                              ctypes.c_int, wintypes.PHANDLE)
# DuplicateTokenEx.restype = wintypes.BOOL
#
# SetTokenInformation = advapi32.SetTokenInformation
# SetTokenInformation.argtypes = (wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD)
# SetTokenInformation.restype = wintypes.BOOL
#
# # USERENV.DLL
# userenv = ctypes.windll.Userenv
#
# CreateEnvironmentBlock = userenv.CreateEnvironmentBlock
# CreateEnvironmentBlock.argtypes = (ctypes.POINTER(wintypes.LPVOID), wintypes.HANDLE, wintypes.BOOL)
# CreateEnvironmentBlock.restype = wintypes.BOOL
#
# # MPR.DLL
# mpr = ctypes.windll.mpr
#
# WNetGetConnection = mpr.WNetGetConnectionA
# WNetGetConnection.argtypes = (wintypes.LPCSTR, wintypes.LPSTR, wintypes.LPDWORD)
# WNetGetConnection.restype = wintypes.DWORD
#
# WNetCancelConnection2 = mpr.WNetCancelConnection2A
# WNetCancelConnection2.argtypes = (wintypes.LPCSTR, wintypes.DWORD, wintypes.BOOL)
# WNetCancelConnection2.restype = wintypes.DWORD
#
# WNetGetUser = mpr.WNetGetUserA
# WNetGetUser.argtypes = (wintypes.LPCSTR, wintypes.LPSTR, wintypes.LPDWORD)
# WNetGetUser.restype = wintypes.DWORD
#
# WNetGetUniversalName = mpr.WNetGetUniversalNameA
# WNetGetUniversalName.argtypes = (wintypes.LPCSTR, wintypes.DWORD, wintypes.LPVOID, wintypes.LPDWORD)
# WNetGetUniversalName.restype = wintypes.DWORD
#
# WNetAddConnection2 = mpr.WNetAddConnection2A
# WNetAddConnection2.argtypes = (LPNETRESOURCE, wintypes.LPCSTR, wintypes.LPCSTR, wintypes.DWORD)
# WNetAddConnection2.restype = wintypes.DWORD
#
# WNetGetResourceInformation = mpr.WNetGetResourceInformationA
# WNetGetResourceInformation.argtypes = (LPNETRESOURCE, wintypes.LPVOID, wintypes.LPDWORD,
#                                        ctypes.POINTER(wintypes.LPSTR))
# WNetGetResourceInformation.restype = wintypes.DWORD
#
#
# # WTSAPI32.DLL
# wtsapi32 = ctypes.windll.Wtsapi32
#
# WTSQueryUserToken = wtsapi32.WTSQueryUserToken
# WTSQueryUserToken.argtypes = (wintypes.ULONG, wintypes.PHANDLE)
# WTSQueryUserToken.restype = wintypes.BOOL
#
# WTSEnumerateSessions = wtsapi32.WTSEnumerateSessionsA
# WTSEnumerateSessions.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD,
#                                  ctypes.POINTER(PWTS_SESSION_INFO), ctypes.POINTER(wintypes.DWORD))
# WTSEnumerateSessions.restype = wintypes.BOOL
#
# WTSEnumerateProcesses = wtsapi32.WTSEnumerateProcessesA
# WTSEnumerateProcesses.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD,
#                                   ctypes.POINTER(PWTS_PROCESS_INFO), ctypes.POINTER(wintypes.DWORD))
# WTSEnumerateProcesses.restype = wintypes.BOOL
#
# WTSFreeMemory = wtsapi32.WTSFreeMemory
# WTSFreeMemory.argtypes = (wintypes.LPVOID,)
