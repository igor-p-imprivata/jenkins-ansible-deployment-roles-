# core.py
import winreg
import atexit
from enum import IntEnum, IntFlag
from collections import deque
from zeus_utils import ior_iterable, SingletonMeta
from .utils import normalize_path


def get(*path, key_flag=0):
    return registry.get(*path, key_flag=key_flag)


class RegistryKeyFlags(IntFlag):
    WOW64_64_KEY = winreg.KEY_WOW64_64KEY
    WOW64_32_KEY = winreg.KEY_WOW64_32KEY


class RegistryDataTypes(IntEnum):
    BINARY = winreg.REG_BINARY
    DWORD = winreg.REG_DWORD
    LE_DWORD = winreg.REG_DWORD_LITTLE_ENDIAN
    BE_DWORD = winreg.REG_DWORD_BIG_ENDIAN
    EXPAND_SZ = winreg.REG_EXPAND_SZ
    LINK = winreg.REG_LINK
    MULTI_SZ = winreg.REG_MULTI_SZ
    NONE = winreg.REG_NONE
    QWORD = winreg.REG_QWORD
    LE_QWORD = winreg.REG_QWORD_LITTLE_ENDIAN
    SZ = winreg.REG_SZ
    RESOURCE_LIST = winreg.REG_RESOURCE_LIST
    RESOURCE_REQUIREMENTS_LIST = winreg.REG_RESOURCE_REQUIREMENTS_LIST


class RegistryAccessRights(IntFlag):
    ALL_ACCESS = winreg.KEY_ALL_ACCESS
    WRITE = winreg.KEY_WRITE
    READ = winreg.KEY_READ
    EXECUTE = winreg.KEY_EXECUTE
    QUERY_VALUE = winreg.KEY_QUERY_VALUE
    SET_VALUE = winreg.KEY_SET_VALUE
    CREATE_SUB_KEY = winreg.KEY_CREATE_SUB_KEY
    ENUMERATE_SUB_KEYS = winreg.KEY_ENUMERATE_SUB_KEYS
    NOTIFY = winreg.KEY_NOTIFY
    CREATE_LINK = winreg.KEY_CREATE_LINK


class RegistryObject:
    def __init__(self, name, parent=None):
        self.name = name
        self.parent = parent
        self._path = None

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    @property
    def path(self):
        if self._path is None:
            ancestors = deque()
            current_node = self

            while current_node is not None:
                ancestors.appendleft(current_node.name)
                current_node = current_node.parent

            self._path = '\\'.join(ancestors)

        return self._path


class RegistryValue(RegistryObject):
    def __init__(self, name, value, data_type, parent):
        super(RegistryValue, self).__init__(name=name, parent=parent)
        self._value = value
        self.data_type = data_type

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", data_type={self.data_type.name})'

    def __hash__(self):
        return hash(f'{self.name}{self._value}')

    @property
    def value(self):
        return self.get()

    @value.setter
    def value(self, value):
        self.set(value)

    def set(self, value):
        winreg.SetValueEx(self.name, self.data_type.value, value)
        self.update()

    def get(self):
        return self._value

    def update(self):
        self._value, _ = winreg.QueryValueEx(self.parent.handle, self.name)


class RegistryKey(RegistryObject):
    def __init__(self, name, handle, parent=None, access=None, key_flag=None):
        super(RegistryKey, self).__init__(name=name, parent=parent)
        self.handle = handle
        self._access = None
        self.key_flag = key_flag or 0
        self.next_sibling = None
        self.previous_sibling = None
        self._values = {}
        self._enumerated_values = False
        self._children = {}
        self._enumerated_children = False

        if access is not None:
            self.access = access

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    def __getattr__(self, item):
        self.ensure_children()

        try:
            return self._children[item.lower()]
        except KeyError:
            raise AttributeError(f"'{self.__class__.__name__}' instance has no attribute '{item}'")

    def __getitem__(self, item):
        try:
            item = item.lower()
        except AttributeError:
            raise TypeError

        self.ensure_children()
        return self._children[item]

    def __iter__(self):
        self.ensure_children()

        for child_key in self._children.values():
            yield child_key
            yield from child_key

    @property
    def access(self):
        return RegistryAccessRights(self._access)

    @access.setter
    def access(self, value):
        if value not in RegistryAccessRights:
            value = RegistryAccessRights(value)

        self._access = value.value

    @property
    def children(self):
        self.ensure_children()
        return tuple(self._children.values())

    @property
    def values(self):
        self.ensure_values()
        return tuple(self._values.values())

    @property
    def reflection_enabled(self):
        return not winreg.QueryReflectionKey(self.handle)

    def close(self):
        for child in self._children.values():
            child.close()

        if self.handle is not None:
            try:
                winreg.CloseKey(self.handle)
            except TypeError:
                pass

            self.handle = None

        self._children.clear()
        self._values.clear()

    def add_access_right(self, access_right):
        if access_right not in RegistryAccessRights:
            access_right = RegistryAccessRights(access_right)

        if not self._access & access_right:
            if self.parent is None:
                raise RuntimeError()

            self.close()
            self._access |= access_right
            self.handle = self.parent.get_child_handle(self.name, self._access)

    def has_access_right(self, access_right):
        if access_right not in RegistryAccessRights:
            access_right = RegistryAccessRights(access_right)

        return (self._access & access_right) > 0

    def get_child_handle(self, name, access):
        return winreg.OpenKeyEx(self.handle, name, 0, self.key_flag + access)

    def enumerate_values(self):
        index = 0

        while True:
            try:
                result = winreg.EnumValue(self.handle, index)
            except OSError:
                break

            name, value, dtype = result

            if name in self._values:
                child_value = self._values[name]
                child_value.update()

            else:
                data_type = RegistryDataTypes(dtype)
                self._values[name.lower()] = RegistryValue(name, value, data_type, parent=self)

            index += 1

    def ensure_values(self):
        if not self._enumerated_values:
            self.enumerate_values()
            self._enumerated_values = True

    def set_value(self, name, data_type, value):
        if data_type not in RegistryDataTypes:
            data_type = RegistryDataTypes(data_type)

        winreg.SetValueEx(self.handle, name, 0, data_type, value)
        self.enumerate_values()
        return self.get_value(name)

    def enumerate_children(self):
        index = 0
        previous_child = None

        while True:
            try:
                name = winreg.EnumKey(self.handle, index)
            except OSError:
                break

            access_rights = [winreg.KEY_READ, winreg.KEY_SET_VALUE]
            access = ior_iterable(access_rights)

            while access:
                try:
                    child_key = self.add_child(name, access)
                except PermissionError:
                    access &= ~access_rights.pop()
                else:
                    if previous_child is not None and child_key is not None:
                        previous_child.next_sibling = child_key
                        child_key.previous_sibling = previous_child

                    previous_child = child_key
                    break

            index += 1

    def ensure_children(self):
        if not self._enumerated_children:
            self.enumerate_children()
            self._enumerated_children = True

    def add_child(self, name, access):
        handle = self.get_child_handle(name, access)
        child_key = RegistryKey(name, handle, parent=self, access=access, key_flag=self.key_flag)
        self._children[name.lower()] = child_key
        return child_key

    def clear_values(self):
        self._values.clear()
        self._enumerated_values = False

    def clear_children(self):
        self._children.clear()
        self._enumerated_children = False

    def clear(self):
        self.clear_values()
        self.clear_children()

    def create_key(self, name):
        winreg.CreateKey(self.handle, name)
        self.clear_children()
        return self.get_key(name)

    def delete_key(self, name):
        winreg.DeleteKey(self.handle, name)
        self.clear_children()

    def create_value(self, name, data_type, value):
        if not self.has_access_right(RegistryAccessRights.SET_VALUE):
            self.add_access_right(RegistryAccessRights.SET_VALUE)

        if data_type not in RegistryDataTypes:
            data_type = RegistryDataTypes(data_type)

        winreg.SetValueEx(self.handle, name, 0, data_type.value, value)
        self.clear_values()
        return self.get_value(name)

    def ensure_value(self, name, data_type, value):
        if data_type not in RegistryDataTypes:
            data_type = RegistryDataTypes(data_type)

        modified = False

        reg_val = self.get_value(name)

        if reg_val is None:
            self.create_value(name, data_type=data_type, value=value)
            modified = True

        elif reg_val.get() != value:
            self.set_value(name, data_type=data_type, value=value)
            modified = True

        return modified

    def delete_value(self, name):
        winreg.DeleteValue(self.handle, name)
        self.clear_values()

    def get_value(self, name):
        self.ensure_values()
        return self._values.get(name.lower())

    def get_values(self):
        self.ensure_values()
        return {value.name: value.value for value in self._values.values()}

    def get_key(self, name):
        self.ensure_children()
        return self._children.get(name)

    def get(self, *path, key_flag=0):
        current_key_flag = self.key_flag

        self.key_flag = key_flag
        current_key = self

        path_parts = normalize_path(*path, func=lambda part: part.lower())

        if self.key_flag != winreg.KEY_WOW64_64KEY and 'wow6432node' in path_parts:
            self.key_flag = winreg.KEY_WOW64_64KEY

        if current_key_flag != self.key_flag:
            self.clear()

        last_part = path_parts.pop()

        for key_name in path_parts:
            current_key = current_key[key_name]

        try:
            ret_val = current_key[last_part]
        except KeyError:
            ret_val = current_key.get_value(last_part)

        if ret_val is None:
            raise KeyError("'{}'".format(last_part))

        return ret_val


class RegistryRoot(RegistryKey, metaclass=SingletonMeta):
    def __init__(self):
        super(RegistryRoot, self).__init__(name='Computer', handle=None)
        self.root_key_names = (
            'HKEY_CLASSES_ROOT',
            'HKEY_CURRENT_USER',
            'HKEY_LOCAL_MACHINE',
            'HKEY_USERS',
            'HKEY_CURRENT_CONFIG'
        )
        self._access = winreg.KEY_READ | winreg.KEY_SET_VALUE
        atexit.register(self.close)

    def get_child_handle(self, name, access=None):
        return getattr(winreg, name)

    def enumerate_children(self):
        for root_key_name in self.root_key_names:
            self.add_child(root_key_name, self._access)


registry = RegistryRoot()
