# utils.py


def normalize_path(*parts, sep='\\', func=None):
    path = []

    for part in parts:
        new_parts = part.split(sep) if sep in part else [part]

        if func is not None:
            new_parts = list(map(func, new_parts))

        path.extend(new_parts)

    return path
