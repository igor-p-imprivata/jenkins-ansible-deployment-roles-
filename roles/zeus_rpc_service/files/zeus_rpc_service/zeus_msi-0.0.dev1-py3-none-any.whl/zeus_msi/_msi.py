# _msi.py
import ctypes
from ctypes import wintypes

MAX_GUID_CHARS = 38
MAX_FEATURE_CHARS = 38

MSI_PRODUCT_FEATURE_BUF_SIZE = 39

IDCANCEL = 2

MSIHANDLE = ctypes.c_ulong

MSIDBOPEN_READONLY = wintypes.LPCSTR(0)
MSIDBOPEN_TRANSACT = wintypes.LPCSTR(1)
MSIDBOPEN_DIRECT = wintypes.LPCSTR(2)
MSIDBOPEN_CREATE = wintypes.LPCSTR(3)
MSIDBOPEN_CREATEDIRECT = wintypes.LPCSTR(4)

MSICOLINFO_NAMES = 0
MSICOLINFO_TYPES = 1

MSI_NULL_INTEGER = 0x80000000

msi = ctypes.windll.msi

MsiEnumProducts = msi.MsiEnumProductsA
MsiEnumProducts.argtypes = (wintypes.DWORD, wintypes.LPSTR)
MsiEnumProducts.restype = wintypes.UINT

MsiEnumProductsEx = msi.MsiEnumProductsExA
MsiEnumProductsEx.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, wintypes.DWORD, wintypes.DWORD,
                              wintypes.LPSTR, wintypes.LPDWORD, wintypes.LPSTR, wintypes.LPDWORD)
MsiEnumProductsEx.restype = wintypes.UINT

MsiEnumFeatures = msi.MsiEnumFeaturesA
MsiEnumFeatures.argtypes = (wintypes.LPCSTR, wintypes.DWORD, wintypes.LPSTR, wintypes.LPSTR)
MsiEnumFeatures.restype = wintypes.UINT

MsiGetProductInfo = msi.MsiGetProductInfoA
MsiGetProductInfo.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, wintypes.LPSTR, wintypes.LPDWORD)
MsiGetProductInfo.restype = wintypes.UINT

MsiEnableLog = msi.MsiEnableLogA
MsiEnableLog.argtypes = (wintypes.DWORD, wintypes.LPCSTR, wintypes.DWORD)
MsiEnableLog.restype = wintypes.UINT

MsiInstallProduct = msi.MsiInstallProductA
MsiInstallProduct.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR)
MsiInstallProduct.restype = wintypes.UINT

INSTALLUI_HANDLER = ctypes.WINFUNCTYPE(ctypes.c_int, wintypes.LPVOID, wintypes.UINT,
                                       wintypes.LPCSTR)

MsiSetInternalUI = msi.MsiSetInternalUI
MsiSetInternalUI.argtypes = (ctypes.c_int, ctypes.POINTER(wintypes.HWND))
MsiSetInternalUI.restype = ctypes.c_int

MsiSetExternalUI = msi.MsiSetExternalUIA
MsiSetExternalUI.argtypes = (INSTALLUI_HANDLER, wintypes.DWORD, wintypes.LPVOID)

MsiOpenProduct = msi.MsiOpenProductA
MsiOpenProduct.argtypes = (wintypes.LPCSTR, ctypes.POINTER(MSIHANDLE))
MsiOpenProduct.restype = wintypes.UINT

MsiCloseHandle = msi.MsiCloseHandle
MsiCloseHandle.argtypes = (MSIHANDLE,)
MsiCloseHandle.restype = wintypes.UINT

MsiEnumComponents = msi.MsiEnumComponentsA
MsiEnumComponents.argtypes = (wintypes.DWORD, wintypes.LPSTR)
MsiEnumComponents.restype = wintypes.UINT

MsiEnumComponentsEx = msi.MsiEnumComponentsExA
MsiEnumComponentsEx.argtypes = (wintypes.LPCSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPSTR,
                                wintypes.LPDWORD, wintypes.LPSTR, wintypes.LPDWORD)
MsiEnumComponentsEx.restype = wintypes.UINT

MsiGetComponentPath = msi.MsiGetComponentPathA
MsiGetComponentPath.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, wintypes.LPSTR, wintypes.LPDWORD)
MsiGetComponentPath.restype = ctypes.c_int

MsiGetProductCode = msi.MsiGetProductCodeA
MsiGetProductCode.argtypes = (wintypes.LPCSTR, wintypes.LPSTR)
MsiGetProductCode.restype = wintypes.UINT

MsiOpenDatabase = msi.MsiOpenDatabaseA
MsiOpenDatabase.argtypes = (wintypes.LPCSTR, wintypes.LPCSTR, ctypes.POINTER(MSIHANDLE))
MsiOpenDatabase.restype = wintypes.UINT

MsiDatabaseOpenView = msi.MsiDatabaseOpenViewA
MsiDatabaseOpenView.argtypes = (MSIHANDLE, wintypes.LPCSTR, ctypes.POINTER(MSIHANDLE))
MsiDatabaseOpenView.restype = wintypes.UINT

MsiViewExecute = msi.MsiViewExecute
MsiViewExecute.argtypes = (MSIHANDLE, MSIHANDLE)
MsiViewExecute.restype = wintypes.UINT

MsiViewFetch = msi.MsiViewFetch
MsiViewFetch.argtypes = (MSIHANDLE, ctypes.POINTER(MSIHANDLE))
MsiViewFetch.restype = wintypes.UINT

MsiRecordGetString = msi.MsiRecordGetStringA
MsiRecordGetString.argtypes = (MSIHANDLE, wintypes.UINT, wintypes.LPSTR, wintypes.LPDWORD)
MsiRecordGetString.restype = wintypes.UINT

MsiViewClose = msi.MsiViewClose
MsiViewClose.argtypes = (MSIHANDLE,)
MsiViewClose.restype = wintypes.UINT

MsiRecordGetFieldCount = msi.MsiRecordGetFieldCount
MsiRecordGetFieldCount.argtypes = (MSIHANDLE,)
MsiRecordGetFieldCount.restype = wintypes.UINT

MsiRecordDataSize = msi.MsiRecordDataSize
MsiRecordDataSize.argtypes = (MSIHANDLE, wintypes.UINT)
MsiRecordDataSize.restype = wintypes.UINT

MsiRecordIsNull = msi.MsiRecordIsNull
MsiRecordIsNull.argtypes = (MSIHANDLE, wintypes.UINT)
MsiRecordIsNull.restype = wintypes.BOOL

MsiRecordGetInteger = msi.MsiRecordGetInteger
MsiRecordGetInteger.argtypes = (MSIHANDLE, wintypes.UINT)
MsiRecordGetInteger.restype = ctypes.c_int

MsiViewGetColumnInfo = msi.MsiViewGetColumnInfo
MsiViewGetColumnInfo.argtypes = (MSIHANDLE, ctypes.c_int, ctypes.POINTER(MSIHANDLE))
MsiViewGetColumnInfo.restype = wintypes.UINT

MsiGetSummaryInformation = msi.MsiGetSummaryInformationA
MsiGetSummaryInformation.argtypes = (MSIHANDLE, wintypes.LPCSTR, wintypes.UINT,
                                     ctypes.POINTER(MSIHANDLE))
MsiGetSummaryInformation.restype = wintypes.UINT
