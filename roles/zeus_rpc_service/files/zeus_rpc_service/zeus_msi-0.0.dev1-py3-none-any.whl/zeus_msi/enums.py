# enums.py
from enum import Enum, IntEnum, IntFlag
from functools import reduce
from operator import ior


class MsiInstallProperties(Enum):
    HELPLINK = 'HelpLink'
    HELPTELEPHONE = 'HelpTelephone'
    INSTALLDATE = 'InstallDate'
    INSTALLEDLANGUAGE = 'InstalledLanguage'
    INSTALLEDPRODUCTNAME = 'InstalledProductName'
    INSTALLLOCATION = 'InstallLocation'
    INSTALLSOURCE = 'InstallSource'
    LOCALPACKAGE = 'LocalPackage'
    PUBLISHER = 'Publisher'
    URLINFOABOUT = 'URLInfoAbout'
    URLUPDATEINFO = 'URLUpdateInfo'
    VERSIONMINOR = 'VersionMinor'
    VERSIONMAJOR = 'VersionMajor'
    VERSIONSTRING = 'VersionString'
    TRANSFORMS = 'Transforms'
    LANGUAGE = 'Language'
    PRODUCTNAME = 'ProductName'
    ASSIGNMENTTYPE = 'AssignmentType'
    INSTANCETYPE = 'InstanceType'
    PACKAGECODE = 'PackageCode'
    VERSION = 'Version'
    PRODUCTICON = 'ProductIcon'
    PACKAGENAME = 'PackageName'
    AUTHORIZED_LUA_APP = 'AuthorizedLUAApp'
    LASTUSEDSOURCE = 'LastUsedSource'
    LASTUSEDTYPE = 'LastUsedType'
    MEDIAPACKAGEPATH = 'MediaPackagePath'
    DISKPROMPT = 'DiskPrompt'


class MsiInstallMessages(IntFlag):
    FATALEXIT = 0x00000000  # premature termination, possibly fatal OOM
    ERROR = 0x01000000  # formatted error message
    WARNING = 0x02000000  # formatted warning message
    USER = 0x03000000  # user request message
    INFO = 0x04000000  # informative message for log
    FILESINUSE = 0x05000000  # list of files in use that need to be replaced
    RESOLVESOURCE = 0x06000000  # request to determine a valid source location
    OUTOFDISKSPACE = 0x07000000  # insufficient disk space message
    ACTIONSTART = 0x08000000  # start of action: action name & description
    ACTIONDATA = 0x09000000  # formatted data associated with individual action item
    PROGRESS = 0x0A000000  # progress gauge info: units so far, total
    COMMONDATA = 0x0B000000  # product info for dialog: language Id, dialog caption
    INITIALIZE = 0x0C000000  # sent prior to UI initialization, no string data
    TERMINATE = 0x0D000000  # sent after UI termination, no string data
    SHOWDIALOG = 0x0E000000
    PERFORMANCE = 0x0F000000  # log only, to log performance number like action time
    RMFILESINUSE = 0x19000000  # the list of apps that the user can request Restart Manager to shut down and restart
    INSTALLSTART = 0x1A000000  # sent prior to server-side install of a product
    INSTALLEND = 0x1B000000  # sent after server-side install


class MsiInstallLogAttributes(IntEnum):
    APPEND = 1
    FLUSH_EACH_LINE = 2


class MsiInstallLogModes(IntFlag):
    FATALEXIT = 1 << (MsiInstallMessages.FATALEXIT >> 24)
    ERROR = 1 << (MsiInstallMessages.ERROR >> 24)
    WARNING = 1 << (MsiInstallMessages.WARNING >> 24)
    USER = 1 << (MsiInstallMessages.USER >> 24)
    INFO = 1 << (MsiInstallMessages.INFO >> 24)
    RESOLVESOURCE = 1 << (MsiInstallMessages.RESOLVESOURCE >> 24)
    OUTOFDISKSPACE = 1 << (MsiInstallMessages.OUTOFDISKSPACE >> 24)
    ACTIONSTART = 1 << (MsiInstallMessages.ACTIONSTART >> 24)
    ACTIONDATA = 1 << (MsiInstallMessages.ACTIONDATA >> 24)
    COMMONDATA = 1 << (MsiInstallMessages.COMMONDATA >> 24)
    PROPERTYDUMP = 1 << (MsiInstallMessages.PROGRESS >> 24)
    VERBOSE = 1 << (MsiInstallMessages.INITIALIZE >> 24)
    EXTRADEBUG = 1 << (MsiInstallMessages.TERMINATE >> 24)
    LOGONLYONERROR = 1 << (MsiInstallMessages.SHOWDIALOG >> 24)
    LOGPERFORMANCE = 1 << (MsiInstallMessages.PERFORMANCE >> 24)
    PROGRESS = 1 << (MsiInstallMessages.PROGRESS >> 24)
    INITIALIZE = 1 << (MsiInstallMessages.INITIALIZE >> 24)
    TERMINATE = 1 << (MsiInstallMessages.TERMINATE >> 24)
    SHOWDIALOG = 1 << (MsiInstallMessages.SHOWDIALOG >> 24)
    FILESINUSE = 1 << (MsiInstallMessages.FILESINUSE >> 24)
    RMFILESINUSE = 1 << (MsiInstallMessages.RMFILESINUSE >> 24)
    INSTALLSTART = 1 << (MsiInstallMessages.INSTALLSTART >> 24)
    INSTALLEND = 1 << (MsiInstallMessages.INSTALLEND >> 24)


INSTALLLOGMODE_ALL = reduce(ior, [mode for mode in MsiInstallLogModes])


class MsiInstallContext(IntFlag):
    USER_MANAGED = 1
    USER_UNMANAGED = 2
    MACHINE = 4
    ALL = 7


class MsiCommandLineOptions(Enum):
    ALL_USERS = 'ALLUSERS=1'
    PER_USER = 'ALLUSERS=""'
    REMOVE_ALL = 'REMOVE=ALL'
    SUPPRESS_REBOOT = 'REBOOT=ReallySuppress'


class MsiInstallUILevels(IntFlag):
    NOCHANGE = 0    # UI level is unchanged
    DEFAULT = 1    # default UI is used
    NONE = 2    # completely silent installation
    BASIC = 3    # simple progress and error handling
    REDUCED = 4    # authored UI, wizard dialogs suppressed
    FULL = 5    # authored UI with wizards, progress, errors
    ENDDIALOG = 0x80  # display success/failure dialog at end of install
    PROGRESSONLY = 0x40  # display only progress dialog
    HIDECANCEL = 0x20  # do not display the cancel button in basic UI
    SOURCERESONLY = 0x100  # force display of source resolution even if quiet
    UACONLY = 0x200  # show UAC prompt even if quiet


class MsiInstallState(IntEnum):
    NOTUSED = -7
    BADCONFIG = -6
    INCOMPLETE = -5
    SOURCEABSENT = -4
    MOREDATA = -3
    INVALIDARG = -2
    UNKNOWN = -1
    BROKEN = 0
    ADVERTISED = 1
    REMOVED = 1
    ABSENT = 2
    LOCAL = 3
    SOURCE = 4
    DEFAULT = 5


class MsiColumnInfo(IntEnum):
    NAMES = 0
    TYPES = 1
