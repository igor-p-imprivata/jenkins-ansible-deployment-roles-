# core.py
import logging
import atexit
import ctypes
import time
from ctypes import wintypes
from datetime import date
from threading import Thread, Event
from zeus_utils import exhaust_iterator, find_by_attrs, findall_by_attrs, split_path, SingletonMeta
from zeus_win32_utils import raise_windows_error, get_current_user_sid, dirty_cast
from zeus_win32_utils.error_codes import (
    ERROR_SUCCESS, ERROR_UNKNOWN_PRODUCT, ERROR_NO_MORE_ITEMS, ERROR_MORE_DATA
)
from .enums import (
    MsiInstallProperties, MsiInstallLogModes, MsiInstallLogAttributes, MsiCommandLineOptions,
    MsiInstallContext, MsiInstallUILevels, MsiInstallMessages, MsiInstallState, MsiColumnInfo,
    INSTALLLOGMODE_ALL,
)
from ._msi import (
    MsiGetProductInfo, MsiEnumProductsEx, MsiEnableLog, MsiInstallProduct, MsiSetInternalUI,
    MsiSetExternalUI, MsiEnumFeatures, MsiOpenProduct, MsiCloseHandle,
    MsiGetComponentPath, MsiGetProductCode, MsiEnumComponentsEx, MsiOpenDatabase, MsiViewGetColumnInfo,
    MsiRecordGetFieldCount, MsiRecordDataSize, MsiRecordIsNull, MsiRecordGetInteger,
    MsiDatabaseOpenView, MsiViewExecute, MsiViewFetch, MsiRecordGetString, MsiViewClose, MsiGetSummaryInformation,
    MSIHANDLE, INSTALLUI_HANDLER, MAX_GUID_CHARS,
    MAX_FEATURE_CHARS, IDCANCEL, MSIDBOPEN_READONLY, MSI_NULL_INTEGER
)


logger = logging.getLogger(__name__)

RECORD_STRING_SIZE = 2048
COMPONENT_PATH_LENGTH = 1024


def enum_products(install_context=MsiInstallContext.ALL):
    return list(msi_exec.enum_products(install_context=install_context))


def iter_products():
    yield from msi_exec.iter_products()


def clear_products():
    msi_exec.clear_products()


def enable_log(log_file, mode=INSTALLLOGMODE_ALL, attributes=None):
    return msi_exec.enable_log(log_file, mode=mode, attributes=attributes)


def install(msi_path, command_line_options=None, start=True, wait=True, timeout=None):
    return msi_exec.install(msi_path, command_line_options=command_line_options, start=start,
                             wait=wait, timeout=timeout)


def remove(msi_path, command_line_options=None, start=True, wait=True, timeout=None):
    return msi_exec.uninstall(msi_path, command_line_options=command_line_options, start=start,
                              wait=wait, timeout=timeout)


uninstall = remove


def find_product(*, case_insensitive=True, sub_string=True, **attributes):
    return msi_exec.find(case_insensitive=case_insensitive, sub_string=sub_string, **attributes)


def findall_products(*, case_insensitive=True, sub_string=True, **attributes):
    return msi_exec.findall(case_insensitive=case_insensitive, sub_string=sub_string, **attributes)


class MsiObject:
    def __init__(self, msi, code):
        self.msi = msi
        self.code = code


class MsiComponent(MsiObject):
    def __init__(self, msi, code, product_code, name, directory, attributes, condition):
        super(MsiComponent, self).__init__(msi=msi, code=code)
        self.product_code = product_code
        self.name = name
        self.directory = directory
        self.attributes = attributes
        self.condition = condition
        self._path = None
        self._install_state = None

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}")'

    @property
    def path(self):
        self._get_path()
        return self._path

    @property
    def install_state(self):
        self._get_path()
        return self._install_state

    def _get_path(self):
        if self._path is None or self._install_state is None:
            buf = ctypes.create_string_buffer(COMPONENT_PATH_LENGTH)
            size = wintypes.DWORD(COMPONENT_PATH_LENGTH)

            ret = MsiGetComponentPath(
                self.product_code.encode('utf-8', 'strict'),
                self.code.encode('utf-8', 'strict'),
                buf,
                ctypes.byref(size)
            )

            self._install_state = MsiInstallState(ret)
            self._path = buf.value.decode('utf-8', 'strict')


class MsiDatabaseRecord:
    def __init__(self, handle):
        self._handle = handle

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        if self._handle is not None:
            MsiCloseHandle(self._handle)
            self._handle = None

    def get_field_count(self):
        return MsiRecordGetFieldCount(self._handle)

    def is_null(self, index):
        return bool(MsiRecordIsNull(self._handle, index))

    def get_string(self, index):
        size = wintypes.DWORD(RECORD_STRING_SIZE)
        buf = ctypes.create_string_buffer(size.value)
        MsiRecordGetString(self._handle, index, buf, ctypes.byref(size))
        return buf.value.decode('utf-8', 'strict')

    def get_integer(self, index):
        return MsiRecordGetInteger(self._handle, index)

    def get_field(self, index):
        if self.is_null(index):
            return None

        value = self.get_integer(index)
        # The MsiRecordGetInteger function returns MSI_NULL_INTEGER if the field is null or
        # if the field is a string that cannot be converted to an integer

        if value == MSI_NULL_INTEGER:
            value = self.get_string(index)

        return value


class MsiDatabaseField(MsiDatabaseRecord):
    def __init__(self, handle, col_info_names):
        super(MsiDatabaseField, self).__init__(handle=handle)
        self._col_info_names = col_info_names
        self._data = {}
        self._enumerated = False

    def items(self):
        if not self._enumerated:
            self.enumerate()

        for name, value in self._data.items():
            yield name, value

    def enumerate(self):
        for i in range(self.get_field_count()):
            name = self._col_info_names.get_string(i)
            self._data[name] = self.get_string(i)

        self._enumerated = True

    def to_dict(self):
        if not self._enumerated:
            self.enumerate()

        return dict(self._data)


class MsiDatabaseView:
    def __init__(self, handle, statement):
        self._handle = handle
        self._record_handle = None
        self._column_info_map = {}
        self.statement = statement
        atexit.register(self.close)

    def __iter__(self):
        ret = MsiViewFetch(self._handle, ctypes.byref(self._record_handle))
        col_info_names = self.get_column_info(MsiColumnInfo.NAMES)

        while ret != ERROR_NO_MORE_ITEMS:
            field = MsiDatabaseField(self._record_handle, col_info_names)
            field.enumerate()
            yield field

            ret = MsiViewFetch(self._handle, ctypes.byref(self._record_handle))

    def __enter__(self):
        self.execute()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def get_column_info(self, info_type):
        if info_type not in MsiColumnInfo:
            info_type = MsiColumnInfo(info_type)

        col_info = self._column_info_map.get(info_type)

        if col_info is None:
            h_col_info = MSIHANDLE()
            ret = MsiViewGetColumnInfo(self._handle, info_type.value, ctypes.byref(h_col_info))

            if ret != ERROR_SUCCESS:
                raise_windows_error(ret)

            self._column_info_map[info_type] = col_info = MsiDatabaseRecord(h_col_info)

        return col_info

    def close(self):
        if self._record_handle is not None:
            MsiCloseHandle(self._record_handle)
            self._record_handle = None

        for col_info in self._column_info_map.values():
            col_info.close()

        self._column_info_map.clear()

        if self._handle is not None:
            MsiViewClose(self._handle)
            self._handle = None

    def execute(self):
        if self._record_handle is None:
            record_handle = MSIHANDLE()
            ret = MsiViewExecute(self._handle, record_handle)

            if ret != ERROR_SUCCESS:
                raise_windows_error(ret)

            self._record_handle = record_handle


class MsiDatabase:
    def __init__(self, database_path, persist_mode=MSIDBOPEN_READONLY):
        self.database_path = database_path
        self.persist_mode = persist_mode
        self._handle = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        if self._handle is not None:
            MsiCloseHandle(self._handle)
            self._handle = None

    def open(self):
        if self._handle is None:
            handle = MSIHANDLE()
            db_path = self.database_path.encode('utf-8', 'strict')

            ret = MsiOpenDatabase(db_path, self.persist_mode, ctypes.byref(handle))

            if ret != ERROR_SUCCESS:
                raise_windows_error(ret)

            self._handle = handle
            atexit.register(self.close)

    def get_summary(self, max_updates=1):
        self.open()
        summary_info = MSIHANDLE()
        MsiGetSummaryInformation(self._handle, None, max_updates, ctypes.byref(summary_info))

    def open_view(self, statement):
        self.open()
        b_statement = statement.encode('utf-8', 'strict')
        view_handle = MSIHANDLE()
        ret = MsiDatabaseOpenView(self._handle, b_statement, ctypes.byref(view_handle))

        if ret != ERROR_SUCCESS:
            raise_windows_error(ret)

        return MsiDatabaseView(view_handle, statement)


class MsiProduct(MsiObject):
    DEFAULT_STRING_FIELDS = ('name', 'install_date', 'version_string')

    def __init__(self, msi, code, install_context):
        super(MsiProduct, self).__init__(msi=msi, code=code)
        # self._guid = guid
        self._ctx = install_context
        # self.msi_service = msi_service
        self._handle = None
        self._database = None
        self._enumerated = False
        self._components_enumerated = False
        self._open = False
        self._info_cache = {}
        self._components_by_code = {}

    def __repr__(self):
        return f'{self.__class__.__name__}(GUID="{self.guid}")'

    def __str__(self):
        return self.to_string()

    @property
    def guid(self):
        return self.code

    # code = guid

    @property
    def install_context(self):
        return MsiInstallContext(self._ctx)

    @property
    def installed_product_name(self):
        return self.get_info(MsiInstallProperties.INSTALLEDPRODUCTNAME)

    @property
    def product_name(self):
        return self.get_info(MsiInstallProperties.PRODUCTNAME)

    name = product_name

    @property
    def install_date(self):
        # format is YYYYMMDD
        date_str = self.get_info(MsiInstallProperties.INSTALLDATE)
        return date(year=int(date_str[:4]), month=int(date_str[4:6]), day=int(date_str[6:]))

    @property
    def version_string(self):
        return self.get_info(MsiInstallProperties.VERSIONSTRING)

    @property
    def version_tuple(self):
        version_string = self.get_info(MsiInstallProperties.VERSIONSTRING)
        return tuple(int(i) for i in version_string.split('.'))

    @property
    def version(self):
        return self.get_info(MsiInstallProperties.VERSION)

    @property
    def local_package(self):
        return self.get_info(MsiInstallProperties.LOCALPACKAGE)

    @property
    def package_code(self):
        return self.get_info(MsiInstallProperties.PACKAGECODE)

    @property
    def package_name(self):
        return self.get_info(MsiInstallProperties.PACKAGENAME)

    def validate(self):
        try:
            self.get_info(MsiInstallProperties.INSTALLEDPRODUCTNAME)
        except WindowsError:
            return False

        return True

    def add_component(self, component):
        self._components_by_code[component.code] = component

    def get_component_by_code(self, code):
        return self._components_by_code.get(code)

    def open_database(self, persist_mode=MSIDBOPEN_READONLY):
        if self._database is None:
            database = MsiDatabase(self.local_package, persist_mode)

            try:
                database.open()
            except OSError:
                pass
            else:
                self._database = database

        return self._database

    def enum_components(self):
        if not self._components_enumerated:
            self.open_database()

            if self._database is None:
                return

            with self._database:
                view = self._database.open_view('SELECT * FROM `Component`')

                with view:
                    for field in view:
                        data = field.to_dict()
                        component = MsiComponent(
                            msi=self.msi,
                            code=data['ComponentId'],
                            product_code=self.code,
                            name=data['Component'],
                            directory=data['Directory_'],
                            attributes=data['Attributes'],
                            condition=data['Condition']
                        )
                        self.add_component(component)

            self._components_enumerated = True

    def close_database(self):
        if self._database is not None:
            self._database.close()
            self._database = None

    def iter_components(self):
        self.enum_components()

        for component in self._components_by_code.values():
            yield component

    def find_component(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(
            self.iter_components(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def findall_components(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(
            self.iter_components(),
            case_insensitive=case_insensitive,
            sub_string=sub_string,
            attrs=attributes
        )

    def clear_info_cache(self):
        self._info_cache.clear()

    def get_info(self, attribute, converter=None):
        if attribute not in MsiInstallProperties:
            attribute = MsiInstallProperties(attribute)

        info = self._info_cache.get(attribute)

        if info is None:
            attr_arr = attribute.value.encode('utf-8', 'strict')
            n_bytes = wintypes.DWORD(0)
            product_code = self.code.encode('utf-8', 'strict')

            res = MsiGetProductInfo(
                product_code,
                attr_arr,
                None,
                ctypes.byref(n_bytes)
            )

            if res != ERROR_SUCCESS:

                if res == ERROR_UNKNOWN_PRODUCT:
                    return

                raise_windows_error(res)

            n_bytes.value += 1
            buf = ctypes.create_string_buffer(n_bytes.value)

            res = MsiGetProductInfo(
                product_code,
                attr_arr,
                buf,
                ctypes.byref(n_bytes)
            )

            if res != ERROR_SUCCESS:
                raise_windows_error(res)

            try:
                info = buf.value.decode('utf-8', 'strict')
            except UnicodeDecodeError:
                info = buf.value.decode('unicode_escape', 'strict')

            if converter is not None:
                info = converter(info)

        return info

    def enum_features(self):
        index = wintypes.DWORD(0)
        feature_buf = ctypes.create_string_buffer(MAX_FEATURE_CHARS + 1)
        parent_buf = ctypes.create_string_buffer(MAX_FEATURE_CHARS + 1)
        product_code = self.code.encode('utf-8', 'strict')

        while True:
            ret = MsiEnumFeatures(product_code, index, feature_buf, parent_buf)

            if ret != ERROR_SUCCESS:
                break

            yield feature_buf.value.decode('utf-8', 'strict')

            index.value += 1

    def ensure_features(self):
        if not self._enumerated:
            self.enum_features()

    def ensure_opened(self):
        if not self._open:
            self._handle = MSIHANDLE()

            ret = MsiOpenProduct(self.code.encode('utf-8', 'strict'), ctypes.byref(self._handle))

            if ret != ERROR_SUCCESS:
                raise_windows_error(ret)

            atexit.register(self.ensure_closed)
            self._open = True

    def ensure_closed(self):
        if self._open:
            MsiCloseHandle(self._handle)
            self._handle = None
            self._open = False

    def uninstall(self, command_line_options=None, start=True, wait=True, raise_for_status=True,
                  timeout=None):
        return self.msi.uninstall(
            self.local_package,
            command_line_options=command_line_options, start=start,
            wait=wait,
            raise_for_status=raise_for_status,
            timeout=timeout
        )

    def dump_install_properties(self):
        return {member.name: self.get_info(member) for member in MsiInstallProperties}

    def to_string(self, fields=None):
        fields = fields or self.DEFAULT_STRING_FIELDS
        lines = [f'{self.__class__.__name__}:']

        for field in fields:
            if isinstance(field, tuple):
                field, *extra = field
                converter = extra[0] if extra else None

            else:
                converter = None

            if field in MsiInstallProperties:
                value = self.get_info(field, converter=converter)

            else:
                value = getattr(self, field)

                if converter is not None:
                    value = converter(value)

            lines.append(f'\t{str(field)} = {str(value)}')

        return '\n'.join(lines)


class MsiInstallProcess:
    def __init__(self, msi_path, cmd_line):
        self.msi_path = msi_path
        self._cmd_line = cmd_line
        self._msi_file = None
        self._thread = None
        self._cancel_event = Event()
        self._done_event = Event()
        self._callback = None
        self._context = None
        self._log_mode = None
        self._callback_set = False
        self._convert_context = None
        self._start_time = None
        self._end_time = None
        self._log_messages = []
        self.return_code = None

    def __repr__(self):
        return f'{self.__class__.__name__}(msi_file="{self.msi_file}")'

    @property
    def command_line(self):
        return self._cmd_line

    @property
    def msi_file(self):
        if self._msi_file is None:
            self._msi_file = split_path(self.msi_path)[-1]

        return self._msi_file

    @property
    def total_time(self):
        if not all((self._start_time, self._end_time)):
            return

        return self._end_time - self._start_time

    @property
    def log(self):
        return '\n'.join(self._log_messages)

    def is_running(self):
        return self._thread is not None and self._thread.is_alive() and self.return_code is not None

    def _run(self):
        b_msi_path = self.msi_path.encode('utf-8', 'strict')
        b_cmd_line = self._cmd_line.encode('utf-8', 'strict')
        self._start_time = time.time()
        self.return_code = MsiInstallProduct(b_msi_path, b_cmd_line)
        self._end_time = time.time()
        self._done_event.set()

    def _default_callback(self, context, message_type, message):
        msg_info = {}
        message_type = MsiInstallMessages(message_type).name

        if message_type is not None:
            msg_info['type'] = message_type

        if message is not None:
            msg_info['message'] = message.decode('utf-8', 'strict')

        if context is not None:
            msg_info['context'] = self._convert_context(context)

        # msg_info_str = ', '.join(f'{k}: {v}' for k, v in msg_info.items())
        # logger.info(f'{repr(self)}: {msg_info_str}')
        self._log_messages.append(', '.join(f'{k}: {v}' for k, v in msg_info.items()))

        if self._cancel_event.is_set():
            return IDCANCEL

        return 0

    def _ensure_callback(self):
        if not self._callback_set:
            self.set_callback(self._default_callback)

    def _cleanup(self):
        self._thread.join()
        self._thread = None

    def set_callback(self, callback, log_mode=INSTALLLOGMODE_ALL, context=None):
        MsiSetInternalUI(MsiInstallUILevels.NONE.value, None)

        if not isinstance(callback, INSTALLUI_HANDLER):
            callback = INSTALLUI_HANDLER(callback)

        self._callback = callback

        if log_mode not in MsiInstallLogModes:
            log_mode = MsiInstallLogModes(log_mode)

        self._log_mode = log_mode

        if context is not None:

            if isinstance(context, str):
                context = context.encode('utf-8', 'strict')

                def convert_ctx(ctx):
                    return ctypes.string_at(ctx).decode('utf-8', 'strict')

            elif isinstance(context, int):
                def convert_ctx(ctx):
                    return ctx

            else:
                raise NotImplemented

            self._convert_context = convert_ctx

        self._context = context

        MsiSetExternalUI(callback, log_mode.value, context)

        if not self._callback_set:
            self._callback_set = True

    def start(self):
        logger.debug('Starting install process.')
        self._ensure_callback()
        self._thread = Thread(target=self._run)
        self._thread.daemon = True
        self._thread.start()

    def wait(self, timeout=None):
        if not self._thread:
            raise RuntimeError('Install process not started')

        if not self._done_event.wait(timeout=timeout):
            self.cancel()
            raise TimeoutError

        self._cleanup()

    def cancel(self):
        if not self._thread:
            raise RuntimeError('Install process not started')

        logger.debug('Canceling install process')
        self._cancel_event.set()
        self._cleanup()

    def raise_for_status(self):
        if self.is_running():
            return False

        if self.return_code is not None and self.return_code != ERROR_SUCCESS:
            raise_windows_error(self.return_code)

        return True


class Msi(metaclass=SingletonMeta):
    DEFAULT_LOG_MODE = MsiInstallLogModes.INFO

    DEFAULT_LOG_ATTRIBUTES = MsiInstallLogAttributes.APPEND

    DEFAULT_INSTALL_OPTIONS = (
        MsiCommandLineOptions.ALL_USERS,
        MsiCommandLineOptions.SUPPRESS_REBOOT
    )

    DEFAULT_UNINSTALL_OPTIONS = (
        MsiCommandLineOptions.REMOVE_ALL,
        MsiCommandLineOptions.SUPPRESS_REBOOT,
    )

    def __init__(self):
        self._products_by_code = {}
        self._components_by_code = {}
        self._enumerated = False
        self._installer_thread = None

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def __iter__(self):
        yield from self.iter_products()

    def iter_products(self):
        if not self._enumerated:
            yield from self.enum_products()

        else:
            for product in self._products_by_code.values():
                yield product

    def enum_products(self, install_context=MsiInstallContext.ALL):
        self._products_by_code.clear()

        index = wintypes.DWORD(0)

        if install_context not in MsiInstallContext:
            install_context = MsiInstallContext(install_context)

        if install_context in (MsiInstallContext.USER_MANAGED, MsiInstallContext.USER_UNMANAGED):
            user_sid = get_current_user_sid().encode('utf-8', 'strict')

        else:
            user_sid = None

        # self.map_components(install_context=install_context)
        buf = ctypes.create_string_buffer(MAX_GUID_CHARS + 1)

        while True:
            ctx = wintypes.DWORD(0)
            ret = MsiEnumProductsEx(None, user_sid, install_context.value, index, buf,
                                    ctypes.byref(ctx), None, None)

            if ret != ERROR_SUCCESS:
                break

            product_code = buf.value.decode('utf-8', 'strict')

            product = MsiProduct(self, product_code, ctx.value)

            if product.validate():
                components = self._components_by_code.get(product_code, [])

                self._products_by_code[product_code] = product

                for component in components:
                    product.add_component(component)

                yield product

            index.value += 1

        if not self._enumerated:
            self._enumerated = True

    def clear_products(self):
        self._products_by_code.clear()
        self._enumerated = False

    def get_product_by_code(self, code):
        if not self._enumerated:
            self.enum_products()

        return self._products_by_code.get(code)

    def enable_log(self, log_file, mode=None, attributes=None):
        mode = mode or self.DEFAULT_LOG_MODE
        attributes = attributes or self.DEFAULT_LOG_ATTRIBUTES
        ret = MsiEnableLog(mode, log_file, attributes)

        if ret != ERROR_SUCCESS:
            raise raise_windows_error(ret)

    def msi_install_product(self, msi_path, command_line_options, start, wait, raise_for_status,
                            timeout=None):
        option_strings = []

        for option in command_line_options:
            if option in MsiCommandLineOptions:
                option = option.value

            option_strings.append(option)

        cmd_line = ' '.join(option_strings)
        install_process = MsiInstallProcess(msi_path, cmd_line=cmd_line)

        if start:
            install_process.start()

            if wait:
                install_process.wait(timeout)

                if raise_for_status:
                    install_process.raise_for_status()

        self.clear_products()
        return install_process

    def install(self, msi_path, command_line_options=None, start=True, wait=True,
                raise_for_status=True, timeout=None):
        command_line_options = command_line_options or self.DEFAULT_INSTALL_OPTIONS
        return self.msi_install_product(msi_path, command_line_options, start=start, wait=wait,
                                        raise_for_status=raise_for_status, timeout=timeout)

    def uninstall(self, msi_path, command_line_options=None, start=True, wait=True,
                  raise_for_status=True, timeout=None):
        command_line_options = command_line_options or self.DEFAULT_UNINSTALL_OPTIONS
        return self.msi_install_product(msi_path, command_line_options, start=start, wait=wait,
                                        raise_for_status=raise_for_status, timeout=timeout)

    remove = uninstall

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(self.iter_products(), case_insensitive=case_insensitive,
                             sub_string=sub_string, attrs=attributes)

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(self.iter_products(), case_insensitive=case_insensitive,
                                sub_string=sub_string, attrs=attributes)


msi_exec = Msi()
