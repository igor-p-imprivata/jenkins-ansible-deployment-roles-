# definitions.py
import os


PACKAGE_ROOT_DIRECTORY = os.path.abspath(os.path.dirname(__file__))

SVC_PORT = 11111

SVC_NAME_ROOT = 'root'
SVC_NAME_MSI = 'msi'
SVC_NAME_REGISTRY = 'registry'
SVC_NAME_DRIVES = 'drives'
SVC_NAME_USERS = 'users'
SVC_NAME_FILES = 'files'
SVC_NAME_SESSIONS = 'sessions'
SVC_NAME_PROCESSES = 'processes'
SVC_NAME_EVENTS = 'events'
SVC_NAME_CMD = 'cmd'
SVC_NAME_SYSTEM = 'system'
SVC_NAME_SERVICES = 'services'
SVC_NAME_CODE_IMPORTER = 'code_importer'
SVC_NAME_PACKAGES = 'packages'

STATION_NAME_SERVICES = 'Services'
STATION_NAME_CONSOLE = 'Console'


__all__ = [
    'PACKAGE_ROOT_DIRECTORY',
    'SVC_PORT',
    'SVC_NAME_ROOT',
    'SVC_NAME_SESSIONS',
    'SVC_NAME_USERS',
    'SVC_NAME_MSI',
    'SVC_NAME_DRIVES',
    'SVC_NAME_FILES',
    'SVC_NAME_EVENTS',
    'SVC_NAME_PROCESSES',
    'SVC_NAME_CMD',
    'SVC_NAME_REGISTRY',
    'SVC_NAME_SYSTEM',
    'SVC_NAME_SERVICES',
    'SVC_NAME_CODE_IMPORTER',
    'SVC_NAME_PACKAGES',
    'STATION_NAME_SERVICES',
    'STATION_NAME_CONSOLE'
]
