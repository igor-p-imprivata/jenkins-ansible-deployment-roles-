# __init__.py
from .client import RpcServiceProxy, STATION_NAME_SERVICES, STATION_NAME_CONSOLE
from .remote_service_installer import RemoteServiceInstaller


__all__ = [
    'RpcServiceProxy', 'RemoteServiceInstaller', 'STATION_NAME_SERVICES', 'STATION_NAME_CONSOLE'
]
