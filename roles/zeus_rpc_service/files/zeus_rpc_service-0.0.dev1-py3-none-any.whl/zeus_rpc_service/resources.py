# resources.py
from typing import Callable, Any


class RpcResourceManager:
    def __init__(self):
        self.__resources = {}

    def cleanup(self):
        exc_map = {}

        for tag, res_info in self.__resources.items():
            _, cleanup_func = res_info

            if cleanup_func is not None:
                try:
                    cleanup_func()
                except Exception as exc:
                    exc_map[tag] = exc

        self.__resources.clear()

        exc_info = [(tag, exc) for tag, exc in exc_map.items() if exc is not None]

        if exc_info:
            exc_str = '\n'.join(f'\ttag: {tag}, exception: {str(exc)}' for tag, exc in exc_info)
            raise RuntimeError(f'Exceptions in cleanup_funcs: {exc_str}')

    def register(self, tag: str, resource: Any, cleanup_func: Callable[[], Any] = None):
        """

        :param tag:
        :param resource:
        :param cleanup_func:
        """
        self.__resources[tag] = (resource, cleanup_func)

    def get(self, tag: str):
        """

        :param tag:
        :return:
        """
        res_info = self.__resources.get(tag)

        if res_info is not None:
            resource, _ = res_info
            return resource
