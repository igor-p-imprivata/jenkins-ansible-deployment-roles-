# exceptions.py


class ZeusRpcServiceError(Exception):
    def __init__(self, fault):
        code = fault.faultCode
        string = fault.faultString
        super(ZeusRpcServiceError, self).__init__(f'fault_code: {code}, fault_string: {string}')
