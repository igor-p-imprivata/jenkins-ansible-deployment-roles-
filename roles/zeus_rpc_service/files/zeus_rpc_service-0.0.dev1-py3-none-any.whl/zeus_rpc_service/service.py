# service.py
import os
import io
import sys
import logging
import shutil
import subprocess as sp
import win32event
import win32service
import win32serviceutil
import threading
import servicemanager
from zeus_utils import config_logging
from zeus_rpc_service.server import RpcServer


# TODO: add ability to specify service port by persisting the value in registry
# TODO: possibility under HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\<ServiceName>


logger = logging.getLogger(__name__)


HOST = '0.0.0.0'
PORT = 11111
SVC_DIR = 'C:\\ProgramData\\ZeusService'
SVC_LOGS_DIR = os.path.join(SVC_DIR, 'logs')
RPC_LOG = os.path.join(SVC_LOGS_DIR, 'rpc.log')

HERE = os.path.abspath(os.path.dirname(__file__))

FILE_PATH = os.path.abspath(__file__)

START_TYPE_AUTO = win32service.SERVICE_AUTO_START

CMD_INSTALL = 'install'
CMD_REMOVE = 'remove'

OPTION_STARTUP_AUTO = '--startup=auto'

STATE_CMD_START = 'start'
STATE_CMD_STOP = 'stop'

PROC_POLL_INTERVAL = 0.1


def run_command(*args):
    proc = sp.run(args, stdout=sp.PIPE, stderr=sp.PIPE)

    if proc.stderr:
        source = 'stderr'
        rawlines = proc.stderr.splitlines()

    else:
        source = 'stdout'
        rawlines = proc.stdout.splitlines()

    messages = []

    for line in rawlines:
        msg = line.decode('utf-8', 'strict').strip()

        if not msg:
            continue

        logger.info(f'Command output -> source: {source}, message: {msg}')
        messages.append(msg)

    return messages


def modify_service(command, *options):
    args = ['python', FILE_PATH, *options, command]

    msg = 'Modifying {} with command line: {}'
    logger.info(msg.format(ZeusRpcService._svc_name_, ' '.join(args)))

    return run_command(*args)


def modify_service_running_state(state_cmd):
    args = ['net', state_cmd, ZeusRpcService._svc_name_]

    msg = 'Modifying {} running state with command line: {}'
    logger.info(msg.format(ZeusRpcService._svc_name_, ' '.join(args)))

    return run_command(*args)


def remove_service():
    # if os.path.exists(SVC_DIR):
    #     shutil.rmtree(SVC_DIR, ignore_errors=True)

    modify_service(CMD_REMOVE)


def install_service(start_type=START_TYPE_AUTO):
    if not os.path.exists(SVC_DIR):
        os.mkdir(SVC_DIR)

    if not os.path.exists(SVC_LOGS_DIR):
        os.mkdir(SVC_LOGS_DIR)

    options = []

    if start_type == START_TYPE_AUTO:
        options.append(OPTION_STARTUP_AUTO)

    modify_service(CMD_INSTALL, *options)


def start_service():
    modify_service_running_state(STATE_CMD_START)


def stop_service():
    modify_service_running_state(STATE_CMD_STOP)


def stop_remove_service():
    stop_service()
    remove_service()


def install_start_service(start_type=START_TYPE_AUTO):
    install_service(start_type=start_type)
    start_service()


def restart_service():
    stop_service()
    start_service()


class ZeusRpcService(win32serviceutil.ServiceFramework):
    _svc_name_ = 'zeus_rpc_service'
    _svc_display_name_ = 'Zeus RPC Service'

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.timeout = 5000
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.server = None
        self.server_thread = None
        self.stdout = None
        self.stderr = None

    # noinspection PyPep8Naming
    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.server.shutdown()
        logger.debug(f'{repr(self)}: SvcStop -> stdout: {self.stdout.getvalue()}, '
                     f'stderr: {self.stderr.getvalue()}')
        win32event.SetEvent(self.hWaitStop)
        self.ReportServiceStatus(win32service.SERVICE_STOPPED)

    # noinspection PyPep8Naming
    def SvcDoRun(self):
        self.ReportServiceStatus(win32service.SERVICE_RUNNING)

        self.stdout = io.StringIO()
        self.stderr = io.StringIO()

        sys.stdout = self.stdout
        sys.stderr = self.stderr

        servicemanager.LogMsg(servicemanager.EVENTLOG_INFORMATION_TYPE,
                              servicemanager.PYS_SERVICE_STARTED,
                              (self._svc_name_, ''))

        if not os.path.exists(SVC_DIR):
            os.mkdir(SVC_DIR)

        if not os.path.exists(SVC_LOGS_DIR):
            os.mkdir(SVC_LOGS_DIR)

        config_logging('debug', log_file=RPC_LOG)

        self.server = RpcServer(HOST, PORT, default_directory=SVC_DIR)

        self.server_thread = threading.Thread(target=self.server.serve_forever)
        self.server_thread.daemon = True
        self.server_thread.start()

        rc = None

        while rc != win32event.WAIT_OBJECT_0:
            rc = win32event.WaitForSingleObject(self.hWaitStop, self.timeout)

        self.server_thread.join()


if __name__ == '__main__':
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(ZeusRpcService)
        servicemanager.StartServiceCtrlDispatcher()

    else:
        win32serviceutil.HandleCommandLine(ZeusRpcService)

