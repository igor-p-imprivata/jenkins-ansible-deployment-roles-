# base.py
from ..protocol import ProtocolObjectProxy
from .packages import get_top_level_import_name


class RemoteServiceProvider(ProtocolObjectProxy):
    def __init__(self, name, service, exclude_attributes=None, import_name=None,
                 service_args=None, service_kwargs=None):
        super(RemoteServiceProvider, self).__init__(
            obj=service,
            exclude_attributes=exclude_attributes
        )
        self.name = name
        self.import_name = import_name
        self.service_args = service_args
        self.service_kwargs = service_kwargs

    def get_originating_module_name(self):
        if self.import_name is not None:
            return get_top_level_import_name(self.import_name)
