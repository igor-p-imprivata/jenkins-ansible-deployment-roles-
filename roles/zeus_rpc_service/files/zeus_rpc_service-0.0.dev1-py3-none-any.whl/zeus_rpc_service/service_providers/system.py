# system.py
import win32api
import win32con
from struct import calcsize
from zeus_utils import SingletonMeta
from zeus_win32_utils import windows_is_64bit, enable_process_privilege


# noinspection PyMethodMayBeStatic
class SystemManager(metaclass=SingletonMeta):
    def get_process_bitness(self):
        return calcsize('P') * 8

    def get_os_bitness(self):
        return 64 if windows_is_64bit() else 32

    def initiate_system_shutdown(self, message=None, timeout=0, force_apps_closed=False,
                                 reboot=False):
        enable_process_privilege(win32con.SE_SHUTDOWN_NAME)
        win32api.InitiateSystemShutdown(None, message, timeout, force_apps_closed, reboot)


system_manager = SystemManager()
