# base.py
import logging
from pickle import loads as pickle_loads, dumps as pickle_dumps
from xmlrpc.client import Binary


logger = logging.getLogger(__name__)


class RpcSerializableObject:
    __slots__ = ()
    PRIVATE_SLOTS = {}

    @classmethod
    def deserialize(cls, binary, **set_attrs):
        # note that __init__ is not called here!
        serializable_object = pickle_loads(binary.data)

        for key, value in set_attrs.items():
            setattr(serializable_object, key, value)

        return serializable_object

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def __getstate__(self):
        public_attrs = tuple(s for s in self.__slots__ if s not in self.PRIVATE_SLOTS)
        return {name: getattr(self, name) for name in public_attrs}

    def __setstate__(self, state):
        for name, value in state.items():
            setattr(self, name, value)

        for slot_name in self.PRIVATE_SLOTS:
            setattr(self, slot_name, None)

    def serialize(self):
        return Binary(pickle_dumps(self))


class RpcSerializableChannel(RpcSerializableObject):
    __slots__ = ('send_func',)
    PRIVATE_SLOTS = {'send_func'}

    def __init__(self, send_func=None):
        self.send_func = send_func
