# response.py
import logging
from collections import Iterable
from xmlrpc.client import Binary
from pickle import UnpicklingError
from .base import RpcSerializableChannel
from .objects import is_custom_class_instance, RpcRemoteObjectProxy


POD_TYPES = (int, float, complex, str, bytes, bytearray)
# ITERABLE_TYPES = (list, tuple)
MAPPING_TYPES = (dict,)


logger = logging.getLogger(__name__)


class RpcResponsePacket(RpcSerializableChannel):
    __slots__ = RpcSerializableChannel.__slots__ + (
        'session_cache',
        'unmarshaled_data',
        'marshaled_data'
    )

    PRIVATE_SLOTS = {
        'session_cache',
        'unmarshaled_data',
        *RpcSerializableChannel.PRIVATE_SLOTS
    }

    def __init__(self, send_func=None, session_cache=None, unmarshaled_data=None,
                 marshaled_data=None):
        super(RpcResponsePacket, self).__init__(send_func=send_func)
        self.unmarshaled_data = unmarshaled_data
        self.marshaled_data = marshaled_data
        self.session_cache = session_cache

    def __repr__(self):
        return f'{self.__class__.__name__}()'

    def _marshal(self, obj):
        if isinstance(obj, POD_TYPES) or isinstance(obj, Binary) or obj is None:
            return obj

        elif is_custom_class_instance(obj):
            if self.session_cache is None:
                raise RuntimeError(f'Cannot marshal {type(obj).__name__} type object without '
                                   f'a session')

            proxy = self.session_cache.cache_object_get_proxy(local_object=obj)
            return proxy.serialize()

        elif isinstance(obj, MAPPING_TYPES):
            return {key: self._marshal(value) for key, value in obj.items()}

        elif isinstance(obj, Iterable):
            return [self._marshal(element) for element in obj]

        raise TypeError(f'Unable to marshal {type(obj).__name__} type object')

    def _unmarshal(self, obj):
        if isinstance(obj, POD_TYPES) or obj is None:
            return obj

        elif isinstance(obj, Binary):
            try:
                return RpcRemoteObjectProxy.deserialize(obj, send_func=self.send_func)
            except (UnpicklingError, EOFError):
                return obj

        elif isinstance(obj, MAPPING_TYPES):
            return {key: self._unmarshal(value) for key, value in obj.items()}

        elif isinstance(obj, Iterable):
            return [self._unmarshal(obj) for obj in obj]

        raise TypeError(f'Unable to marshal {type(obj).__name__} type object')

    def marshal(self):
        self.marshaled_data = self._marshal(self.unmarshaled_data)
        return self.marshaled_data

    def unmarshal(self):
        self.unmarshaled_data = self._unmarshal(self.marshaled_data)
        return self.unmarshaled_data
