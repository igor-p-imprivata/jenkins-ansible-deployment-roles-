# server.py
import os
import sys
import logging
import traceback
from uuid import uuid4
from zeus_utils import kwargs2str, config_logging, get_default_python_exe
from zeus_win32_utils import get_current_process_id, get_current_session_id
from zeus_file_service import FileManager
from zeus_rpc_service.protocol import (
    RpcSessionObjectCache, RpcRequestPacket, RpcResponsePacket, RpcLocalObjectWrapper
)
from zeus_rpc_service.server.base import BaseRpcServer, BaseRpcRequestHandler
from zeus_rpc_service.service_providers import (
    PythonCodeImporter, PythonPackageManager
)
from zeus_rpc_service.service_providers.packages import get_top_level_import_name
from zeus_rpc_service.definitions import (
    PACKAGE_ROOT_DIRECTORY, SVC_NAME_MSI, SVC_NAME_REGISTRY, SVC_NAME_DRIVES, SVC_NAME_USERS,
    SVC_NAME_FILES, SVC_NAME_SESSIONS, SVC_NAME_PROCESSES, SVC_NAME_EVENTS, SVC_NAME_CMD,
    SVC_NAME_SYSTEM, SVC_NAME_SERVICES, SVC_NAME_ROOT, SVC_NAME_CODE_IMPORTER, SVC_NAME_PACKAGES
)
from zeus_rpc_service.utils import command_line2kwargs, kwargs2command_line


logger = logging.getLogger(__name__)

# TODO MOVE TO CONFIG FILE
SESSION_LOGS_REL_DIR = 'logs\\sessions'
SESSION_LOG_NAME_FMT = 'RpcServerSession{}.log'

DEFAULT_SERVICES = [
    (SVC_NAME_MSI, 'zeus_msi.msi_exec'),
    (SVC_NAME_REGISTRY, 'zeus_reg.registry'),
    (SVC_NAME_DRIVES, 'zeus_drive_service.drive_manager'),
    (SVC_NAME_USERS, 'service_providers.user_manager'),
    (SVC_NAME_SESSIONS, 'service_providers.session_manager'),
    (SVC_NAME_PROCESSES, 'service_providers.process_manager'),
    (SVC_NAME_EVENTS, 'service_providers.event_manager'),
    (SVC_NAME_CMD, 'service_providers.command_prompt'),
    (SVC_NAME_SYSTEM, 'service_providers.system_manager'),
    (SVC_NAME_SERVICES, 'service_providers.service_manager'),
]


# noinspection PyMethodMayBeStatic
class RpcServer:
    def __init__(self, host, port, default_directory=None):
        self.host = host
        self.port = port
        self.quit = False
        self.default_directory = default_directory

        self._file_manager = FileManager(default_directory=default_directory)
        self._code_importer = PythonCodeImporter()
        self._package_manager = PythonPackageManager()

        self._services = {}
        self._sessions = {}

        self._xml_rpc_server = BaseRpcServer(host=self.host, port=self.port)

        self._init_services()
        self._xml_rpc_server.register_instance(self)

    def __repr__(self):
        return f'{self.__class__.__name__}(host="{self.host}", port={self.port})'

    def _init_services(self):
        self._code_importer.import_package('service_providers', location=PACKAGE_ROOT_DIRECTORY)

        # required services
        self.add_service(SVC_NAME_ROOT, self)
        self.add_service(SVC_NAME_FILES, self._file_manager)
        self.add_service(SVC_NAME_CODE_IMPORTER, self._code_importer)
        self.add_service(SVC_NAME_PACKAGES, self._package_manager)

        for provider_info in DEFAULT_SERVICES:
            service_name, import_path, *extra = provider_info

            service = self._import_from_path(import_path)
            call_import = extra[0] if extra else False

            if call_import:
                args = extra[1] if len(extra) > 1 else ()
                kwargs = extra[2] if len(extra) > 2 else {}
                service = service(*args, **kwargs)

            self.add_service(
                name=service_name,
                service=service
            )

    def _import_from_path(self, import_path):
        top_level_name = get_top_level_import_name(import_path)

        if top_level_name not in self._code_importer:
            package = self._package_manager.find(name=top_level_name)

            if package is None:
                raise ImportError(f'"{top_level_name}" not installed')

            # the package is installed but not imported
            logger.debug(f'{repr(self)}: _import_from_path -> {top_level_name} is installed but '
                         f'not imported, doing import')

            self._code_importer.import_package(
                name=package.name,
                location=package.location
            )

        obj = self._code_importer.get(import_path)

        if obj is None:
            raise ImportError(f'Invalid import_path: {import_path}')

        return obj

    def add_service(self, name, service):
        logger.info(f'{repr(self)}: add_service -> name: {name}, service: {repr(service)}')

        local_object_wrapper = RpcLocalObjectWrapper()
        local_object_wrapper.wrap(service)

        self._services[name] = local_object_wrapper

    def remove_service(self, name):
        logger.info(f'{repr(self)}: remove_service -> name: {name}')

        self._services.pop(name, None)

    def get_service(self, name):
        return self._services.get(name)

    def create_session_context(self, context_request=None, *, src_uuid=None, keyword_mapping=None):
        session_cache = self._sessions.get(context_request.session_uuid)

        if session_cache is None:
            raise ValueError(f'Invalid session_uuid: {context_request.session_uuid}')

        context = session_cache.create_context(
            src_uuid=src_uuid,
            keyword_mapping=keyword_mapping
        )

        if context_request is not None:
            for item_request in context_request:
                import_path = item_request.import_path
                call_import = item_request.call_import
                call_args = item_request.call_args
                call_kwargs = item_request.call_kwargs
                method_name = item_request.method_name

                try:
                    context_item = item_request.get_item()

                    if context_item is None:
                        value = self._import_from_path(item_request.import_path)

                        if item_request.call_import:
                            args = item_request.call_args or ()
                            kwargs = item_request.call_kwargs or {}
                            value = value(*args, **kwargs)

                        if item_request.method_name is not None:
                            value = getattr(value, item_request.method_name)

                        item_request.set_value(value)
                        context_item = item_request.get_item()

                    assert context_item is not None
                    context.add_item(context_item)

                except Exception as exc:
                    raise RuntimeError(f'Exception during context item request '
                                       f'\n\t(import_path={import_path}, call_import={call_import}, '
                                       f'call_args={call_args}, call_kwargs={call_kwargs}, '
                                       f'method_name={method_name})\nException: \n\t{str(exc)}')

        return context.uuid

    def clear_session_context(self, session_uuid, context_uuid):
        session_cache = self._sessions.get(session_uuid)

        if session_cache is None:
            raise ValueError(f'Invalid session_uuid: {session_uuid}')

        session_cache.clear_context(context_uuid)

    def add_ext_request_handler(self, name, ext_handler):
        BaseRpcRequestHandler.register_ext_handler(name, ext_handler)

    def remove_ext_request_handler(self, name):
        BaseRpcRequestHandler.unregister_ext_handler(name)

    def get_session_count(self):
        return len(self._sessions)

    def create_session(self):
        session_uuid = str(uuid4())

        logger.debug(f'{repr(self)}: creation_session -> session_uuid: {session_uuid}')

        self._sessions[session_uuid] = RpcSessionObjectCache(session_uuid)
        return session_uuid

    def clear_session(self, session_uuid):
        session_object_cache = self._sessions.pop(session_uuid, None)

        if session_object_cache is not None:
            session_object_cache.clear()

    def get_service_names(self):
        return list(self._services.keys())

    def handle_request(self, binary):
        rpc_request = RpcRequestPacket.deserialize(binary)

        logger.debug(f'{repr(self)}: handle_request -> {str(rpc_request)}')

        session_uuid = rpc_request.session_uuid
        class_name = rpc_request.class_name
        service_name = rpc_request.service_name
        session_cache = self._sessions.get(session_uuid)

        if class_name is not None:
            object_hash = rpc_request.object_hash

            if object_hash is None:
                raise ValueError('object_hash must be defined with class_name')

            if session_cache is None:
                raise ValueError(f'Invalid session: {session_uuid}')

            local_object_wrapper = session_cache.get_wrapper(
                class_name=class_name,
                object_hash=object_hash
            )

        else:
            local_object_wrapper = self._services.get(service_name)

        if local_object_wrapper is None:
            raise ValueError(f'No such service: {service_name}')

        attr_name = rpc_request.attribute_name
        context_uuid = rpc_request.context_uuid

        if context_uuid is not None:

            if session_uuid is None:
                raise ValueError(f'Invalid session: {session_uuid}')

            ctx = session_cache.get_context(context_uuid)

            if ctx is None:
                raise ValueError(f'Invalid context_uuid: {context_uuid}')

            args = ctx.args
            kwargs = ctx.kwargs

        else:
            args = rpc_request.callable_args or ()
            kwargs = rpc_request.callable_kwargs or {}

        logger.debug(f'{repr(self)}: calling {repr(local_object_wrapper)} -> '
                     f'attribute_name: {attr_name}')

        unmarshaled_data = local_object_wrapper.call_object(attr_name, *args, **kwargs)

        response = RpcResponsePacket(
            unmarshaled_data=unmarshaled_data,
            session_cache=session_cache
        )
        response.marshal()
        return response.serialize()

    def ping(self):
        return True

    def spawn_rpc_server(self, session_id, port, python_exe=None, default_directory=None,
                         timeout=None, **kwargs):
        logger.debug(f'{repr(self)}: spawn_rpc_server -> session_id: {session_id}')

        proc_mgr = self.get_service(SVC_NAME_PROCESSES)

        assert proc_mgr is not None

        if python_exe is None:
            python_exe = get_default_python_exe()

        default_directory = default_directory or self.default_directory
        evt_mgr = self.get_service(SVC_NAME_EVENTS)

        assert evt_mgr is not None

        start_event = evt_mgr.create_event()
        server_kwargs = dict(host=self.host, port=port, default_directory=default_directory)
        cmd_line_args = [python_exe, __file__, start_event.name]

        arg_str = ', '.join(str(a) for a in cmd_line_args)
        logger.debug(f'{repr(self)}: spawn_rpc_server -> cmd_line_args: {arg_str}')

        kwds_str = kwargs2str(**server_kwargs)
        logger.debug(f'{repr(self)}: spawn_rpc_server -> server_kwargs: {kwds_str}')

        cmd_line_args.append(kwargs2command_line(**server_kwargs))

        logger.debug(f'{repr(self)}: spawn_rpc_server -> calling '
                     f'{proc_mgr.class_name}.create_process_in_session')

        pid = proc_mgr.create_process_in_session(session_id, *cmd_line_args, **kwargs)

        logger.debug(f'{repr(self)}: spawn_rpc_server -> received PID {pid} from '
                     f'{proc_mgr.class_name}.create_process_in_session')

        logger.debug(f'{repr(self)}: spawn_rpc_server -> waiting for start event '
                     f'(timeout={timeout})')

        if not start_event.wait(timeout=timeout):
            logger.debug(f'{repr(self)}: spawn_rpc_server -> timed out waiting for start event')
            logger.debug(f'{repr(self)}: spawn_rpc_server -> terminating PID {pid}')
            proc_mgr.terminate(pid)
            raise TimeoutError()

        logger.debug(f'{repr(self)}: spawn_rpc_server -> server successfully started')
        return pid

    def shutdown(self):
        self.quit = True

    def serve_forever(self):
        logger.debug(f'{repr(self)}: serving...')

        while not self.quit:
            self._xml_rpc_server.handle_request()

        logger.debug(f'{repr(self)}: stopping...')


class RpcServerLauncher:
    def __init__(self, args):
        self.args = args
        self.session_uuid = None
        self.start_event_name = None
        self.server_kwargs = None
        self.event_manager = None

    def __str__(self):
        return f'{self.__class__.__name__}(session_uuid={self.session_uuid})'

    def __enter__(self):
        self.get_session_id()
        self.parse_args()
        self.config_logging()
        args_str = ', '.join(' '.join(arg.split('\n')) for arg in self.args)
        logger.debug(f'{str(self)}: __enter__ -> args: {args_str}')
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        exc_str = traceback.format_exception(exc_type, exc_val, exc_tb)
        logger.debug(f'{str(self)}: __exit__ -> exception: {exc_str}')

    def get_session_id(self):
        self.session_uuid = get_current_session_id(get_current_process_id())

    def parse_args(self):
        assert len(self.args) == 2

        self.start_event_name = self.args[0]
        self.server_kwargs = command_line2kwargs(self.args[1])

    def config_logging(self):
        default_dir = self.server_kwargs['default_directory']
        session_logs_dir = os.path.join(default_dir, SESSION_LOGS_REL_DIR)

        if not os.path.exists(session_logs_dir):
            os.mkdir(session_logs_dir)

        log_file = os.path.join(session_logs_dir, SESSION_LOG_NAME_FMT.format(self.session_uuid))
        config_logging('debug', log_file=log_file)

        logger.debug(f'{str(self)}: logging config complete')

    def create_server(self):
        server = RpcServer(**self.server_kwargs)

        logger.debug(f'{str(self)}: created {repr(server)}')

        self.event_manager = server.get_service(SVC_NAME_EVENTS)

        assert self.event_manager is not None

        logger.debug(f'{str(self)}: setting start event -> name: "{self.start_event_name}"')
        self.set_start_event()
        return server

    def set_start_event(self):
        if self.start_event_name is not None and self.event_manager is not None:
            self.event_manager.set_event(self.start_event_name)


if __name__ == '__main__':
    with RpcServerLauncher(sys.argv[1:]) as launcher:
        rpc_server = launcher.create_server()
        rpc_server.serve_forever()


