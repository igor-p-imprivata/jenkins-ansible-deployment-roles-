# _server.py
import abc
import sys
import logging
import traceback
from urllib.parse import urlparse, parse_qsl
from functools import partial
from http import HTTPStatus
from xmlrpc.server import (
    SimpleXMLRPCServer, SimpleXMLRPCRequestHandler, Fault
)
from xmlrpc.client import gzip_encode


HTTP_METHOD_NAME_PREFIX = 'do_'
DEFAULT_CONTENT_TYPE = 'text/plain'


logger = logging.getLogger(__name__)


class ExtendedRequestHandler(metaclass=abc.ABCMeta):

    def __init__(self, name, supported_paths=None, supported_http_methods=None, content_type=None):
        self.name = name
        self.supported_paths = set(supported_paths or [])
        self.supported_http_methods = set(supported_http_methods or [])
        self._content_type = content_type
        self.http_method = None
        self.path = None
        self.base_request_handler = None

    def __repr__(self):
        return f'{self.__class__.__name__}(name="{self.name}", http_method="{self.http_method}", ' \
               f'path="{self.path}")'

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False

        return hash(self) == hash(other)

    @property
    def content_type(self):
        if self._content_type is None:
            self._content_type = DEFAULT_CONTENT_TYPE

        return self._content_type

    @content_type.setter
    def content_type(self, value):
        self._content_type = value

    def is_valid_path(self):
        return self.path in self.supported_paths

    def set_request_context(self, base_request_handler, http_method, path):
        self.base_request_handler = base_request_handler
        self.http_method = http_method
        self.path = path

    @abc.abstractmethod
    def handle_request(self, data=None):
        raise NotImplementedError()


class BaseRpcRequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = {'/', '/RPC2'}
    ext_handlers_by_name = {}
    ext_handlers_by_http_method = {}

    @classmethod
    def register_ext_handler(cls, name, ext_handler):
        if not isinstance(ext_handler, ExtendedRequestHandler):
            raise TypeError(f'ext_handler must be a valid {ExtendedRequestHandler.__name__} instance')

        if name in cls.ext_handlers_by_name:
            raise ValueError(f'Name already registered: "{name}"')

        paths = ext_handler.supported_paths
        cls.rpc_paths.update(paths)
        path_map = {path: ext_handler for path in paths}

        for http_method in ext_handler.supported_http_methods:
            cls.ext_handlers_by_http_method.setdefault(http_method, {})
            cls.ext_handlers_by_http_method[http_method].update(path_map)

        cls.ext_handlers_by_name[name] = ext_handler

    @classmethod
    def unregister_ext_handler(cls, name):
        ext_handler = cls.ext_handlers_by_name.pop(name, None)

        if ext_handler is not None:
            for path_map in cls.ext_handlers_by_http_method.values():
                for path, handler in list(path_map.items()):
                    if handler is ext_handler:
                        cls.rpc_paths.discard(path)
                        path_map.pop(path)

    def __getattr__(self, item):
        if item.startswith(HTTP_METHOD_NAME_PREFIX):
            http_method = item[len(HTTP_METHOD_NAME_PREFIX):].upper()
            return partial(self.handle_ext_request, http_method)

        # noinspection PyUnresolvedReferences
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{item}'")

    def read_request_data(self):
        # Get arguments by reading body of request.
        # We read this in chunks to avoid straining
        # socket.read(); around the 10 or 15Mb mark, some platforms
        # begin to have problems (bug #792570).
        max_chunk_size = 10 * 1024 * 1024
        size_remaining = int(self.headers["content-length"] or 0)
        L = []

        while size_remaining:
            chunk_size = min(size_remaining, max_chunk_size)
            chunk = self.rfile.read(chunk_size)

            if not chunk:
                break

            L.append(chunk)
            size_remaining -= len(L[-1])

        return b''.join(L)

    def on_exception(self):
        self.send_response(500)
        self.send_header("Content-length", "0")
        self.end_headers()

    def send_response_data(self, response_data, content_type):
        self.send_response(200)

        self.send_header("Content-type", content_type)
        response_data = response_data or b''

        if self.encode_threshold is not None:
            if len(response_data) > self.encode_threshold:
                accepted_encodings = self.accept_encodings()
                gzip_encoding = accepted_encodings.get('gzip')

                if gzip_encoding:
                    try:
                        response_data = gzip_encode(response_data)
                        self.send_header("Content-Encoding", "gzip")
                    except NotImplementedError:
                        pass

        self.send_header("Content-length", str(len(response_data)))
        self.end_headers()
        self.wfile.write(response_data)

    def handle_ext_request(self, http_method):
        try:
            handlers_by_path = self.ext_handlers_by_http_method[http_method]
        except KeyError:
            logger.error(f'{repr(self)}: handle_ext_request -> no extended handler for '
                         f'http_method: {http_method}')

            self.send_error(
                code=HTTPStatus.NOT_IMPLEMENTED,
                message=f'Unsupported method {http_method}'
            )

            return

        parse_result = urlparse(self.path)
        # noinspection PyAttributeOutsideInit
        self.path = parse_result.path

        try:
            ext_handler = handlers_by_path[self.path]
        except KeyError:
            logger.error(f'{repr(self)}: handle_ext_request -> no extended handler for '
                         f'path: {self.path}')

            self.send_error(
                code=HTTPStatus.NOT_IMPLEMENTED,
                message=f'Unsupported method {http_method}'
            )

            return

        ext_handler.set_request_context(
            base_request_handler=self,
            http_method=http_method,
            path=self.path
        )

        # Check that the path is legal
        if not self.is_rpc_path_valid() or not ext_handler.is_valid_path():
            self.report_404()
            return

        try:
            data = self.read_request_data()

            logger.debug(f'{repr(self)}: handle_ext_request -> ext_handler: {ext_handler}, '
                         f'data: {data}')

            response_data = ext_handler.handle_request(data=data)

        except Exception as exc:
            logger.error(f'{repr(self)}: handle_ext_request -> exception: {exc} ')

            self.on_exception()

        else:
            self.send_response_data(
                response_data=response_data,
                content_type=ext_handler.content_type
            )


class BaseRpcServer(SimpleXMLRPCServer):
    def __init__(self, host, port, **kwargs):
        # logRequests should be false since this will run as a Windows service, and there's no
        # stdout there which can cause problems
        SimpleXMLRPCServer.__init__(
            self,
            addr=(host, port),
            requestHandler=BaseRpcRequestHandler,
            allow_none=True,
            logRequests=False,
            **kwargs
        )

    def _dispatch(self, method, params):
        try:
            return super(BaseRpcServer, self)._dispatch(method, params)
        except Exception:
            type_, value, tb = sys.exc_info()
            raise Fault(1, ''.join(traceback.format_exception(type_, value, tb)))
