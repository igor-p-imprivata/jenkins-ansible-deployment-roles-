# server.py
import os
import sys
import logging
import traceback
from xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler, Fault
from zeus_utils import kwargs2str, params2str, config_logging, get_default_python_exe
from zeus_win32_utils import get_current_process_id, get_current_session_id
from zeus_file_service import FileManager
from zeus_rpc_service.service_providers import (
    PythonCodeImporter, PythonPackageManager
)
from zeus_rpc_service.service_providers.packages import get_top_level_import_name
from zeus_rpc_service.protocol import (
    ProtocolObjectCache, RemoteProcedureCall, ProtocolObjectProxy,
    PROTOCOL_MAGIC, PROTOCOL_KEY_SERVICE, PROTOCOL_KEY_CLASS_NAME, PROTOCOL_KEY_UID,
    PROTOCOL_KEY_SESSION_UUID, SVC_NAME_MSI, SVC_NAME_REGISTRY, SVC_NAME_DRIVES, SVC_NAME_USERS,
    SVC_NAME_FILES, SVC_NAME_SESSIONS, SVC_NAME_PROCESSES, SVC_NAME_EVENTS, SVC_NAME_CMD,
    SVC_NAME_SYSTEM, SVC_NAME_SERVICES, SVC_NAME_ROOT, SVC_NAME_CODE_IMPORTER, SVC_NAME_PACKAGES
)
from zeus_rpc_service.utils import command_line2kwargs, kwargs2command_line


logger = logging.getLogger(__name__)

SESSION_LOGS_REL_DIR = 'logs\\sessions'
SESSION_LOG_NAME_FMT = 'RpcServerSession{}.log'

DEFAULT_SERVICES = [
    (SVC_NAME_MSI, 'zeus_msi.msi_exec'),
    (SVC_NAME_REGISTRY, 'zeus_reg.registry'),
    (SVC_NAME_DRIVES, 'zeus_drive_service.drive_manager'),
    (SVC_NAME_USERS, 'service_providers.user_manager'),
    (SVC_NAME_SESSIONS, 'service_providers.session_manager'),
    (SVC_NAME_PROCESSES, 'service_providers.process_manager'),
    (SVC_NAME_EVENTS, 'service_providers.event_manager'),
    (SVC_NAME_CMD, 'service_providers.command_prompt'),
    (SVC_NAME_SYSTEM, 'service_providers.system_manager'),
    (SVC_NAME_SERVICES, 'service_providers.service_manager'),
]


class _XmlRpcServer(SimpleXMLRPCServer):
    def _dispatch(self, method, params):
        try:
            return super(_XmlRpcServer, self)._dispatch(method, params)
        except Exception:
            type_, value, tb = sys.exc_info()
            raise Fault(1, ''.join(traceback.format_exception(type_, value, tb)))


class RpcRequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/', '/test', '/RPC2')


class RemoteServiceProvider(ProtocolObjectProxy):
    def __init__(self, name, service, exclude_attributes=None, import_name=None,
                 service_args=None, service_kwargs=None):
        super(RemoteServiceProvider, self).__init__(
            obj=service,
            exclude_attributes=exclude_attributes
        )
        self.name = name
        self.import_name = import_name
        self.service_args = service_args
        self.service_kwargs = service_kwargs

    def get_originating_module_name(self):
        if self.import_name is not None:
            return get_top_level_import_name(self.import_name)


# noinspection PyMethodMayBeStatic
class RpcServer:
    EXCLUDE_ATTR_NAMES = {'register_service', 'handle_protocol', 'serve_forever'}

    def __init__(self, host, port, default_directory=None):
        self.host = host
        self.port = port
        self.quit = False
        self.default_directory = default_directory

        self._file_manager = FileManager(default_directory=default_directory)
        self._code_importer = PythonCodeImporter()
        self._package_manager = PythonPackageManager()

        self._services = {}
        self._module_ref = {}
        self._obj_cache = ProtocolObjectCache()
        # logRequests should be false since this will run as a Windows service, and there's no
        # stdout there which can cause problems
        self._xml_rpc_server = _XmlRpcServer(
            addr=(self.host, self.port),
            requestHandler=RpcRequestHandler,
            allow_none=True,
            logRequests=False
        )

        self._init_services()
        self._xml_rpc_server.register_instance(self)

    def __repr__(self):
        return f'{self.__class__.__name__}(host="{self.host}", port={self.port})'

    def _init_services(self):
        sp_loc = os.path.abspath(os.path.dirname(__file__))
        self._code_importer.import_package('service_providers', location=sp_loc)

        # required services
        self.add_service(SVC_NAME_ROOT, self, exclude_attributes=self.EXCLUDE_ATTR_NAMES)
        self.add_service(SVC_NAME_FILES, self._file_manager)
        self.add_service(SVC_NAME_CODE_IMPORTER, self._code_importer)
        self.add_service(SVC_NAME_PACKAGES, self._package_manager)

        for provider_info in DEFAULT_SERVICES:
            service_name, import_name, *extra = provider_info
            load_kwargs = {}

            if extra:
                load_kwargs.update(exclude_attributes=extra[0])

                if len(extra) > 1:
                    load_kwargs.update(service_args=extra[1])

                if len(extra) > 2:
                    load_kwargs.update(service_kwargs=extra[2])

            self.load_service(
                service_name=service_name,
                import_name=import_name,
                **load_kwargs
            )

    def load_service(self, service_name, import_name, exclude_attributes=None,
                     service_args=None, service_kwargs=None):
        logger.info(f'{repr(self)}: load_service -> service_name: {service_name}, '
                    f'import_name: {import_name}, exclude_attributes: {exclude_attributes}, '
                    f'service_args: {service_args}, service_kwargs: {service_kwargs}')

        top_level_name = get_top_level_import_name(import_name)

        logger.debug(f'{repr(self)}: load_service -> top_level_name: {top_level_name}')

        if top_level_name not in self._code_importer:
            package = self._package_manager.find(name=top_level_name)

            if package is None:
                raise RuntimeError(f'"{top_level_name}" not installed')

            # the package is installed but not imported
            logger.debug(f'{repr(self)}: load_service -> {top_level_name} is installed but '
                         f'not imported, doing import')
            self._code_importer.import_package(
                name=package.name,
                location=package.location
            )

        service_type = self._code_importer.get(import_name)

        if service_type is None:
            raise RuntimeError(f'Cannot import "{import_name}" from {service_name}')

        # check if the import is a type, as it maybe be an instance of a singleton
        if isinstance(service_type, type):
            service_args = service_args or ()
            service_kwargs = service_kwargs or {}

            logger.debug(f'{repr(self)}: load_service -> creating instance: '
                         f'{service_type.__name__}({params2str(*service_args, **service_kwargs)})')

            service = service_type(*service_args, **service_kwargs)

        else:
            service = service_type

        self.add_service(
            name=service_name,
            service=service,
            exclude_attributes=exclude_attributes,
            import_name=import_name,
            service_args=service_args,
            service_kwargs=service_kwargs
        )

    def add_service(self, name, service, exclude_attributes=None, import_name=None,
                    service_args=None, service_kwargs=None):
        logger.info(f'{repr(self)}: add_service -> name: {name}, service: {repr(service)}')
        service_provider = RemoteServiceProvider(
            name=name,
            service=service,
            exclude_attributes=exclude_attributes,
            import_name=import_name,
            service_args=service_args,
            service_kwargs=service_kwargs
        )

        module_name = service_provider.get_originating_module_name()

        if module_name is not None:
            self._module_ref.setdefault(module_name, 0)

            logger.debug(f'{repr(self)}: add_service -> incrementing ref count '
                         f'for module "{module_name}"')
            self._module_ref[module_name] += 1

        self._services[name] = service_provider

    def remove_service(self, name):
        logger.info(f'{repr(self)}: remove_service -> name: {name}')
        service_provider = self._services.pop(name, None)

        if service_provider is not None:
            module_name = service_provider.get_originating_module_name()

            if module_name is not None:
                logger.debug(f'{repr(self)}: add_service -> decrementing ref count '
                             f'for module "{module_name}"')

                self._module_ref[module_name] -= 1

                if self._module_ref[module_name] <= 0:
                    logger.debug(f'{repr(self)}: add_service -> unloading module: "{module_name}"')
                    self._code_importer.unload(module_name)
                    self._module_ref[module_name] = 0

    def get_service(self, name):
        return self._services.get(name)

    def do_handshake(self, protocol_magic):
        if protocol_magic != PROTOCOL_MAGIC:
            raise RuntimeError('Mismatching protocol magic')

        return self.get_service_names()

    def get_service_names(self):
        return list(self._services.keys())

    def clear_session(self, session_uuid):
        self._obj_cache.clear_session(session_uuid)

    def handle_protocol(self, binary):
        rpc = RemoteProcedureCall.deserialize(binary)

        logger.debug(f'{repr(self)}: handle_protocol -> {str(rpc)}')

        session_uuid = rpc.get_field(PROTOCOL_KEY_SESSION_UUID)
        class_name = rpc.get_field(PROTOCOL_KEY_CLASS_NAME)
        service_name = rpc.get_field(PROTOCOL_KEY_SERVICE)

        if class_name is not None:
            uid = rpc.get_field(PROTOCOL_KEY_UID)

            if uid is None:
                raise RuntimeError('uid must be defined with class_name')

            proxy = self._obj_cache.get(
                session_uuid=session_uuid,
                class_name=class_name,
                uid=uid
            )

        else:
            proxy = self._services.get(service_name)

        if proxy is None:
            raise RuntimeError(f'No such service: {service_name}')

        logger.debug(f'{repr(self)}: dispatching to {repr(proxy)}')

        return proxy.dispatch(
            rpc,
            self._obj_cache,
            session_uuid=session_uuid
        )

    def ping(self):
        return True

    def shutdown(self):
        self.quit = True

    def serve_forever(self):
        logger.debug(f'{repr(self)}: serving...')

        while not self.quit:
            self._xml_rpc_server.handle_request()

        logger.debug(f'{repr(self)}: stopping...')

    def spawn_rpc_server(self, session_id, port, python_exe=None, default_directory=None,
                         timeout=None, **kwargs):
        logger.debug(f'{repr(self)}: spawn_rpc_server -> session_id: {session_id}')

        proc_mgr = self.get_service(SVC_NAME_PROCESSES)

        if proc_mgr is None:
            raise RuntimeError()

        if python_exe is None:
            python_exe = get_default_python_exe()

        default_directory = default_directory or self.default_directory
        evt_mgr = self.get_service(SVC_NAME_EVENTS)

        if evt_mgr is None:
            raise RuntimeError()

        start_event = evt_mgr.create_event()
        server_kwargs = dict(host=self.host, port=port, default_directory=default_directory)
        cmd_line_args = [python_exe, __file__, start_event.name]

        arg_str = ', '.join(str(a) for a in cmd_line_args)
        logger.debug(f'{repr(self)}: spawn_rpc_server -> cmd_line_args: {arg_str}')

        kwds_str = kwargs2str(**server_kwargs)
        logger.debug(f'{repr(self)}: spawn_rpc_server -> server_kwargs: {kwds_str}')

        cmd_line_args.append(kwargs2command_line(**server_kwargs))

        logger.debug(f'{repr(self)}: spawn_rpc_server -> calling '
                     f'{proc_mgr.class_name}.create_process_in_session')
        pid = proc_mgr.create_process_in_session(session_id, *cmd_line_args, **kwargs)

        logger.debug(f'{repr(self)}: spawn_rpc_server -> received PID {pid} from '
                     f'{proc_mgr.class_name}.create_process_in_session')

        logger.debug(f'{repr(self)}: spawn_rpc_server -> waiting for start event '
                     f'(timeout={timeout})')

        if not start_event.wait(timeout=timeout):
            logger.debug(f'{repr(self)}: spawn_rpc_server -> timed out waiting for start event')
            logger.debug(f'{repr(self)}: spawn_rpc_server -> terminating PID {pid}')
            proc_mgr.terminate(pid)
            raise TimeoutError()

        logger.debug(f'{repr(self)}: spawn_rpc_server -> server successfully started')
        return pid


class RpcServerLauncher:
    def __init__(self, args):
        self.args = args
        self.session_uuid = None
        self.start_event_name = None
        self.server_kwargs = None
        self.event_manager = None

    def __str__(self):
        return f'{self.__class__.__name__}(session_uuid={self.session_uuid})'

    def __enter__(self):
        self.get_session_id()
        self.parse_args()
        self.config_logging()
        args_str = ', '.join(' '.join(arg.split('\n')) for arg in self.args)
        logger.debug(f'{str(self)}: __enter__ -> args: {args_str}')
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        exc_str = traceback.format_exception(exc_type, exc_val, exc_tb)
        logger.debug(f'{str(self)}: __exit__ -> exception: {exc_str}')

    def get_session_id(self):
        self.session_uuid = get_current_session_id(get_current_process_id())

    def parse_args(self):
        if len(self.args) != 2:
            raise RuntimeError()

        self.start_event_name = self.args[0]
        self.server_kwargs = command_line2kwargs(self.args[1])

    def config_logging(self):
        default_dir = self.server_kwargs['default_directory']
        session_logs_dir = os.path.join(default_dir, SESSION_LOGS_REL_DIR)

        if not os.path.exists(session_logs_dir):
            os.mkdir(session_logs_dir)

        log_file = os.path.join(session_logs_dir, SESSION_LOG_NAME_FMT.format(self.session_uuid))
        config_logging('debug', log_file=log_file)

        logger.debug(f'{str(self)}: logging config complete')

    def create_server(self):
        server = RpcServer(**self.server_kwargs)

        logger.debug(f'{str(self)}: created {repr(server)}')

        self.event_manager = server.get_service(SVC_NAME_EVENTS)

        if self.event_manager is None:
            raise RuntimeError()

        logger.debug(f'{str(self)}: setting start event -> name: "{self.start_event_name}"')
        self.set_start_event()
        return server

    def set_start_event(self):
        if self.start_event_name is not None and self.event_manager is not None:
            self.event_manager.set_event(self.start_event_name)


if __name__ == '__main__':
    with RpcServerLauncher(sys.argv[1:]) as launcher:
        rpc_server = launcher.create_server()
        rpc_server.serve_forever()


