# protocol.py
import inspect
import logging
import pickle
from collections import Callable
from xmlrpc.client import Binary
from zeus_utils import kwargs2str
from .utils import flatten_class_inheritance, is_custom_class_instance
from ._protocol_magic import PROTOCOL_MAGIC


logger = logging.getLogger(__name__)

RPC_STR_MAX_LEN = 256

PROTOCOL_KEY_SESSION_UUID = 'session_uuid'
PROTOCOL_KEY_SERVICE = 'service'
PROTOCOL_KEY_UID = 'uid'
PROTOCOL_KEY_CLASS_NAME = 'class_name'
PROTOCOL_KEY_METHOD = 'method'
PROTOCOL_KEY_ARGS = 'args'
PROTOCOL_KEY_KWARGS = 'kwargs'

SVC_PORT = 11111

SVC_NAME_ROOT = 'root'
SVC_NAME_MSI = 'msi'
SVC_NAME_REGISTRY = 'registry'
SVC_NAME_DRIVES = 'drives'
SVC_NAME_USERS = 'users'
SVC_NAME_FILES = 'files'
SVC_NAME_SESSIONS = 'sessions'
SVC_NAME_PROCESSES = 'processes'
SVC_NAME_EVENTS = 'events'
SVC_NAME_CMD = 'cmd'
SVC_NAME_SYSTEM = 'system'
SVC_NAME_SERVICES = 'services'
SVC_NAME_CODE_IMPORTER = 'code_importer'
SVC_NAME_PACKAGES = 'packages'

SVC_NAMES = {
    SVC_NAME_MSI, SVC_NAME_REGISTRY, SVC_NAME_DRIVES, SVC_NAME_USERS, SVC_NAME_FILES,
    SVC_NAME_SESSIONS, SVC_NAME_PROCESSES, SVC_NAME_EVENTS, SVC_NAME_CMD, SVC_NAME_SYSTEM
}


class ProtocolBinaryObject:
    @classmethod
    def deserialize(cls, binary, protocol_handler=None):
        bin_obj = pickle.loads(binary.data)
        bin_obj.protocol_handler = protocol_handler
        return bin_obj

    def __init__(self, protocol_handler=None, **kwargs):
        self.protocol_handler = protocol_handler
        self._data = dict(kwargs)

    def __getstate__(self):
        return {'_data': self._data}

    def __setstate__(self, state):
        self._data = state['_data']

    def __getitem__(self, item):
        return self._data[item]

    def __setitem__(self, key, value):
        self._data[key] = value

    def serialize(self):
        return Binary(pickle.dumps(self))


class ProtocolObjectProxy:
    _unbound_attr_cache = {}

    @classmethod
    def get_unbound_attribute_map(cls, type_):
        unbound_attr_map = cls._unbound_attr_cache.get(type_.__name__)

        if unbound_attr_map is None:
            unbound_attr_map = {}
            classes = flatten_class_inheritance(type_)

            for cls_ in classes:
                for attr_name, unbound_attr_obj in cls_.__dict__.items():
                    if attr_name.startswith('_'):
                        continue

                    is_callable = isinstance(unbound_attr_obj, Callable)
                    unbound_attr_map[attr_name] = (unbound_attr_obj, is_callable)

            cls._unbound_attr_cache[type_.__name__] = unbound_attr_map

        return dict(unbound_attr_map)

    def __init__(self, obj, session_uuid=None, exclude_attributes=None):
        cls = obj.__class__
        exclude = set(exclude_attributes or [])
        unbound_attr_map = self.get_unbound_attribute_map(cls)

        if exclude:
            for key in exclude.intersection(set(unbound_attr_map.keys())):
                unbound_attr_map.pop(key)

        self._session_uuid = session_uuid
        self._obj = obj
        self._unbound_attr_map = unbound_attr_map
        self._callable_map = {}
        self.class_name = cls.__name__
        self.uid = hash(obj)
        self.string = str(obj)

        for key, value in unbound_attr_map.items():
            _, is_callable = value
            self._callable_map[key] = is_callable

        for attr_name in dir(obj):
            if attr_name.startswith('_') or attr_name in self._callable_map:
                continue

            bound_attr = getattr(obj, attr_name)

            if inspect.ismethod(bound_attr) or inspect.isfunction(bound_attr):
                is_callable = True

            else:
                is_callable = False

            self._callable_map[attr_name] = is_callable

    def __repr__(self):
        return f'{self.__class__.__name__}(class_name="{self.class_name}", uid="{self.uid}")'

    def __getattr__(self, item):
        attr_info = self._unbound_attr_map.get(item)
        is_callable = self._callable_map.get(item)

        if attr_info is not None:
            unbound_attr, _ = attr_info

            if isinstance(unbound_attr, property):
                def wrapper(*args, **kwargs):
                    return unbound_attr.__get__(self._obj)

                return wrapper

            if is_callable:
                return unbound_attr.__get__(self._obj, self._obj.__class__)

        if not is_callable:
            def wrapper(*args, **kwargs):
                return getattr(self._obj, item)

            return wrapper

        return getattr(self._obj, item)

    def dispatch(self, rpc, object_cache, session_uuid):
        method_name = rpc.get_field(PROTOCOL_KEY_METHOD)
        args = rpc.get_field(PROTOCOL_KEY_ARGS)
        kwargs = rpc.get_field(PROTOCOL_KEY_KWARGS)
        result = getattr(self, method_name)(*args, **kwargs)

        if inspect.isgeneratorfunction(result) or inspect.isgenerator(result):
            result = list(result)

        if isinstance(result, (list, tuple)):
            safe_result = []

            for obj in result:
                if is_custom_class_instance(obj):
                    descriptor = object_cache.ensure(session_uuid, obj).to_descriptor(session_uuid)
                    safe_obj = descriptor.serialize()

                else:
                    safe_obj = obj

                safe_result.append(safe_obj)

            result = safe_result

        elif isinstance(result, dict):
            safe_result = {}

            for key, value in result.items():
                if is_custom_class_instance(value):
                    descriptor = object_cache.ensure(session_uuid, value).to_descriptor(session_uuid)
                    safe_obj = descriptor.serialize()

                else:
                    safe_obj = value

                safe_result[key] = safe_obj

            result = safe_result

        elif is_custom_class_instance(result):
            descriptor = object_cache.ensure(session_uuid, result).to_descriptor(session_uuid)
            result = descriptor.serialize()

        return result

    def to_descriptor(self, session_uuid):
        return ProtocolObjectDescriptor(session_uuid=session_uuid, class_name=self.class_name,
                                        uid=self.uid, string=self.string,
                                        callable_map=self._callable_map)


class ProtocolObjectCache:
    def __init__(self):
        self._storage = {}

    def ensure(self, session_uuid, obj):
        cls_name = obj.__class__.__name__
        uid = hash(obj)

        self._storage.setdefault(session_uuid, {})

        session_storage = self._storage[session_uuid]
        session_storage.setdefault(cls_name, {})
        proxy = session_storage[cls_name].get(uid)

        if proxy is None:
            proxy = ProtocolObjectProxy(obj, session_uuid=session_uuid)
            session_storage[cls_name][uid] = proxy

        return proxy

    def get(self, session_uuid, class_name, uid):
        session_storage = self._storage.get(session_uuid)

        if session_storage is not None:
            cls_storage = session_storage.get(class_name)

            if cls_storage is not None:
                return cls_storage.get(uid)

    def clear_session(self, session_uuid):
        self._storage.pop(session_uuid, None)

    def clear(self):
        self._storage.clear()


class ProtocolObjectDescriptor(ProtocolBinaryObject):
    def __init__(self, session_uuid, class_name, uid, string, callable_map, protocol_handler=None):
        super(ProtocolObjectDescriptor, self).__init__(protocol_handler=protocol_handler,
                                                       session_uuid=session_uuid,
                                                       class_name=class_name,
                                                       uid=uid,
                                                       string=string,
                                                       callable_map=callable_map)

    def __repr__(self):
        return f'{self.__class__.__name__}(class_name="{self.class_name}")'

    def __str__(self):
        return self.string

    def __getattr__(self, item):
        # if item not in self._data['callable_map']:
        #     raise AttributeError(f"'{self._data['class_name']}' instance has no attribute '{item}'")

        if self.protocol_handler is None:
            raise RuntimeError('No protocol_handler defined')

        is_callable = self._data['callable_map'].get(item)

        if is_callable is None:
            raise AttributeError(f"'{self._data['class_name']}' instance has no attribute '{item}'")

        rpc = RemoteProcedureCall(
            session_uuid=self._data['session_uuid'],
            class_name=self._data['class_name'],
            uid=self._data['uid'],
            protocol_handler=self.protocol_handler
        )

        attr_obj = getattr(rpc, item)
        return attr_obj if is_callable else attr_obj()

    @property
    def class_name(self):
        return self._data['class_name']

    @property
    def uid(self):
        return self._data['uid']

    @property
    def string(self):
        return self._data['string']

    @property
    def callable_map(self):
        return self._data['callable_map']


class RemoteProcedureCall(ProtocolBinaryObject):
    def __init__(self, session_uuid=None, service=None, class_name=None, uid=None,
                 protocol_handler=None):
        super(RemoteProcedureCall, self).__init__(protocol_handler=protocol_handler)
        # noinspection PyDictCreation
        self._data = {
            PROTOCOL_KEY_SESSION_UUID: session_uuid,
            PROTOCOL_KEY_SERVICE: service,
            PROTOCOL_KEY_CLASS_NAME: class_name,
            PROTOCOL_KEY_UID: uid,
            PROTOCOL_KEY_METHOD: None,
            PROTOCOL_KEY_ARGS: (),
            PROTOCOL_KEY_KWARGS: {}
        }

    def __str__(self):
        kwargs_str = kwargs2str(**self._data)

        if len(kwargs_str) > RPC_STR_MAX_LEN:
            kwargs_str = f'{kwargs_str[:RPC_STR_MAX_LEN]}...'

        return f'{self.__class__.__name__}({kwargs_str})'

    def __getattr__(self, item):
        if self.protocol_handler is None:
            raise AttributeError(f"'{self.__class__.__name__}' instance has no attribute '{item}'")

        self.set_field(PROTOCOL_KEY_METHOD, item)

        def _inner(*args, **kwargs):
            self.set_field(PROTOCOL_KEY_ARGS, args)
            self.set_field(PROTOCOL_KEY_KWARGS, kwargs)
            return self.protocol_handler(self)

        return _inner

    @property
    def service(self):
        return self._data[PROTOCOL_KEY_SERVICE]

    @property
    def method(self):
        return self._data[PROTOCOL_KEY_METHOD]

    def get_field(self, key):
        if key not in self._data:
            raise KeyError(key)

        return self._data[key]

    def set_field(self, key, value):
        if key not in self._data:
            raise KeyError(key)

        self._data[key] = value
