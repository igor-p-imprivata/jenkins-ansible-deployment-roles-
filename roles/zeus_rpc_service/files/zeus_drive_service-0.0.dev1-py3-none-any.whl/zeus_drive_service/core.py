# core.py
import ctypes
from ctypes import wintypes
import win32api
import win32wnet
from string import ascii_uppercase
from zeus_utils import find_by_attrs, findall_by_attrs, SingletonMeta
from zeus_win32_utils import (
    raise_windows_error, GetDriveType, WNetGetConnection, WConnectFlags, WResourceType, DriveTypes
)
from zeus_win32_utils.error_codes import (
    NO_ERROR, ERROR_NOT_CONNECTED, ERROR_MORE_DATA, ERROR_CONNECTION_UNAVAIL
)


class Drive:
    def __init__(self, index, letter, bitmask):
        self._index = index
        self.letter = letter
        self._bitmask = bitmask
        self._available = False
        self._remote_name = None
        self._has_remote_name = False
        self._get_conn_errno = None

    def __repr__(self):
        return f'{self.__class__.__name__}("{self.name}")'

    @property
    def name(self):
        return f'{self.letter}:'

    @property
    def available(self):
        net_loc = self.get_remote_name()
        return self._bitmask & (1 << self._index) == 0 and net_loc is None

    @property
    def connected(self):
        net_loc = self.get_remote_name()
        return net_loc is not None and self._get_conn_errno == NO_ERROR

    @property
    def get_conn_errno(self):
        return self._get_conn_errno

    @property
    def remote_name(self):
        return self.get_remote_name()

    @property
    def type(self):
        return DriveTypes(self.get_type())

    @property
    def user(self):
        return self.get_user()

    def _clear_state(self):
        self._has_remote_name = False
        self._remote_name = None
        self._get_conn_errno = None

    def get_type(self):
        return GetDriveType(self.name.encode('utf-8', 'strict'))

    def get_user(self):
        return win32wnet.WNetGetUser(self.name)

    def get_remote_name(self):
        if not self._has_remote_name:
            drive_name = f'{self.letter}:'
            b_drive_name = drive_name.encode('utf-8', 'strict')
            req_size = wintypes.DWORD(0)

            try:
                self._get_conn_errno = ret = WNetGetConnection(b_drive_name, None,
                                                               ctypes.byref(req_size))

                if ret != NO_ERROR and ret not in (ERROR_MORE_DATA, ERROR_CONNECTION_UNAVAIL):
                    if ret == ERROR_NOT_CONNECTED:
                        return

                    else:
                        raise_windows_error(ret)

                buf = ctypes.create_string_buffer(req_size.value)
                self._get_conn_errno = WNetGetConnection(b_drive_name, buf, ctypes.byref(req_size))
                self._remote_name = buf.value.decode('utf-8', 'strict')

            finally:
                self._has_remote_name = True

        return self._remote_name

    def connect(self, remote_name, username, password, w_resource_type=WResourceType.ANY,
                flags=WConnectFlags.UPDATE_PROFILE):
        if w_resource_type not in WResourceType:
            w_resource_type = WResourceType(w_resource_type)

        nr = win32wnet.NETRESOURCE()
        nr.dwType = w_resource_type.value
        nr.lpLocalName = self.name
        nr.lpRemoteName = remote_name
        nr.lpProvider = None
        win32wnet.WNetAddConnection2(nr, password, username, int(flags))
        self._clear_state()

    def disconnect(self, flags=WConnectFlags.UPDATE_PROFILE, force=True):
        if flags not in WConnectFlags:
            flags = WConnectFlags(flags)

        win32wnet.WNetCancelConnection2(self.name, flags.value, force)
        self._clear_state()


# noinspection PyMethodMayBeStatic
class DriveManager(metaclass=SingletonMeta):

    def enumerate(self):
        bitmask = win32api.GetLogicalDrives()

        for i, letter in enumerate(ascii_uppercase):
            yield Drive(i, letter, bitmask)

    def find(self, *, case_insensitive=True, sub_string=True, **attributes):
        return find_by_attrs(self.enumerate(), case_insensitive=case_insensitive,
                             sub_string=sub_string, attrs=attributes)

    def findall(self, *, case_insensitive=True, sub_string=True, **attributes):
        return findall_by_attrs(self.enumerate(), case_insensitive=case_insensitive,
                                sub_string=sub_string, attrs=attributes)

    def disconnect_drives(self):
        for drive in filter(lambda drv: drv.get_remote_name() is not None, self.enumerate()):
            drive.disconnect()

    def get_drives(self, reverse_order=True):
        drives = list(self.enumerate())

        if reverse_order and drives:
            drives.reverse()

        return drives

    def get_available_drive(self, reverse_order=True):
        available_drives = self.get_available_drives(reverse_order=reverse_order)

        if available_drives:
            return available_drives[0]

    def get_available_drives(self, reverse_order=True):
        available_drives = self.findall(available=True)

        if available_drives and reverse_order:
            available_drives.reverse()

        return available_drives


drive_manager = DriveManager()
